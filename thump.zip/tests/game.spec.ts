import { expect, test, type Page } from '@playwright/test';

let browserErrors: string[];

test.beforeEach(async ({ page }) => {
  browserErrors = [];
  page.on('pageerror', error => browserErrors.push(error.message));
  page.on('response', response => {
    if (response.status() >= 400) browserErrors.push(`${response.status()} ${response.url()}`);
  });
  // A stable seed makes the original randomized rounds reproducible.
  await page.addInitScript(() => { Date.now = () => 1792619693000; });
  await page.goto('/');
  await page.evaluate(() => document.fonts.ready);
  await expect(page.locator('.splash-play')).toBeVisible();
});

test.afterEach(() => {
  expect(browserErrors).toEqual([]);
});

async function expectPhase(page: Page, phase: string) {
  await expect(page.locator('[data-phase]')).toHaveAttribute('data-phase', phase);
}

async function sortedIndices(page: Page, level: number, reverse = false): Promise<number[]> {
  const indices = await page.evaluate(async level => {
    const modulePath = '/src/game/config.ts';
    const { buildRound } = await import(modulePath);
    return buildRound(level).items
      .map((item: { value: number }, index: number) => ({ index, value: item.value }))
      .sort((a: { value: number }, b: { value: number }) => b.value - a.value)
      .map((item: { index: number }) => item.index);
  }, level);
  return reverse ? indices.reverse() : indices;
}

async function arrangeWithKeyboard(page: Page, level: number, reverse = false) {
  for (const index of await sortedIndices(page, level, reverse)) {
    await page.keyboard.press(`Digit${index + 1}`);
    await page.keyboard.press('Enter');
  }
}

test('start screen, options, local assets, and native keyboard buttons', async ({ page }) => {
  await expect(page).toHaveTitle(/Thump/);
  expect(await page.locator('.splash-art').evaluate((image: HTMLImageElement) => image.complete && image.naturalWidth > 0)).toBe(true);
  await page.locator('.splash-icon').first().click();
  await expect(page.locator('.splash-icon').first()).toHaveAttribute('aria-pressed', 'true');
  await page.locator('.splash-icon').first().click();
  await page.locator('.splash-options').focus();
  await page.keyboard.press('Enter');
  await expectPhase(page, 'menu');
  await expect(page.locator('.panel')).toBeVisible();
  await expect(page.locator('.panel button.group')).toHaveCount(5);
  const assist = page.locator('.panel button[aria-pressed]').first();
  await assist.click();
  await expect(assist).toHaveAttribute('aria-pressed', 'true');
  const music = page.locator('.panel button[aria-label]');
  await music.click();
  await expect(music).toHaveAttribute('aria-pressed', 'true');
  await page.locator('.panel button').first().click();
  await page.locator('.splash-play').click();
  await expectPhase(page, 'playing');
  const audioState = await page.evaluate(async () => {
    // Reuse the app's module URL, including Vite's hot-reload timestamp.
    const modulePath = performance.getEntriesByType('resource')
      .map(entry => entry.name)
      .find(url => new URL(url).pathname === '/src/game/audio.ts')!;
    const { audio } = await import(modulePath);
    return { state: audio.ensure()?.state, music: audio.musicOn };
  });
  expect(audioState).toEqual({ state: 'running', music: true });
});

test('correct sorting advances the level and pause freezes the timer', async ({ page }) => {
  await page.locator('.splash-play').click();
  await arrangeWithKeyboard(page, 1);
  await expectPhase(page, 'levelclear');
  await page.locator('.panel button').click();
  await expectPhase(page, 'playing');
  await page.locator('button[aria-label$="(P)"]').click();
  await expectPhase(page, 'paused');
  const timer = page.locator('.tabular-nums').last();
  const pausedTime = await timer.textContent();
  await page.waitForTimeout(500);
  expect(await timer.textContent()).toBe(pausedTime);
  await page.keyboard.press('KeyR');
  await expectPhase(page, 'playing');
  // Assist and mute are keyboard-only: their HUD buttons were removed from the game screen.
  await page.keyboard.press('KeyA');
  await page.keyboard.press('KeyM');
  await expectPhase(page, 'playing');
  await page.keyboard.press('Escape');
  await page.locator('.panel button').last().click();
  await expect(page.locator('.splash-play')).toBeVisible();
});

test('mouse drag-and-drop places objects in the right shelf cells', async ({ page }) => {
  await page.locator('.splash-play').click();
  await page.waitForTimeout(1200);
  const indices = await sortedIndices(page, 1);
  const { width: w, height: h } = page.viewportSize()!;
  const cell = (w - 92) / indices.length;
  for (const [slot, index] of indices.entries()) {
    const x = 46 + cell * (index + 0.5);
    const destination = 46 + cell * (indices.length - slot - 0.5);
    await page.mouse.move(x, h * 0.6 - 65);
    await page.mouse.down();
    await page.mouse.move(destination, h * 0.83, { steps: 15 });
    await page.mouse.up();
    await page.waitForTimeout(350);
  }
  await expectPhase(page, 'levelclear');
});

test('three failed rounds open game over directly and persist a high score', async ({ page }) => {
  await page.locator('.splash-play').click();
  await arrangeWithKeyboard(page, 1);
  await page.locator('.panel button').click();
  for (let attempt = 0; attempt < 3; attempt++) {
    await arrangeWithKeyboard(page, 2, true);
    await expectPhase(page, attempt === 2 ? 'gameover' : 'roundfailed');
    if (attempt < 2) await page.locator('.panel button').click();
  }
  // The result screen opens straight away; the intermediate reveal card is gone.
  await expect(page.getByText('See results')).toHaveCount(0);
  await expect(page.getByRole('textbox')).toBeVisible();
  await page.getByRole('textbox').fill('Test Player');
  const save = page.locator('.panel input + button');
  await save.focus();
  await page.keyboard.press('Enter');
  await expect(save).toBeDisabled();
  const scores = await page.evaluate(() => JSON.parse(localStorage.getItem('thump.scores.v1') || '[]'));
  expect(scores).toHaveLength(1);
  expect(scores[0].name).toBe('Test Player');
  expect(scores[0].score).toBeGreaterThan(0);
  await page.reload();
  await page.locator('.splash-options').click();
  await expect(page.getByText('Test Player')).toBeVisible();
});

test('all fifty original stages, five renderers, and pitch ordering work', async ({ page }) => {
  const result = await page.evaluate(async () => {
    const enginePath = '/src/game/engine.ts';
    const configPath = '/src/game/config.ts';
    const audioPath = '/src/game/audio.ts';
    const drawPath = '/src/game/draw.ts';
    const { Game } = await import(enginePath);
    const { SEASONS } = await import(configPath);
    const { AudioEngine } = await import(audioPath);
    const { drawItemBody } = await import(drawPath);
    const canvas = document.createElement('canvas');
    canvas.style.cssText = 'position:absolute;left:-2000px;width:900px;height:640px';
    document.body.appendChild(canvas);
    let latest: { score: number; level: number } = { score: 0, level: 0 };
    const game = new Game(canvas, (state: typeof latest) => { latest = state; });
    game.setMuted(true);
    const completed: number[] = [];
    for (let level = 1; level <= 50; level++) {
      game.startGame(level);
      const expected = SEASONS[Math.floor((level - 1) / 10)].type;
      if (game.items.some((item: { type: string }) => item.type !== expected)) throw new Error(`Wrong season ${level}`);
      const ordered = [...game.items].sort((a, b) => b.value - a.value);
      for (const item of ordered) {
        game.selectIndex(item.idx);
        game.cursorPlace();
        const ctx = canvas.getContext('2d')!;
        ctx.save();
        ctx.translate(400, 400);
        drawItemBody(ctx, { ...item, reveal: 1 }, 3);
        ctx.restore();
      }
      if (game.phase !== 'levelclear' || latest.score <= 0) throw new Error(`Could not complete stage ${level}`);
      game.continueNow();
      if (game.phase !== 'playing' || latest.level !== level + 1) throw new Error(`Could not advance from ${level}`);
      completed.push(level);
    }
    game.startGame(1);
    const glass = { ...game.items[0], w: 65, h: 120, reveal: 0 };
    const pixels = (value: number, reveal: number) => {
      const sample = document.createElement('canvas');
      sample.width = sample.height = 256;
      const ctx = sample.getContext('2d')!;
      ctx.translate(128, 200);
      drawItemBody(ctx, { ...glass, value, reveal }, 3);
      return Array.from(ctx.getImageData(0, 0, 256, 256).data).join(',');
    };
    const hidden = pixels(0.1, 0) === pixels(0.9, 0);
    const revealed = pixels(0.1, 1) !== pixels(0.9, 1);
    const pitches = SEASONS.every((season: { type: string }) => AudioEngine.pitchFor(season.type, 0.9) < AudioEngine.pitchFor(season.type, 0.1));
    game.destroy();
    canvas.remove();
    return { completed: completed.length, hidden, revealed, pitches };
  });
  expect(result).toEqual({ completed: 50, hidden: true, revealed: true, pitches: true });
});

test.describe('Touch layout', () => {
  test.use({ viewport: { width: 390, height: 844 }, isMobile: true, hasTouch: true });

  test('touch selection and shelf placement complete a round', async ({ page }) => {
    await page.locator('.splash-play').tap();
    await page.waitForTimeout(1200);
    const indices = await sortedIndices(page, 1);
    const w = 390;
    const h = 844;
    const pad = w * 0.015;
    const cell = (w - pad * 2) / indices.length;
    for (const [slot, index] of indices.entries()) {
      await page.touchscreen.tap(pad + cell * (index + 0.5), h * 0.6 - 50);
      await page.touchscreen.tap(pad + cell * (indices.length - slot - 0.5), h * 0.83);
      await page.waitForTimeout(350);
    }
    await expectPhase(page, 'levelclear');
    expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true);
  });

  test('all season choices remain reachable on mobile', async ({ page }) => {
    await page.locator('.splash-options').tap();
    const lastSeason = page.locator('.panel button.group').last();
    await lastSeason.scrollIntoViewIfNeeded();
    await lastSeason.tap();
    await expectPhase(page, 'playing');
    await page.waitForTimeout(1200);
    expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true);
  });
});