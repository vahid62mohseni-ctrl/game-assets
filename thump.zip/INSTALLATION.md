# Thump

A listening and sorting game: knock objects, listen to how they sound and line them up on the shelf from full to empty.

## Running

- `npm install`
- `npm run dev`
- `npm run build` for the production version in `dist/`.
- `npm run preview` to preview the production version.

## Notes

- The whole interface is in English; fonts (Lilita One and Nunito) are bundled locally.
- All sounds are synthesized locally with Web Audio. No remote services are required while playing.
- High scores and the player name are stored in this browser's local storage (`thump.scores.v1`, `thump.name.v1`).
- Artwork lives in `src/assets/` (menu poster, game environment, one sprite per season, the opened can and the coin).
