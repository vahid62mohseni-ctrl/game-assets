/**
 * Thump — audio engine
 * Most sounds are synthesized with WebAudio. The piggy-bank knock uses a local coin sample.
 * Core rule of the design: the FULLER an object is, the LOWER its knock pitch.
 */

import { embeddedAssets } from "../embeddedAssets";

// Six real coin recordings (SoundBible 2081 Public Domain; Mixkit free SFX 3187, 1939,
// 2003, 1993, 1989). One is assigned to each piggy bank, emptiest to fullest.
const coinUrls = embeddedAssets.coinSamples;

export type KnockType = "glass" | "can" | "melon" | "piggy" | "head";

const PENTA = [523.25, 587.33, 659.25, 783.99, 880.0, 1046.5, 1174.7, 1318.5, 1567.98];

export class AudioEngine {
  private ac: AudioContext | null = null;
  private master: GainNode | null = null;
  private wet: GainNode | null = null;
  private noiseBuf: AudioBuffer | null = null;
  private musicGain: GainNode | null = null;
  private musicTimer: number | null = null;
  private musicStep = 0;
  private coinClips: AudioBuffer[] = [];
  private coinSeqGain: GainNode | null = null;
  private coinSeqSources: AudioBufferSourceNode[] = [];
  private coinPromise: Promise<AudioBuffer[]> | null = null;
  muted = false;
  musicOn = false;

  ensure(): AudioContext | null {
    if (typeof window === "undefined") return null;
    if (!this.ac) {
      const AC: typeof AudioContext =
        window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (!AC) return null;
      try {
        this.ac = new AC();
      } catch {
        return null;
      }
      const ac = this.ac;
      this.master = ac.createGain();
      this.master.gain.value = this.muted ? 0 : 0.9;
      const comp = ac.createDynamicsCompressor();
      comp.threshold.value = -14;
      comp.ratio.value = 7;
      comp.attack.value = 0.003;
      comp.release.value = 0.18;
      this.master.connect(comp).connect(ac.destination);

      // tiny algorithmic reverb for satisfying "room" knocks
      const conv = ac.createConvolver();
      const len = Math.floor(ac.sampleRate * 1.1);
      const buf = ac.createBuffer(2, len, ac.sampleRate);
      for (let c = 0; c < 2; c++) {
        const d = buf.getChannelData(c);
        for (let i = 0; i < len; i++) {
          d[i] = (Math.random() * 2 - 1) * Math.pow(1 - i / len, 3.2);
        }
      }
      conv.buffer = buf;
      this.wet = ac.createGain();
      this.wet.gain.value = 0.24;
      this.wet.connect(conv).connect(this.master);

      // noise buffer
      const nlen = Math.floor(ac.sampleRate * 1.2);
      this.noiseBuf = ac.createBuffer(1, nlen, ac.sampleRate);
      const nd = this.noiseBuf.getChannelData(0);
      for (let i = 0; i < nlen; i++) nd[i] = Math.random() * 2 - 1;

      this.musicGain = ac.createGain();
      this.musicGain.gain.value = 0.0;
      this.musicGain.connect(this.master);
      void this.loadCoins(ac);
    }
    if (this.ac.state === "suspended") void this.ac.resume();
    return this.ac;
  }

  /**
   * Trims the dead air off a coin recording, caps its length with a short fade, and
   * measures how many separate coin hits it contains plus how loud it is. Those two
   * numbers decide which bank it belongs to: few quiet hits = nearly empty,
   * many loud hits = full.
   */
  private prepareCoinClip(
    ac: AudioContext,
    decoded: AudioBuffer,
  ): { buffer: AudioBuffer; hits: number; loudness: number } | null {
    const sr = decoded.sampleRate;
    const ch = decoded.numberOfChannels;
    const d0 = decoded.getChannelData(0);
    const total = decoded.length;
    if (!total) return null;

    let peak = 1e-6;
    for (let i = 0; i < total; i++) {
      const a = Math.abs(d0[i]);
      if (a > peak) peak = a;
    }

    const win = Math.max(1, Math.floor(sr * 0.005));
    const numW = Math.max(1, Math.floor(total / win));
    const rms = new Float32Array(numW);
    let maxRms = 1e-6;
    for (let w = 0; w < numW; w++) {
      let sum = 0;
      const base = w * win;
      for (let i = 0; i < win; i++) {
        const s = d0[base + i];
        sum += s * s;
      }
      const r = Math.sqrt(sum / win);
      rms[w] = r;
      if (r > maxRms) maxRms = r;
    }

    // First audible moment, with a couple of milliseconds of pre-roll kept.
    let firstW = 0;
    while (firstW < numW && rms[firstW] < maxRms * 0.06) firstW++;
    const start = Math.max(0, firstW * win - Math.floor(sr * 0.004));

    const maxLen = Math.floor(sr * 1.25);
    const len = Math.max(1, Math.min(maxLen, total - start));
    const fadeOut = Math.min(len, Math.floor(sr * 0.05));
    const clip = ac.createBuffer(ch, len, sr);
    const norm = 0.92 / peak;
    for (let c = 0; c < ch; c++) {
      const srcData = decoded.getChannelData(c);
      const dst = clip.getChannelData(c);
      for (let i = 0; i < len; i++) {
        const fade = i >= len - fadeOut ? (len - i) / fadeOut : 1;
        dst[i] = srcData[start + i] * norm * fade;
      }
    }

    // Measure the clip that will actually be heard, so the bank ordering matches
    // what the player counts: distinct coin hits first, then overall loudness.
    const cd = clip.getChannelData(0);
    const cWin = Math.max(1, Math.floor(sr * 0.005));
    const cNum = Math.max(1, Math.floor(cd.length / cWin));
    const cRms = new Float32Array(cNum);
    let cMax = 1e-6;
    let energy = 0;
    for (let w = 0; w < cNum; w++) {
      let sum = 0;
      const base = w * cWin;
      for (let i = 0; i < cWin; i++) {
        const s = cd[base + i];
        sum += s * s;
      }
      const r = Math.sqrt(sum / cWin);
      cRms[w] = r;
      energy += r * r;
      if (r > cMax) cMax = r;
    }
    let hits = 0;
    let armed = true;
    for (let w = 0; w < cNum; w++) {
      const r = cRms[w];
      if (armed && r > cMax * 0.3) {
        hits++;
        armed = false;
      } else if (!armed && r < cMax * 0.13) {
        armed = true;
      }
    }
    return { buffer: clip, hits: Math.max(1, hits), loudness: Math.sqrt(energy / cNum) };
  }

  /** Loads every coin recording once and orders them from fewest to most coins. */
  private loadCoins(ac: AudioContext): Promise<AudioBuffer[]> {
    if (this.coinClips.length) return Promise.resolve(this.coinClips);
    if (!this.coinPromise) {
      this.coinPromise = Promise.all(
        coinUrls.map((url) =>
          fetch(url)
            .then((res) => (res.ok ? res.arrayBuffer() : Promise.reject(new Error("bad sample"))))
            .then((buf) => ac.decodeAudioData(buf))
            .then((decoded) => this.prepareCoinClip(ac, decoded))
            .catch(() => null),
        ),
      )
        .then((prepared) => {
          const ok = prepared.filter((p): p is NonNullable<typeof p> => Boolean(p));
          if (!ok.length) return [];
          // Order by how many coins each recording actually contains, quietest first:
          // the emptiest bank gets the sparsest take, the fullest the densest one.
          ok.sort((a, b) => a.hits - b.hits || a.loudness - b.loudness);
          this.coinClips = ok.map((p) => p.buffer);
          return this.coinClips;
        })
        .catch(() => [] as AudioBuffer[])
        .then((clips) => {
          if (!clips.length) this.coinPromise = null;
          return clips;
        });
    }
    return this.coinPromise;
  }

  /** Plays one bank's own dry recording — no reverb send, so nothing echoes. */
  private playCoinForBank(ac: AudioContext, startAt: number, index: number, gain: number): boolean {
    if (!this.coinClips.length || !this.master) return false;
    const buffer = this.coinClips[Math.max(0, Math.min(this.coinClips.length - 1, index))];
    if (!buffer) return false;

    // Cut the previous bank's recording so consecutive knocks never layer into an echo.
    if (this.coinSeqGain) {
      const prevGain = this.coinSeqGain;
      const prevSources = this.coinSeqSources;
      try {
        prevGain.gain.cancelScheduledValues(startAt);
        prevGain.gain.setValueAtTime(Math.max(0.0001, prevGain.gain.value), startAt);
        prevGain.gain.exponentialRampToValueAtTime(0.0001, startAt + 0.012);
        for (const s of prevSources) {
          try {
            s.stop(startAt + 0.015);
          } catch {
            /* already stopped */
          }
        }
      } catch {
        /* ignore */
      }
    }

    const src = ac.createBufferSource();
    const out = ac.createGain();
    src.buffer = buffer;
    src.playbackRate.value = 1;
    const dur = Math.min(buffer.duration, 1.2);
    out.gain.setValueAtTime(Math.max(0.0002, gain), startAt);
    out.gain.setValueAtTime(Math.max(0.0002, gain), startAt + Math.max(0.02, dur - 0.09));
    out.gain.exponentialRampToValueAtTime(0.0001, startAt + dur);
    // Dry path only: straight to master, bypassing the room convolver.
    src.connect(out).connect(this.master);
    this.coinSeqGain = out;
    this.coinSeqSources = [src];
    src.start(startAt);
    src.stop(startAt + dur + 0.02);
    return true;
  }

  setMuted(m: boolean) {
    this.muted = m;
    if (this.master && this.ac) {
      this.master.gain.setTargetAtTime(m ? 0 : 0.9, this.ac.currentTime, 0.05);
    }
  }

  // ---------- primitives ----------
  private osc(
    ac: AudioContext,
    opts: {
      type?: OscillatorType;
      f0: number;
      f1?: number;
      t0: number;
      dur: number;
      peak: number;
      attack?: number;
      dest?: AudioNode;
      sendWet?: number;
      detune?: number;
    },
  ) {
    const o = ac.createOscillator();
    const g = ac.createGain();
    o.type = opts.type ?? "sine";
    if (opts.detune) o.detune.value = opts.detune;
    o.frequency.setValueAtTime(Math.max(20, opts.f0), opts.t0);
    if (opts.f1) o.frequency.exponentialRampToValueAtTime(Math.max(20, opts.f1), opts.t0 + opts.dur);
    const atk = opts.attack ?? 0.004;
    g.gain.setValueAtTime(0.0001, opts.t0);
    g.gain.exponentialRampToValueAtTime(Math.max(0.0002, opts.peak), opts.t0 + atk);
    g.gain.exponentialRampToValueAtTime(0.0001, opts.t0 + opts.dur);
    o.connect(g);
    g.connect(opts.dest ?? this.master ?? ac.destination);
    if (opts.sendWet && this.wet) {
      const s = ac.createGain();
      s.gain.value = opts.sendWet;
      g.connect(s).connect(this.wet);
    }
    o.start(opts.t0);
    o.stop(opts.t0 + opts.dur + 0.05);
  }

  private noise(
    ac: AudioContext,
    opts: {
      f0: number;
      f1?: number;
      q?: number;
      type?: BiquadFilterType;
      t0: number;
      dur: number;
      peak: number;
      sendWet?: number;
      dest?: AudioNode;
    },
  ) {
    if (!this.noiseBuf) return;
    const src = ac.createBufferSource();
    src.buffer = this.noiseBuf;
    src.playbackRate.value = 0.85 + Math.random() * 0.4;
    const filt = ac.createBiquadFilter();
    filt.type = opts.type ?? "bandpass";
    filt.frequency.setValueAtTime(Math.max(40, opts.f0), opts.t0);
    if (opts.f1) filt.frequency.exponentialRampToValueAtTime(Math.max(40, opts.f1), opts.t0 + opts.dur);
    filt.Q.value = opts.q ?? 1.2;
    const g = ac.createGain();
    g.gain.setValueAtTime(0.0001, opts.t0);
    g.gain.exponentialRampToValueAtTime(Math.max(0.0002, opts.peak), opts.t0 + 0.006);
    g.gain.exponentialRampToValueAtTime(0.0001, opts.t0 + opts.dur);
    src.connect(filt).connect(g);
    g.connect(opts.dest ?? this.master!);
    if (opts.sendWet && this.wet) {
      const s = ac.createGain();
      s.gain.value = opts.sendWet;
      g.connect(s).connect(this.wet);
    }
    src.start(opts.t0, Math.random() * 0.4);
    src.stop(opts.t0 + opts.dur + 0.05);
  }

  /** Reference pitch (Hz) for a given fill value — used by the assist meter too. */
  static pitchFor(type: KnockType, v: number): number {
    const x = Math.min(1, Math.max(0, v));
    switch (type) {
      case "glass":
        return 340 + (1 - x) * 830;
      case "can":
        return 205 + (1 - x) * 175;
      case "melon":
        return 84 + (1 - x) * 120;
      case "piggy":
        return 140 + (1 - x) * 900;
      case "head":
        // A full head gives a deep, meaty smack; an empty head gives a high, sharp one.
        // More than three octaves apart so the difference is easy to hear.
        return 92 + (1 - x) * 838;
    }
  }

  // ---------- game sounds ----------
  knock(type: KnockType, value: number, coinCount?: number) {
    const ac = this.ensure();
    if (!ac || this.muted) return;
    const t = ac.currentTime + 0.001;
    const f = AudioEngine.pitchFor(type, value);

    if (type === "glass") {
      this.osc(ac, { type: "sine", f0: f, f1: f * 0.995, t0: t, dur: 1.15, peak: 0.34, sendWet: 0.5 });
      this.osc(ac, { type: "sine", f0: f * 2.72, t0: t, dur: 0.42, peak: 0.11, sendWet: 0.35 });
      this.osc(ac, { type: "triangle", f0: f * 4.2, t0: t, dur: 0.16, peak: 0.05 });
      this.noise(ac, { f0: f * 3.1, f1: f * 1.2, q: 0.9, t0: t, dur: 0.06, peak: 0.16 });
      // liquid body
      this.noise(ac, { type: "lowpass", f0: 520 + f * 0.35, f1: 180, q: 3, t0: t, dur: 0.16, peak: 0.1 });
    } else if (type === "can") {
      // --- metal can ---
      // The fuller it is: the body ring dies sooner and the sound gets duller and deeper.
      const full = value;
      const ringDur = 0.1 + (1 - full) * 1.05; // an empty can rings for up to ~1.1 seconds
      const ringAmt = 1 - full * 0.74; // the legumes soak up the body vibration

      // Cylinder modes of the metal: inharmonic, just like a real can
      const modes = [1, 1.82, 2.67, 3.61, 4.48];
      modes.forEach((m, i) => {
        this.osc(ac, {
          type: i === 0 ? "triangle" : "sine",
          f0: f * m,
          f1: f * m * 0.994,
          t0: t + i * 0.0012,
          dur: Math.max(0.05, ringDur / (1 + i * 0.34)),
          peak: (0.2 * ringAmt) / (1 + i * 1.05),
          sendWet: 0.42,
        });
      });

      // Fingernail / finger hitting the metal sheet: a very short, bright click
      this.noise(ac, { f0: 4300 - full * 1700, f1: 1500, q: 1.1, t0: t, dur: 0.028, peak: 0.2 });
      this.noise(ac, { type: "highpass", f0: 3100, q: 0.7, t0: t, dur: 0.016, peak: 0.11 });

      // Weight of the contents: a full can has a deep, solid thud
      this.osc(ac, {
        type: "sine",
        f0: 155 + full * 45,
        f1: 68,
        t0: t,
        dur: 0.12 + full * 0.13,
        peak: 0.11 + full * 0.24,
      });
      this.noise(ac, {
        type: "lowpass",
        f0: 460 + full * 220,
        f1: 120,
        q: 1.2,
        t0: t,
        dur: 0.09 + full * 0.09,
        peak: 0.1 + full * 0.17,
      });

      // Legumes knocking together: tiny ticks; more and rattlier in an empty can
      const grains = Math.round(1 + (1 - full) * 9);
      for (let i = 0; i < grains; i++) {
        this.noise(ac, {
          f0: (full > 0.6 ? 900 : 1500) + Math.random() * (full > 0.6 ? 1300 : 2600),
          q: 7,
          t0: t + 0.02 + Math.random() * (0.06 + (1 - full) * 0.22),
          dur: 0.018 + Math.random() * 0.022,
          peak: 0.012 + (1 - full) * 0.055,
        });
      }

      // Contents settling in a full can: a short, deep rumble
      if (full > 0.42) {
        this.noise(ac, {
          type: "lowpass",
          f0: 320,
          f1: 85,
          q: 1,
          t0: t + 0.028,
          dur: 0.17,
          peak: (full - 0.42) * 0.34,
        });
      }

      // Second rebound of the metal sheet (double bounce)
      this.osc(ac, {
        type: "triangle",
        f0: f * 1.03,
        f1: f * 0.99,
        t0: t + 0.052,
        dur: Math.max(0.05, ringDur * 0.42),
        peak: 0.055 * ringAmt,
        sendWet: 0.3,
      });
    } else if (type === "melon") {
      const hollow = 0.5 + value * 0.6;
      this.osc(ac, { type: "sine", f0: f, f1: f * 0.86, t0: t, dur: 0.5 + hollow * 0.5, peak: 0.42, attack: 0.006, sendWet: 0.55 });
      this.osc(ac, { type: "sine", f0: f * 1.98, f1: f * 1.7, t0: t, dur: 0.24, peak: 0.11 });
      this.osc(ac, { type: "triangle", f0: f * 3.4, t0: t, dur: 0.09, peak: 0.05 * (1 - value * 0.6) });
      this.noise(ac, { type: "lowpass", f0: 900 - value * 420, f1: 200, q: 1.2, t0: t, dur: 0.13, peak: 0.13 });
    } else if (type === "piggy") {
      const full = Math.max(0, Math.min(1, value));
      // Each bank plays its own recorded coin sample: the emptiest bank gets the
      // sparsest, quietest take and the fullest gets the densest, loudest one.
      const rank =
        coinCount !== undefined
          ? Math.max(1, Math.round(coinCount)) - 1
          : Math.round(full * (this.coinClips.length - 1 || 5));
      const gain = 0.7 + full * 0.32;
      if (!this.playCoinForBank(ac, t, rank, gain)) {
        void this.loadCoins(ac).then((clips) => {
          if (clips.length && !this.muted && this.ac === ac) {
            this.playCoinForBank(ac, ac.currentTime + 0.001, rank, gain);
          }
        });
      }
    } else {
      // --- palm slap on a cheek: noise only, no drum-like oscillation ---
      // The structure and character of the sound are the approved version; only the loudness (peak) and
      // the range of the "k" factor were widened so the pitches are easier to tell apart.
      const full = value;
      const empty = 1 - full;
      // A much wider frequency range: about 5x between the fullest and the emptiest
      const k = 0.32 * Math.pow(6.2, empty); // exponential: 0.32 to 1.98, each step ~1.5x
      // Loudness also changes with fullness: a full head is louder, an empty one quieter
      const loud = 0.14 * Math.pow(8.5, full); // 0.14 to 1.19, each step ~1.35x louder
      const crack = t + 0.012;

      // Air escaping from the palm, very short and light
      this.noise(ac, {
        type: "highpass",
        f0: 2400 * k,
        q: 0.55,
        t0: t,
        dur: 0.014,
        peak: 0.03 * loud,
      });

      // Crack of the slap on skin: the core of the sound
      this.noise(ac, {
        type: "highpass",
        f0: 2100 * k,
        q: 0.5,
        t0: crack,
        dur: 0.018 + empty * 0.012,
        peak: 0.2 * loud,
      });
      this.noise(ac, {
        type: "bandpass",
        f0: 1650 * k,
        f1: 900 * k,
        q: 1.1,
        t0: crack,
        dur: 0.03,
        peak: 0.09 * loud,
      });

      // Cheek flesh: deep and heavy when full, thin when empty
      this.noise(ac, {
        type: "lowpass",
        f0: 780 * k,
        f1: 240 * k,
        q: 0.7,
        t0: crack,
        dur: 0.04 + full * 0.02,
        peak: (0.06 + full * 0.1) * loud,
      });

      // Rustle of skin and hair
      this.noise(ac, {
        type: "bandpass",
        f0: 1100 * k,
        f1: 520 * k,
        q: 1.4,
        t0: crack + 0.004,
        dur: 0.024,
        peak: (0.05 + empty * 0.1) * loud,
      });

      // Narrow resonance on the same noise: makes the pitch (deep/high) recognisable
      const ring = 80 * Math.pow(21, empty); // 80 to 1680 Hz in equal steps
      this.noise(ac, {
        type: "bandpass",
        f0: ring,
        f1: ring * 0.98,
        q: 34,
        t0: crack,
        dur: 0.34 + empty * 0.2,
        peak: 0.5 * loud,
        sendWet: 0.22,
      });
      this.noise(ac, {
        type: "bandpass",
        f0: ring * 2,
        f1: ring * 1.97,
        q: 24,
        t0: crack,
        dur: 0.1,
        peak: 0.3 * loud,
      });

      // Short and tuneful: the pitch changes with how full the head is (180 to 640 Hz)
      const tone = 170 * Math.pow(4.6, empty); // 170 to 780 Hz in equal steps
      this.osc(ac, {
        type: "triangle",
        f0: tone * 1.5,
        f1: tone,
        attack: 0.001,
        t0: crack,
        dur: 0.085 + full * 0.05,
        peak: 0.62 * loud,
        sendWet: 0.1,
      });
      this.osc(ac, {
        type: "sine",
        f0: tone * 2,
        f1: tone * 1.9,
        attack: 0.001,
        t0: crack,
        dur: 0.045,
        peak: 0.16 * loud,
      });
    }
  }

  place(combo: number) {
    const ac = this.ensure();
    if (!ac || this.muted) return;
    const t = ac.currentTime;
    const f = PENTA[Math.min(combo, PENTA.length - 1)];
    this.osc(ac, { type: "triangle", f0: f, t0: t, dur: 0.24, peak: 0.2 });
    this.osc(ac, { type: "sine", f0: f * 2, t0: t, dur: 0.18, peak: 0.09, sendWet: 0.4 });
    this.noise(ac, { type: "lowpass", f0: 700, f1: 200, q: 1, t0: t, dur: 0.08, peak: 0.12 });
  }

  thunk() {
    const ac = this.ensure();
    if (!ac || this.muted) return;
    const t = ac.currentTime;
    this.noise(ac, { type: "lowpass", f0: 460, f1: 120, q: 1.4, t0: t, dur: 0.1, peak: 0.2 });
  }

  error() {
    const ac = this.ensure();
    if (!ac || this.muted) return;
    const t = ac.currentTime;
    this.osc(ac, { type: "sawtooth", f0: 230, f1: 70, t0: t, dur: 0.38, peak: 0.16 });
    this.osc(ac, { type: "square", f0: 118, f1: 58, t0: t + 0.02, dur: 0.3, peak: 0.08 });
    this.noise(ac, { type: "bandpass", f0: 800, f1: 200, q: 1, t0: t, dur: 0.22, peak: 0.12 });
  }

  sparkle() {
    const ac = this.ensure();
    if (!ac || this.muted) return;
    const t = ac.currentTime;
    [1568, 2093, 2637].forEach((f, i) =>
      this.osc(ac, { type: "sine", f0: f, t0: t + i * 0.045, dur: 0.3, peak: 0.07, sendWet: 0.5 }),
    );
  }

  levelClear() {
    const ac = this.ensure();
    if (!ac || this.muted) return;
    const t = ac.currentTime;
    [523.25, 659.25, 783.99, 1046.5].forEach((f, i) => {
      this.osc(ac, { type: "triangle", f0: f, t0: t + i * 0.09, dur: 0.42, peak: 0.2, sendWet: 0.45 });
      this.osc(ac, { type: "sine", f0: f * 2, t0: t + i * 0.09, dur: 0.28, peak: 0.07 });
    });
    this.noise(ac, { type: "highpass", f0: 3200, q: 0.7, t0: t + 0.1, dur: 0.5, peak: 0.06, sendWet: 0.6 });
  }

  gameOver() {
    const ac = this.ensure();
    if (!ac || this.muted) return;
    const t = ac.currentTime;
    [440, 392, 330, 262].forEach((f, i) =>
      this.osc(ac, { type: "triangle", f0: f, f1: f * 0.97, t0: t + i * 0.13, dur: 0.5, peak: 0.17, sendWet: 0.4 }),
    );
    this.noise(ac, { type: "lowpass", f0: 400, f1: 90, q: 1, t0: t, dur: 0.6, peak: 0.14 });
  }

  click(high = false) {
    const ac = this.ensure();
    if (!ac || this.muted) return;
    const t = ac.currentTime;
    this.osc(ac, { type: "sine", f0: high ? 1180 : 760, f1: high ? 820 : 520, t0: t, dur: 0.09, peak: 0.11 });
    this.noise(ac, { type: "highpass", f0: 2600, q: 0.8, t0: t, dur: 0.03, peak: 0.05 });
  }

  tick() {
    const ac = this.ensure();
    if (!ac || this.muted) return;
    this.osc(ac, { type: "sine", f0: 1500, t0: ac.currentTime, dur: 0.06, peak: 0.05 });
  }

  // ---------- ambient menu music ----------
  setMusic(on: boolean) {
    this.musicOn = on;
    if (!on && this.musicTimer !== null) {
      window.clearInterval(this.musicTimer);
      this.musicTimer = null;
    }
    if (!on && !this.ac) return;
    const ac = this.ensure();
    if (!ac || !this.musicGain) return;
    this.musicGain.gain.setTargetAtTime(on && !this.muted ? 0.18 : 0, ac.currentTime, 0.4);
    if (on && this.musicTimer === null) {
      this.musicTimer = window.setInterval(() => this.musicTick(), 470);
    }
  }

  private musicTick() {
    const ac = this.ac;
    if (!ac || !this.musicGain || this.muted || !this.musicOn) return;
    const t = ac.currentTime + 0.01;
    const pattern = [0, 2, 1, 4, 3, 1, 5, 2];
    const idx = pattern[this.musicStep % pattern.length];
    const scale = [392, 440, 523.25, 587.33, 659.25, 783.99];
    this.osc(ac, {
      type: "triangle",
      f0: scale[idx % scale.length],
      t0: t,
      dur: 0.9,
      peak: 0.09,
      dest: this.musicGain,
    });
    if (this.musicStep % 4 === 0) {
      this.osc(ac, { type: "sine", f0: 130.8, t0: t, dur: 1.4, peak: 0.3, dest: this.musicGain });
    }
    if (this.musicStep % 2 === 1) {
      this.noise(ac, {
        type: "highpass",
        f0: 6200,
        q: 0.8,
        t0: t + 0.22,
        dur: 0.05,
        peak: 0.05,
        dest: this.musicGain!,
      });
    }
    this.musicStep++;
  }
}

export const audio = new AudioEngine();
