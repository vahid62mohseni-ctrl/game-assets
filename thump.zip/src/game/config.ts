import type { KnockType } from "./audio";

export type ItemType = KnockType;
export type Phase = "menu" | "countdown" | "playing" | "paused" | "levelclear" | "roundfailed" | "gameover";

export interface RoundItem {
  id: number;
  type: ItemType;
  value: number; // 0..1  (full = 1, empty = 0)
}

export interface Item extends RoundItem {
  idx: number;
  x: number;
  y: number;
  tx: number;
  ty: number;
  vx: number;
  vy: number;
  w: number;
  h: number;
  homeX: number;
  slotX: number;
  slotIndex: number;
  state: "table" | "held" | "placed";
  slot: number;
  knock: number;
  reveal: number;
  revealTo: number;
  revealTimer: number;
  seed: number;
  hue: number;
  rot: number;
  glow: number;
  bad: number;
  wobble: number;
}

export const TYPE_META: Record<
  ItemType,
  { name: string; sub: string; rule: string; palette: number[]; accent: string }
> = {
  glass: {
    name: "Water glass",
    sub: "Fuller → deeper sound",
    rule: "Flick the glass: the more water, the deeper and longer the sound.",
    palette: [196, 172, 210, 30, 340],
    accent: "#7ad9ff",
  },
  can: {
    name: "Bean can",
    sub: "Fuller can → duller sound",
    rule: "Knock the metal can: a full can sounds dull and deep, an empty one rings and rattles.",
    palette: [36, 12, 150, 92, 268],
    accent: "#ffc453",
  },
  melon: {
    name: "Watermelon",
    sub: "Riper → hollower sound",
    rule: "Tap the watermelon: a ripe one sounds deep and hollow, an unripe one sounds sharp.",
    palette: [110, 96, 128, 84, 140],
    accent: "#64f0c8",
  },
  piggy: {
    name: "Piggy bank",
    sub: "More coins → heavier jingle",
    rule: "Tap the piggy bank: the more coins inside, the fuller and deeper the jingle; one with few coins gives a single high ring.",
    palette: [342, 330, 352, 18, 44],
    accent: "#ffd166",
  },
  head: {
    name: "Human head",
    sub: "More brain → deeper, solid sound",
    rule:
      "Give it a smack: the more brain, the deeper and more solid the skull sounds; an empty head sounds high and hollow.",
    palette: [206, 348, 28, 168, 44],
    accent: "#ff9dc0",
  },
};

export const LIVES_START = 3;
export const LIVES_MAX = 5;
export const MAX_ITEMS = 6;

export function itemSizeFor(type: ItemType, size: number): { w: number; h: number } {
  switch (type) {
    case "glass":
      return { w: size * 0.54, h: size * 1.04 };
    case "can":
      return { w: size * 0.58, h: size * 0.86 };
    case "melon":
      return { w: size * 1.18, h: size * 0.94 };
    case "piggy":
      return { w: size * 1.12, h: size * 1.0 };
    case "head":
      return { w: size * 1.18, h: size * 1.38 };
  }
}

function mulberry32(a: number) {
  return function () {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

export function unlockedTypes(level: number): ItemType[] {
  if (level <= 2) return ["glass"];
  if (level <= 4) return ["glass", "can"];
  if (level <= 6) return ["glass", "can", "melon"];
  return ["glass", "can", "melon", "piggy"];
}

export interface Season {
  type: ItemType;
  label: string;
}

/** Each season has 10 levels; every level uses a single type of object. */
export const LEVELS_PER_SEASON = 10;
export const SEASONS: Season[] = [
  { type: "glass", label: "Season 1 · Glasses" },
  { type: "can", label: "Season 2 · Cans" },
  { type: "melon", label: "Season 3 · Watermelons" },
  { type: "piggy", label: "Season 4 · Piggy banks" },
  { type: "head", label: "Season 5 · Heads" },
];

export function seasonFor(level: number): Season {
  const idx = Math.floor((level - 1) / LEVELS_PER_SEASON) % SEASONS.length;
  return SEASONS[idx];
}

export interface Round {
  items: RoundItem[];
  time: number;
}

/** Builds a round: N objects whose fill values are distinct, gap shrinks with level. */
export function buildRound(level: number): Round {
  const season = seasonFor(level);
  const seasonLevel = ((level - 1) % LEVELS_PER_SEASON) + 1;
  const count =
    season.type === "can"
      ? Math.min(4 + Math.floor((seasonLevel - 1) / 3), MAX_ITEMS)
      : Math.min(3 + Math.floor(level / 2), MAX_ITEMS);
  const minGap = Math.max(0.11, 0.29 - level * 0.018);
  const rnd = mulberry32((Date.now() % 100000) * 7 + level * 131);

  let values: number[] = [];
  for (let attempt = 0; attempt < 400; attempt++) {
    const v = Array.from({ length: count }, () => 0.08 + rnd() * 0.86).sort((a, b) => a - b);
    let ok = true;
    for (let i = 1; i < v.length; i++) if (v[i] - v[i - 1] < minGap) ok = false;
    if (ok) {
      values = v;
      break;
    }
    if (attempt === 399) {
      const lo = 0.12;
      const hi = 0.94;
      values = Array.from({ length: count }, (_, i) => lo + ((hi - lo) * (i + 0.5)) / count);
    }
  }

  // every object in a level belongs to the level's season (one type per level)
  const type = season.type;
  const items: RoundItem[] = values.map((value, i) => ({ id: i, type, value }));
  // shuffle placement order, keep values
  for (let i = items.length - 1; i > 0; i--) {
    const j = Math.floor(rnd() * (i + 1));
    [items[i], items[j]] = [items[j], items[i]];
  }
  return {
    items: items.map((it, i) => ({ ...it, id: i })),
    time: Math.max(16, Math.min(42, 9 + count * 7 - level * 0.6)),
  };
}

export function scoreForPlacement(level: number, combo: number, assist: boolean) {
  const comboMult = 1 + Math.min(combo, 9) * 0.18;
  return Math.round((70 + 14 * level) * comboMult * (assist ? 0.7 : 1));
}

// ---------------- local high scores ----------------
export interface ScoreEntry {
  name: string;
  score: number;
  level: number;
  combo: number;
  date: string;
}

const KEY = "thump.scores.v1";
const NAME_KEY = "thump.name.v1";

export function loadScores(): ScoreEntry[] {
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return [];
    const arr = JSON.parse(raw) as ScoreEntry[];
    if (!Array.isArray(arr)) return [];
    return arr.filter((s) => typeof s?.score === "number").sort((a, b) => b.score - a.score).slice(0, 8);
  } catch {
    return [];
  }
}

export function saveScore(entry: ScoreEntry): ScoreEntry[] {
  const all = [...loadScores(), entry].sort((a, b) => b.score - a.score).slice(0, 8);
  try {
    localStorage.setItem(KEY, JSON.stringify(all));
  } catch {
    /* ignore */
  }
  return all;
}

/** First level of a season (index 0 = season 1). */
export function seasonStartLevel(seasonIndex: number) {
  return seasonIndex * LEVELS_PER_SEASON + 1;
}

export function lastName(): string {
  try {
    return localStorage.getItem(NAME_KEY) || "Player";
  } catch {
    return "Player";
  }
}

export function rememberName(n: string) {
  try {
    localStorage.setItem(NAME_KEY, n);
  } catch {
    /* ignore */
  }
}

export const fmt = (n: number) => n.toLocaleString("en-US");
