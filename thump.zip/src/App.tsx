import { useCallback, useEffect, useRef, useState } from "react";
import { audio } from "./game/audio";
import { Game, type UiState } from "./game/engine";
import { lastName, loadScores, rememberName, saveScore, type ScoreEntry } from "./game/config";
import Hud from "./components/Hud";
import {
  Banner,
  GameOverScreen,
  LevelClearCard,
  PauseScreen,
  RoundFailedCard,
  SplashScreen,
  StartScreen,
} from "./components/Overlays";

const initialUi: UiState = {
  phase: "menu",
  score: 0,
  level: 1,
  lives: 3,
  combo: 0,
  bestCombo: 0,
  timeLeft: 0,
  timeLimit: 30,
  placed: 0,
  total: 4,
  assist: false,
  muted: false,
  music: false,
  banner: null,
  roundSummary: null,
  failedInfo: null,
  totalCorrect: 0,
  totalWrong: 0,
};

export default function App() {
  const wrapRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const gameRef = useRef<Game | null>(null);
  const savedRef = useRef(true);
  const [ui, setUi] = useState<UiState>(initialUi);
  const [showOptions, setShowOptions] = useState(false);
  const [scores, setScores] = useState<ScoreEntry[]>([]);
  const [best, setBest] = useState(0);
  const [name, setName] = useState("Player");
  const [saved, setSaved] = useState(false);
  const [isRecord, setIsRecord] = useState(false);
  const uiRef = useRef(ui);
  uiRef.current = ui;

  // boot
  useEffect(() => {
    const canvas = canvasRef.current;
    const wrap = wrapRef.current;
    if (!canvas || !wrap) return;
    const g = new Game(canvas, setUi);
    gameRef.current = g;
    const ro = new ResizeObserver(() => g.resize());
    ro.observe(wrap);
    const onResize = () => g.resize();
    window.addEventListener("resize", onResize);
    window.addEventListener("orientationchange", onResize);
    const onVisibility = () => {
      if (document.hidden && g.phase === "playing") g.togglePause();
    };
    document.addEventListener("visibilitychange", onVisibility);
    return () => {
      ro.disconnect();
      window.removeEventListener("resize", onResize);
      window.removeEventListener("orientationchange", onResize);
      document.removeEventListener("visibilitychange", onVisibility);
      g.destroy();
      gameRef.current = null;
    };
  }, []);

  useEffect(() => {
    const s = loadScores();
    setScores(s);
    setBest(s[0]?.score ?? 0);
    setName(lastName());
  }, []);

  const prevPhase = useRef<UiState["phase"]>("menu");
  useEffect(() => {
    if (prevPhase.current !== "gameover" && ui.phase === "gameover") {
      setIsRecord(ui.score > 0 && ui.score >= best);
      savedRef.current = false;
      setSaved(false);
    }
    prevPhase.current = ui.phase;
  }, [ui.phase, ui.score, best]);

  const submitScore = useCallback(
    (silent = false) => {
      if (savedRef.current) return;
      const cur = uiRef.current;
      const nm = (name || "Player").trim().slice(0, 14) || "Player";
      rememberName(nm);
      const all = saveScore({
        name: nm,
        score: cur.score,
        level: cur.level,
        combo: cur.bestCombo,
        date: new Date().toISOString().slice(0, 10),
      });
      savedRef.current = true;
      setSaved(true);
      setScores(all);
      setBest((b) => Math.max(b, cur.score));
      if (!silent) audio.sparkle();
    },
    [name],
  );

  const start = useCallback((startLevel?: number) => {
    audio.ensure();
    submitScore(true);
    setShowOptions(false);
    gameRef.current?.startGame(startLevel);
  }, [submitScore]);

  const toMenu = useCallback(() => {
    submitScore(true);
    setShowOptions(false);
    gameRef.current?.toMenu();
  }, [submitScore]);

  const restart = useCallback(() => {
    submitScore(true);
    gameRef.current?.startGame();
  }, [submitScore]);

  // keyboard
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const g = gameRef.current;
      if (!g) return;
      const el = e.target as HTMLElement | null;
      if (el && (el.tagName === "INPUT" || el.tagName === "TEXTAREA")) return;
      if (el?.closest("button") && (e.code === "Enter" || e.code === "Space")) return;
      const phase = uiRef.current.phase;
      const k = e.code;

      if (phase === "menu") {
        if (showOptions && (k === "Escape" || k === "Backspace")) {
          e.preventDefault();
          setShowOptions(false);
          return;
        }
        if (!showOptions && k === "KeyO") {
          e.preventDefault();
          setShowOptions(true);
          return;
        }
        if (!showOptions && (k === "Enter" || k === "Space") && el?.tagName !== "BUTTON") {
          e.preventDefault();
          start();
        }
        return;
      }
      if (phase === "levelclear" || phase === "roundfailed") {
        if (k === "Enter" || k === "Space") {
          e.preventDefault();
          g.continueNow();
        }
        return;
      }
      if (phase === "gameover") {
        if (k === "KeyR" || k === "Enter" || k === "Space") {
          e.preventDefault();
          restart();
        } else if (k === "Escape") toMenu();
        return;
      }
      if (k === "KeyP" || k === "Escape") {
        e.preventDefault();
        g.togglePause();
        return;
      }
      if (phase === "paused") {
        if (k === "KeyR") {
          e.preventDefault();
          g.restartLevel();
        }
        return;
      }
      switch (k) {
        case "Space":
        case "ArrowUp":
          e.preventDefault();
          g.cursorListen();
          break;
        case "Enter":
        case "ArrowDown":
          e.preventDefault();
          g.cursorPlace();
          break;
        case "ArrowLeft":
          e.preventDefault();
          g.moveCursor(-1);
          break;
        case "ArrowRight":
          e.preventDefault();
          g.moveCursor(1);
          break;
        case "Tab":
          break;
        case "KeyR":
          e.preventDefault();
          g.restartLevel();
          break;
        case "KeyA":
          g.setAssist(!uiRef.current.assist);
          break;
        case "KeyM":
          g.setMuted(!uiRef.current.muted);
          break;
        default: {
          let n = -1;
          if (k.startsWith("Digit")) n = Number(k.slice(5)) - 1;
          else if (k.startsWith("Numpad")) n = Number(k.slice(6)) - 1;
          if (n >= 0 && n < uiRef.current.total) {
            e.preventDefault();
            g.selectIndex(n);
          }
        }
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [start, restart, toMenu, showOptions]);

  const local = (e: React.PointerEvent<HTMLCanvasElement>) => {
    const r = e.currentTarget.getBoundingClientRect();
    return { x: e.clientX - r.left, y: e.clientY - r.top };
  };

  return (
    <div dir="ltr" data-phase={ui.phase} className="fixed inset-0 overflow-hidden bg-night-900 font-body">
      <div ref={wrapRef} className="absolute inset-0">
        <canvas
          ref={canvasRef}
          className="size-full"
          aria-label="Thump game board; select with the arrow keys, listen with Space and place with Enter."
          role="img"
          onPointerDown={(e) => {
            e.currentTarget.setPointerCapture(e.pointerId);
            const p = local(e);
            gameRef.current?.onPointerDown(p.x, p.y);
          }}
          onPointerMove={(e) => {
            const p = local(e);
            gameRef.current?.pointerMove(p.x, p.y);
          }}
          onPointerUp={(e) => {
            const p = local(e);
            gameRef.current?.pointerUp(p.x, p.y);
          }}
          onPointerCancel={() => gameRef.current?.pointerUp(0, -999)}
          onContextMenu={(e) => e.preventDefault()}
        />
      </div>

      {/* readability scrim */}
      <div className="pointer-events-none absolute inset-x-0 top-0 h-28 bg-gradient-to-b from-night-900/85 to-transparent" />

      {ui.phase !== "menu" && (
        <Hud
          ui={ui}
          onPause={() => gameRef.current?.togglePause()}
        />
      )}
      {ui.phase === "playing" && <Banner ui={ui} />}
      {ui.phase !== "menu" && (
        <p className="pointer-events-none absolute inset-x-0 bottom-[max(0.75rem,env(safe-area-inset-bottom))] z-20 px-3 text-center font-display text-sm text-cream text-shadow-hard sm:text-base">
          Arrange from full (right) to empty (left)
        </p>
      )}
      {ui.phase === "levelclear" && <LevelClearCard ui={ui} onContinue={() => gameRef.current?.continueNow()} />}
      {ui.phase === "roundfailed" && <RoundFailedCard ui={ui} onRetry={() => gameRef.current?.continueNow()} />}

      {ui.phase === "menu" && !showOptions && (
        <SplashScreen onPlay={() => start()} onOption={() => setShowOptions(true)} />
      )}
      {ui.phase === "menu" && showOptions && (
        <StartScreen
          scores={scores}
          best={best}
          assist={ui.assist}
          onAssist={() => gameRef.current?.setAssist(!ui.assist)}
          music={ui.music}
          onMusic={() => gameRef.current?.setMusic(!ui.music)}
          onStart={start}
          onBack={() => setShowOptions(false)}
        />
      )}
      {ui.phase === "paused" && (
        <PauseScreen
          onResume={() => gameRef.current?.togglePause()}
          onRestart={() => {
            gameRef.current?.togglePause();
            gameRef.current?.restartLevel();
          }}
          onMenu={toMenu}
        />
      )}
      {ui.phase === "gameover" && (
        <GameOverScreen
          ui={ui}
          best={Math.max(best, ui.score)}
          isRecord={isRecord}
          scores={saved ? scores : [...scores].sort((a, b) => b.score - a.score)}
          name={name}
          setName={setName}
          saved={saved}
          onSave={() => submitScore()}
          onRestart={restart}
          onMenu={toMenu}
        />
      )}
    </div>
  );
}
