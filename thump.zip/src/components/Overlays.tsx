import {
  ArrowLeft,
  Keyboard,
  MousePointer2,
  PartyPopper,
  Play,
  RotateCcw,
  Trophy,
  Volume2,
  VolumeX,
  Hand,
  Waves,
  Layers,
  Settings2,
  Maximize,
  Minimize,
  GlassWater,
  Cylinder,
  Citrus,
  PiggyBank,
  Brain,
} from "lucide-react";
import { useEffect, useState } from "react";
import type { UiState } from "../game/engine";
import { embeddedAssets } from "../embeddedAssets";
import { LEVELS_PER_SEASON, SEASONS, TYPE_META, fmt, seasonStartLevel, type ScoreEntry } from "../game/config";
import ScoreBoard from "./ScoreBoard";

const menuPosterUrl = embeddedAssets.poster;
const num = (n: number) => Math.round(n).toLocaleString("en-US");

export function Overlay({ children, dim = 0.78 }: { children: React.ReactNode; dim?: number }) {
  return (
    <div
      className="absolute inset-0 z-30 grid place-items-center overflow-y-auto p-3"
      style={{
        background: `radial-gradient(120% 80% at 50% 0%, rgba(9,20,36,${dim * 0.75}) 0%, rgba(6,12,22,${dim}) 70%)`,
        backdropFilter: "blur(3px)",
      }}
    >
      {children}
    </div>
  );
}

function Wave({ period, color, label }: { period: number; color: string; label: string }) {
  const pts: string[] = [];
  for (let x = 0; x <= 160; x += 2) {
    pts.push(`${x === 0 ? "M" : "L"}${x},${12 + Math.sin((x / period) * Math.PI * 2) * 8}`);
  }
  return (
    <div className="flex items-center gap-2">
      <svg viewBox="0 0 160 24" className="h-6 w-full max-w-40" fill="none">
        <path d={pts.join(" ")} stroke={color} strokeWidth="2.6" strokeLinecap="round" />
      </svg>
      <span className="shrink-0 font-display text-sm" style={{ color }}>
        {label}
      </span>
    </div>
  );
}

function Step({ n, title, text }: { n: number; title: string; text: string }) {
  return (
    <li className="flex gap-3">
      <span className="mt-0.5 grid size-7 shrink-0 place-items-center rounded-lg bg-night-700 font-display text-base text-amber-glow">
        {num(n)}
      </span>
      <span className="text-sm leading-6 text-cream/80">
        <b className="font-display text-base font-normal text-cream">{title}</b> — {text}
      </span>
    </li>
  );
}

export function SplashScreen({
  onPlay,
  onOption,
}: {
  onPlay: () => void;
  onOption: () => void;
}) {
  const fullscreenDocument = document as Document & {
    webkitFullscreenElement?: Element | null;
    webkitExitFullscreen?: () => Promise<void> | void;
  };
  const fullscreenRoot = document.documentElement as HTMLElement & {
    webkitRequestFullscreen?: () => Promise<void> | void;
  };
  const [fullscreen, setFullscreen] = useState(() =>
    Boolean(fullscreenDocument.fullscreenElement || fullscreenDocument.webkitFullscreenElement),
  );
  const [fullscreenError, setFullscreenError] = useState("");

  useEffect(() => {
    const update = () => {
      setFullscreen(Boolean(fullscreenDocument.fullscreenElement || fullscreenDocument.webkitFullscreenElement));
      setFullscreenError("");
    };
    document.addEventListener("fullscreenchange", update);
    document.addEventListener("webkitfullscreenchange", update);
    return () => {
      document.removeEventListener("fullscreenchange", update);
      document.removeEventListener("webkitfullscreenchange", update);
    };
  }, [fullscreenDocument]);

  const toggleFullscreen = async () => {
    setFullscreenError("");
    try {
      if (fullscreenDocument.fullscreenElement) await fullscreenDocument.exitFullscreen();
      else if (fullscreenDocument.webkitFullscreenElement && fullscreenDocument.webkitExitFullscreen) {
        await fullscreenDocument.webkitExitFullscreen();
      } else if (fullscreenRoot.requestFullscreen) {
        await fullscreenRoot.requestFullscreen();
      } else if (fullscreenRoot.webkitRequestFullscreen) {
        await fullscreenRoot.webkitRequestFullscreen();
      } else {
        setFullscreenError("Fullscreen is not supported in this browser.");
        return;
      }
      setFullscreen(Boolean(fullscreenDocument.fullscreenElement || fullscreenDocument.webkitFullscreenElement));
    } catch {
      setFullscreenError("The browser blocked fullscreen; try opening the game in its own tab.");
    }
  };

  return (
    <main className="splash absolute inset-0 z-30 overflow-hidden bg-night-900" aria-labelledby="game-title">
      <img
        src={menuPosterUrl}
        alt=""
        aria-hidden="true"
        draggable={false}
        fetchPriority="high"
        className="splash-art absolute inset-0 size-full object-cover object-center"
      />
      <div className="splash-shade pointer-events-none absolute inset-0" />

      <header className="splash-header">
        <button
          type="button"
          className="splash-icon"
          onClick={toggleFullscreen}
          aria-label={fullscreen ? "Exit fullscreen" : "Fullscreen"}
          title={fullscreen ? "Exit fullscreen" : "Fullscreen"}
          aria-pressed={fullscreen}
        >
          {fullscreen ? <Minimize size={19} /> : <Maximize size={19} />}
        </button>
        {fullscreenError && (
          <p role="status" className="pointer-events-none absolute left-0 top-full mt-3 max-w-64 text-xs leading-6 text-cream text-shadow-hard">
            {fullscreenError}
          </p>
        )}
      </header>

      <section className="splash-content" aria-label="Game menu">
        <button onClick={onPlay} className="splash-play" aria-label="Start game">
          <Play size={23} fill="currentColor" strokeWidth={1.5} aria-hidden="true" />
          <span>Start Game</span>
        </button>
        <button onClick={onOption} className="splash-options" aria-label="Help and settings">
          <Settings2 size={18} aria-hidden="true" />
          Help &amp; Settings
        </button>
      </section>

      <div className="splash-motes pointer-events-none absolute inset-0" aria-hidden="true">
        {Array.from({ length: 9 }, (_, i) => <i key={i} style={{ left: `${14 + i * 9}%`, animationDelay: `${i * -1.3}s`, animationDuration: `${8 + i % 4}s` }} />)}
      </div>
    </main>
  );
}

export function StartScreen({
  scores,
  best,
  assist,
  onAssist,
  music,
  onMusic,
  onStart,
  onBack,
}: {
  scores: ScoreEntry[];
  best: number;
  assist: boolean;
  onAssist: () => void;
  music: boolean;
  onMusic: () => void;
  onStart: (startLevel?: number) => void;
  onBack: () => void;
}) {
  const SEASON_ICON = { glass: GlassWater, can: Cylinder, piggy: PiggyBank, melon: Citrus, head: Brain };
  const legend = SEASONS.map((season, index) => ({ k: season.type, at: seasonStartLevel(index) }));
  return (
    <Overlay>
      <div className="anim-pop panel grid w-full max-w-4xl gap-5 rounded-3xl p-5 sm:p-7 md:grid-cols-[1.05fr_0.95fr]">
        {/* title + CTA */}
        <div className="flex flex-col">
          <div className="mb-3 flex items-center justify-between gap-2">
            <button
              onClick={onBack}
              className="btn-3d rounded-xl border border-cream/15 bg-night-900/55 px-3 py-1.5 text-sm text-cream/75"
            >
              <ArrowLeft className="me-1 inline size-4" /> Back
            </button>
            <div className="flex items-center gap-2">
              <span className="anim-glow rounded-full bg-amber-glow/15 px-3 py-1 font-display text-xs text-amber-glow ring-1 ring-amber-glow/40">
                Options &amp; Seasons
              </span>
              {best > 0 && (
                <span className="rounded-full bg-mint/12 px-3 py-1 text-xs text-mint ring-1 ring-mint/30">
                  Your best {fmt(best)}
                </span>
              )}
            </div>
          </div>
          <h1 className="font-display text-6xl leading-[0.95] text-cream text-shadow-hard sm:text-7xl">
            Thump
          </h1>
          <p className="mt-2 max-w-md text-[15px] leading-7 text-cream/70">
            The objects are filled to different levels, but you can&apos;t see inside. Just{" "}
            <b className="text-cream">knock</b> and <b className="text-cream">listen</b> to work out which one is
            fuller, then line them up on the shelf from full to empty.
          </p>

          <div className="mt-4 rounded-2xl border border-amber-glow/25 bg-night-900/50 p-3.5">
            <div className="mb-2 flex items-center gap-2 font-display text-lg text-amber-glow">
              <Waves className="size-4" /> Golden rule
            </div>
            <Wave period={34} color="#7ad9ff" label="Full → deep" />
            <div className="my-1.5 h-px bg-cream/10" />
            <Wave period={9} color="#64f0c8" label="Empty → high" />
            <p className="mt-2 text-xs leading-5 text-cream/55">
              The fuller an object is, the slower it vibrates and the deeper it sounds. A ripe watermelon sounds deeper and hollower too.
            </p>
          </div>

          {/* season picker — every season is open from the start */}
          <div className="mt-4 rounded-2xl border border-grape/30 bg-night-900/50 p-3.5">
            <div className="mb-2.5 flex items-center gap-2">
              <Layers className="size-4 text-grape" />
              <span className="font-display text-lg text-cream">Choose a season</span>
              <span className="rounded-full bg-grape/18 px-2 py-0.5 text-[10px] text-grape">
                All unlocked · {num(LEVELS_PER_SEASON)} levels per season
              </span>
            </div>
            <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
              {SEASONS.map((s, i) => {
                const meta = TYPE_META[s.type];
                const first = seasonStartLevel(i);
                const SeasonIcon = SEASON_ICON[s.type];
                return (
                  <button
                    key={s.type}
                    onClick={() => onStart(first)}
                    className={`btn-3d group rounded-2xl border border-cream/12 bg-night-800/70 p-2.5 text-left hover:border-amber-glow/60 ${
                      i === 4 ? "col-span-2 border-[#ff9dc0]/45 bg-[#ff9dc0]/10 sm:col-span-4" : ""
                    }`}
                  >
                    <div className="flex items-center gap-2">
                      <span className="grid size-8 shrink-0 place-items-center rounded-xl bg-night-900/70 text-lg">
                        <SeasonIcon className="size-5" style={{ color: meta.accent }} aria-hidden="true" />
                      </span>
                      <span className="min-w-0">
                        <span className="block font-display text-sm leading-tight text-cream">
                          Season {num(i + 1)}
                        </span>
                        <span className="block truncate text-[10px] text-cream/50">{meta.name}</span>
                      </span>
                    </div>
                    <div className="mt-1.5 text-[10px] leading-4 text-cream/55">{meta.sub}</div>
                    <div
                      className="mt-1.5 h-1 w-full rounded-full"
                      style={{ background: `linear-gradient(90deg, ${meta.accent}, transparent)` }}
                    />
                    <div className="mt-1 font-display text-[11px] text-amber-glow/85">
                      Levels {num(first)}–{num(first + LEVELS_PER_SEASON - 1)}
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          <div className="mt-4 flex flex-wrap items-center gap-2.5">
            <button
              onClick={() => onStart()}
              className="btn-3d flex items-center gap-2 rounded-2xl bg-amber-glow px-7 py-3.5 font-display text-2xl text-night-900 shadow-[0_8px_0_0_#b9832f,0_20px_36px_-12px_rgba(255,196,83,.6)] active:shadow-[0_4px_0_0_#b9832f]"
            >
              <Play className="size-6 fill-current" />
              Start Game
            </button>
            <button
              onClick={onAssist}
              aria-pressed={assist}
              className={`btn-3d rounded-2xl border px-3.5 py-3 text-sm ${
                assist ? "border-mint/60 bg-mint/20 text-mint" : "border-cream/15 bg-night-900/50 text-cream/70"
              }`}
            >
              Sound line (assist) {assist ? "ON" : "OFF"}
            </button>
            <button
              onClick={onMusic}
              className="btn-3d grid size-11 place-items-center rounded-2xl border border-cream/15 bg-night-900/50 text-cream/70"
              aria-label="Music"
              aria-pressed={music}
            >
              {music ? <Volume2 className="size-5" /> : <VolumeX className="size-5" />}
            </button>
          </div>
          <p className="mt-2 text-[11px] text-cream/40">
            The sound line makes the game easier, but scores 30% less.
          </p>
        </div>

        {/* how to + scores */}
        <div className="flex flex-col gap-4">
          <div className="rounded-2xl border border-cream/12 bg-night-900/45 p-4">
            <div className="mb-3 flex items-center gap-2 font-display text-lg text-cream">
              <Keyboard className="size-4 text-mint" /> How to play
            </div>
            <ol className="space-y-2.5">
              <Step n={1} title="Knock & listen" text="Click any object to hear it being knocked." />
              <Step
                n={2}
                title="Hold it"
                text="One tap lifts the object and keeps it in your hand; tap it again to listen again."
              />
              <Step
                n={3}
                title="Drag it onto the shelf"
                text="Drag it to the shelf and let go (or press Enter) to drop it into the next slot."
              />
              <Step
                n={4}
                title="Full to empty"
                text="Arrange from the fullest (right) to the emptiest (left). A mistake costs one life."
              />
            </ol>
            <div className="mt-3 flex flex-wrap items-center gap-1.5 text-[11px]">
              <span className="flex items-center gap-1 rounded-lg bg-night-700 px-2 py-1 text-cream/70">
                <MousePointer2 className="size-3" /> Click
              </span>
              <span className="flex items-center gap-1 rounded-lg bg-night-700 px-2 py-1 text-cream/70">
                <Hand className="size-3" /> Drag
              </span>
              <span className="rounded-lg bg-night-700 px-2 py-1 font-mono text-cream/70">Space</span>
              <span className="rounded-lg bg-night-700 px-2 py-1 font-mono text-cream/70">Enter</span>
              <span className="rounded-lg bg-night-700 px-2 py-1 font-mono text-cream/70">1…6</span>
              <span className="rounded-lg bg-night-700 px-2 py-1 font-mono text-cream/70">P</span>
            </div>
          </div>

          <div className="rounded-2xl border border-cream/12 bg-night-900/45 p-4">
            <div className="mb-2.5 font-display text-lg text-cream">Sound toolbox</div>
            <div className="grid grid-cols-2 gap-2">
              {legend.map(({ k, at }) => (
                <div
                  key={k}
                  className={`rounded-xl border px-2.5 py-2 ${
                    k === "glass" ? "border-mint/35 bg-mint/8" : "border-cream/10 bg-night-800/60"
                  }`}
                >
                  <div className="flex items-center justify-between gap-1">
                    <span className="font-display text-sm text-cream">{TYPE_META[k].name}</span>
                    <span className="text-[10px] text-cream/45">{at > 1 ? `Level ${num(at)}` : "From the start"}</span>
                  </div>
                  <div className="mt-0.5 text-[11px] leading-4 text-cream/55">{TYPE_META[k].sub}</div>
                </div>
              ))}
            </div>
          </div>

          <div className="rounded-2xl border border-cream/12 bg-night-900/45 p-4">
            <ScoreBoard scores={scores} />
          </div>
        </div>
      </div>
    </Overlay>
  );
}

export function PauseScreen({
  onResume,
  onRestart,
  onMenu,
}: {
  onResume: () => void;
  onRestart: () => void;
  onMenu: () => void;
}) {
  return (
    <Overlay dim={0.72}>
      <div className="anim-pop panel w-full max-w-md rounded-3xl p-6 text-center">
        <div className="font-display text-5xl text-cream">Paused</div>
        <div className="mt-5 grid gap-3">
          <button
            onClick={onResume}
            className="btn-3d mx-auto flex w-full items-center justify-center gap-2 rounded-2xl bg-amber-glow px-6 py-3 font-display text-xl text-night-900 shadow-[0_6px_0_0_#b9832f]"
          >
            <Play className="size-5 fill-current" /> Resume
          </button>
          <button
            onClick={onRestart}
            className="btn-3d mx-auto flex w-full items-center justify-center gap-2 rounded-2xl bg-amber-glow px-6 py-3 font-display text-xl text-night-900 shadow-[0_6px_0_0_#b9832f]"
          >
            <RotateCcw className="size-5" /> Restart level
          </button>
          <button
            onClick={onMenu}
            className="btn-3d mx-auto flex w-full items-center justify-center gap-2 rounded-2xl bg-amber-glow px-6 py-3 font-display text-xl text-night-900 shadow-[0_6px_0_0_#b9832f]"
          >
            <ArrowLeft className="size-5" /> Main menu
          </button>
        </div>
      </div>
    </Overlay>
  );
}

export function GameOverScreen({
  ui,
  best,
  isRecord,
  scores,
  name,
  setName,
  onSave,
  saved,
  onRestart,
  onMenu,
}: {
  ui: UiState;
  best: number;
  isRecord: boolean;
  scores: ScoreEntry[];
  name: string;
  setName: (v: string) => void;
  onSave: () => void;
  saved: boolean;
  onRestart: () => void;
  onMenu: () => void;
}) {
  return (
    <Overlay dim={0.8}>
      <div className="anim-pop panel grid w-full max-w-3xl gap-5 rounded-3xl p-6 sm:grid-cols-[1.05fr_0.95fr]">
        <div>
          <div className="font-display text-5xl text-berry text-shadow-hard">Game over</div>
          {isRecord ? (
            <div className="shine mt-3 inline-flex items-center gap-2 rounded-full bg-amber-glow px-4 py-1.5 font-display text-lg text-night-900">
              <PartyPopper className="size-5" /> New record!
            </div>
          ) : (
            <div className="mt-3 inline-flex items-center gap-2 rounded-full bg-night-900/60 px-4 py-1.5 text-sm text-cream/65">
              <Trophy className="size-4 text-amber-glow" /> Best score {fmt(best)}
            </div>
          )}
          <div className="mt-4 rounded-2xl border border-cream/12 bg-night-900/50 p-4">
            <div className="text-[11px] text-cream/50">Final score</div>
            <div className="font-display text-6xl leading-none tabular-nums text-cream">{fmt(ui.score)}</div>
            <div className="mt-3 grid grid-cols-2 gap-2 text-center sm:grid-cols-4">
              {[
                ["Level", num(ui.level)],
                ["Best combo", `${num(ui.bestCombo)}×`],
                ["Correct", num(ui.totalCorrect)],
                ["Wrong", num(ui.totalWrong)],
              ].map(([l, v]) => (
                <div key={l} className="rounded-xl bg-night-800/70 px-2 py-1.5">
                  <div className="font-display text-xl text-amber-glow">{v}</div>
                  <div className="text-[10px] text-cream/50">{l}</div>
                </div>
              ))}
            </div>
          </div>

          <div className="mt-3 flex items-center gap-2">
            <input
              value={name}
              aria-label="Player name"
              maxLength={14}
              onChange={(e) => setName(e.target.value)}
              placeholder="Enter your name"
              className="min-w-0 flex-1 rounded-xl border border-cream/15 bg-night-900/70 px-3 py-2.5 text-sm text-cream outline-none placeholder:text-cream/35 focus:border-amber-glow/60"
            />
            <button
              onClick={onSave}
              disabled={saved}
              className="btn-3d shrink-0 rounded-xl border border-amber-glow/50 bg-amber-glow/18 px-4 py-2.5 text-sm text-amber-glow disabled:opacity-45"
            >
              {saved ? "Saved" : "Save score"}
            </button>
          </div>

          <div className="mt-3 flex gap-2">
            <button
              onClick={onRestart}
              className="btn-3d flex flex-1 basis-0 items-center justify-center gap-2 rounded-2xl bg-amber-glow px-5 py-3 font-display text-xl text-night-900 shadow-[0_6px_0_0_#b9832f]"
            >
              <RotateCcw className="size-5" /> Play again
            </button>
            <button
              onClick={onMenu}
              className="btn-3d flex flex-1 basis-0 items-center justify-center gap-2 rounded-2xl bg-amber-glow px-5 py-3 font-display text-xl text-night-900 shadow-[0_6px_0_0_#b9832f]"
            >
              <ArrowLeft className="size-5" /> Main menu
            </button>
          </div>
        </div>

        <div className="rounded-2xl border border-cream/12 bg-night-900/45 p-4">
          <ScoreBoard scores={scores} />
        </div>
      </div>
    </Overlay>
  );
}

/** Shown after a wrong full arrangement: objects stay revealed until retry is pressed. */
export function RoundFailedCard({ ui, onRetry }: { ui: UiState; onRetry: () => void }) {
  const f = ui.failedInfo;
  return (
    <div className="pointer-events-none absolute inset-x-0 top-28 z-[25] flex justify-center px-3 sm:top-32">
      <div className="anim-pop panel pointer-events-auto w-full max-w-md rounded-3xl p-5 text-center">
        <div className="font-display text-4xl text-berry">Not quite!</div>
        <p className="mt-1 text-sm text-cream/65">
          You lost this round — look inside each one to see how full it was; the ones that turned red were in the wrong place.
        </p>
        <div className="mt-3 flex items-stretch justify-center gap-2">
          {[
            ["Correctly placed", `${num(f?.correct ?? 0)} of ${num(f?.total ?? ui.total)}`],
            ["Lives left", num(ui.lives)],
            ["Total score", fmt(ui.score)],
          ].map(([l, v]) => (
            <div key={l} className="flex-1 rounded-xl bg-night-900/60 px-2 py-2">
              <div className="font-display text-lg text-amber-glow">{v}</div>
              <div className="text-[10px] text-cream/50">{l}</div>
            </div>
          ))}
        </div>
        <button
          onClick={onRetry}
          className="btn-3d mt-4 w-full rounded-2xl bg-amber-glow px-5 py-2.5 font-display text-lg text-night-900 shadow-[0_5px_0_0_#b9832f]"
        >
          Try again →
        </button>
      </div>
    </div>
  );
}

export function LevelClearCard({ ui, onContinue }: { ui: UiState; onContinue: () => void }) {
  const s = ui.roundSummary;
  return (
    <div className="pointer-events-none absolute inset-x-0 top-28 z-[25] flex justify-center px-3 sm:top-32">
      <div className="anim-pop panel pointer-events-auto w-full max-w-md rounded-3xl p-5 text-center">
        <div className="font-display text-4xl text-mint">{s?.perfect ? "Perfect arrangement!" : "Level complete!"}</div>
        <div className="mt-3 flex items-stretch justify-center gap-2">
          {[
            ["Arrangement bonus", fmt(s?.bonus ?? 0)],
            ["Time bonus", fmt(s?.timeBonus ?? 0)],
            ["Total score", fmt(ui.score)],
          ].map(([l, v]) => (
            <div key={l} className="flex-1 rounded-xl bg-night-900/60 px-2 py-2">
              <div className="font-display text-lg text-amber-glow">{v}</div>
              <div className="text-[10px] text-cream/50">{l}</div>
            </div>
          ))}
        </div>
        <button
          onClick={onContinue}
          className="btn-3d mt-4 w-full rounded-2xl bg-mint px-5 py-2.5 font-display text-lg text-night-900 shadow-[0_5px_0_0_#2fae8d]"
        >
          Next level →
        </button>
      </div>
    </div>
  );
}

export function Banner({ ui }: { ui: UiState }) {
  if (!ui.banner) return null;
  const tone =
    ui.banner.tone === "good"
      ? "border-mint/45 bg-mint/15 text-mint"
      : ui.banner.tone === "bad"
        ? "border-berry/45 bg-berry/15 text-berry"
        : "border-amber-glow/45 bg-amber-glow/12 text-amber-glow";
  return (
    <div className="pointer-events-none absolute inset-x-0 top-28 z-20 grid place-items-center sm:top-32">
      <div key={ui.banner.title + ui.banner.sub} className={`anim-slide rounded-2xl border px-5 py-2 text-center ${tone} bg-night-900/70`}>
        <div className="font-display text-2xl leading-tight">{ui.banner.title}</div>
        {ui.banner.sub && <div className="text-[12px] leading-5 text-cream/70">{ui.banner.sub}</div>}
      </div>
    </div>
  );
}

