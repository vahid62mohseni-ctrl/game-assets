import { Pause, Sparkles } from "lucide-react";
import { embeddedAssets } from "../embeddedAssets";
import type { UiState } from "../game/engine";

const heartUrl = embeddedAssets.heart;
const num = (n: number) => Math.round(n).toLocaleString("en-US");

function IconButton({
  label,
  onClick,
  children,
}: {
  label: string;
  onClick: () => void;
  children: React.ReactNode;
}) {
  return (
    <button
      onClick={onClick}
      title={label}
      aria-label={label}
      className="btn-3d grid size-10 place-items-center rounded-xl border border-cream/15 bg-night-900/55 text-cream/75 hover:text-cream sm:size-11"
    >
      {children}
    </button>
  );
}

export default function Hud({
  ui,
  onPause,
}: {
  ui: UiState;
  onPause: () => void;
}) {
  const pct = ui.timeLimit ? Math.max(0, Math.min(1, ui.timeLeft / ui.timeLimit)) : 1;
  const danger = ui.timeLeft <= 6;
  const barColor = pct > 0.55 ? "bg-mint" : pct > 0.25 ? "bg-amber-glow" : "bg-berry";
  const playing =
    ui.phase === "playing" || ui.phase === "paused" || ui.phase === "levelclear" || ui.phase === "roundfailed";

  return (
    <div className="pointer-events-none absolute inset-x-0 top-0 z-20 select-none p-2 sm:p-3">
      <div className="mx-auto flex w-full max-w-md flex-col items-center">
        <div className="chip flex items-center rounded-2xl px-3.5 py-1.5">
          <span className="font-display text-xl leading-none text-cream/90 sm:text-2xl">
            Level {num(ui.level)}
          </span>
        </div>
        {ui.combo >= 2 && (
          <div
            key={ui.combo}
            className="anim-pop mt-1 flex items-center gap-1 rounded-full bg-mint/20 px-2.5 py-0.5 text-mint ring-1 ring-mint/45"
          >
            <Sparkles className="size-3.5" />
            <span className="font-display text-sm leading-none">Combo {num(ui.combo)}×</span>
          </div>
        )}
        <div className="mt-1.5 flex w-full max-w-64 items-center gap-2">
          <div className="relative h-2.5 flex-1 overflow-hidden rounded-full bg-night-900/70 ring-1 ring-cream/12">
            <div
              className={`h-full rounded-full transition-[width] duration-150 ease-linear ${barColor} ${
                danger ? "animate-pulse" : ""
              }`}
              style={{ width: `${pct * 100}%` }}
            />
          </div>
          <span
            className={`font-display text-sm leading-none tabular-nums ${danger ? "text-berry" : "text-cream/70"}`}
          >
            {num(ui.timeLeft)}s
          </span>
        </div>
      </div>

      <div className="pointer-events-auto absolute top-2 left-2 sm:top-3 sm:left-3">
        <IconButton label="Pause (P)" onClick={onPause}>
          <Pause className="size-5" />
        </IconButton>
      </div>

      <div className="absolute top-2 right-2 flex flex-row-reverse flex-wrap items-center gap-1.5 sm:top-3 sm:right-3">
        {Array.from({ length: Math.max(ui.lives, 3) }).map((_, i) => (
          <img
            key={i}
            src={heartUrl}
            alt=""
            aria-hidden="true"
            draggable={false}
            className={`h-8 w-auto shrink-0 transition-all sm:h-9 ${
              i < ui.lives ? "scale-100 drop-shadow-[0_2px_6px_rgba(255,60,85,.55)]" : "opacity-25 grayscale"
            }`}
          />
        ))}
      </div>

      {/* slot progress */}
      {playing && (
        <div className="mx-auto mt-1.5 flex w-fit items-center gap-1.5 rounded-full bg-night-900/45 px-3 py-1 ring-1 ring-cream/10">
          <span className="font-display text-xs text-cream/60">Shelf</span>
          {Array.from({ length: ui.total }).map((_, i) => (
            <span
              key={i}
              className={`size-2 rounded-full transition-all duration-200 ${
                i < ui.placed ? "scale-110 bg-mint shadow-[0_0_8px_rgba(100,240,200,.8)]" : "bg-cream/20"
              }`}
            />
          ))}
          <span className="ms-1 font-display text-xs text-mint/90">
            {num(ui.placed)}/{num(ui.total)}
          </span>
        </div>
      )}
    </div>
  );
}
