import { Crown } from "lucide-react";
import type { ScoreEntry } from "../game/config";
import { fmt } from "../game/config";

const num = (n: number) => n.toLocaleString("en-US");

export default function ScoreBoard({ scores, compact = false }: { scores: ScoreEntry[]; compact?: boolean }) {
  return (
    <div className="w-full">
      {!compact && (
        <div className="mb-2 flex items-center gap-2 text-cream/70">
          <Crown className="size-4 text-amber-glow" />
          <span className="font-display text-lg">High scores</span>
        </div>
      )}
      {scores.length === 0 ? (
        <div className="rounded-xl border border-dashed border-cream/25 px-3 py-4 text-center text-sm text-cream/55">
          No scores yet — be the first!
        </div>
      ) : (
        <ol className="space-y-1.5">
          {scores.slice(0, compact ? 5 : 8).map((s, i) => (
            <li
              key={`${s.name}-${s.score}-${i}`}
              className={`flex items-center gap-3 rounded-xl px-3 py-1.5 transition ${
                i === 0
                  ? "bg-amber-glow/18 text-cream shadow-[inset_0_1px_0_rgba(255,255,255,.18)]"
                  : i < 3
                    ? "bg-cream/8 text-cream/95"
                    : "bg-cream/4 text-cream/75"
              }`}
            >
              <span
                className={`grid size-6 shrink-0 place-items-center rounded-lg font-display text-sm ${
                  i === 0 ? "bg-amber-glow text-night-900" : "bg-night-700 text-cream/80"
                }`}
              >
                {num(i + 1)}
              </span>
              <span className="min-w-0 flex-1 truncate text-sm font-semibold">{s.name}</span>
              <span className="text-[11px] text-cream/45">Level {num(s.level)}</span>
              <span className="font-display text-lg tabular-nums leading-none">{fmt(s.score)}</span>
            </li>
          ))}
        </ol>
      )}
    </div>
  );
}
