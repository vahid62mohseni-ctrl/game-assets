import { audio, AudioEngine } from "./audio";
import {
  buildRound,
  itemSizeFor,
  LIVES_MAX,
  LIVES_START,
  scoreForPlacement,
  seasonFor,
  TYPE_META,
  type Item,
  type Phase,
  type RoundItem,
  unlockedTypes,
} from "./config";
import { drawAssist, drawItemBody, drawKnockFx, makeBackdrop, makeGlowSprite, rng } from "./draw";

export interface UiState {
  phase: Phase;
  score: number;
  level: number;
  lives: number;
  combo: number;
  bestCombo: number;
  timeLeft: number;
  timeLimit: number;
  placed: number;
  total: number;
  assist: boolean;
  muted: boolean;
  music: boolean;
  banner: { title: string; sub: string; tone: "good" | "bad" | "info" } | null;
  roundSummary: { bonus: number; timeBonus: number; perfect: boolean } | null;
  failedInfo: { correct: number; total: number } | null;
  totalCorrect: number;
  totalWrong: number;
}

interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  life: number;
  max: number;
  size: number;
  color: string;
  kind: "drop" | "star" | "grain" | "spark" | "ring" | "confetti";
  rot: number;
  vr: number;
  g: number;
}

interface Popup {
  x: number;
  y: number;
  text: string;
  life: number;
  max: number;
  color: string;
  size: number;
}

interface Dust {
  x: number;
  y: number;
  r: number;
  s: number;
  p: number;
}

const HOLD_LIMIT = 2.6;

export class Game {
  private canvas: HTMLCanvasElement;
  private ctx: CanvasRenderingContext2D;
  private raf = 0;
  private last = 0;
  private W = 0;
  private H = 0;
  private dpr = 1;
  private bg: HTMLCanvasElement | null = null;
  private glow = makeGlowSprite(120, "255,214,140");
  private glowMint = makeGlowSprite(120, "110,240,210");

  phase: Phase = "menu";
  items: Item[] = [];
  private particles: Particle[] = [];
  private popups: Popup[] = [];
  private dust: Dust[] = [];
  private rings: { x: number; y: number; r: number; max: number; life: number; color: string; w: number }[] = [];

  private counterY = 0;
  private rowY = 0;
  private shelfY = 0;
  private size = 100;
  private cell = 100;
  private padX = 20;

  private score = 0;
  private level = 1;
  private lives = LIVES_START;
  private combo = 0;
  private bestCombo = 0;
  private timeLeft = 0;
  private timeLimit = 30;
  private placed = 0;
  private levelMistakes = 0;
  private totalCorrect = 0;
  private totalWrong = 0;
  private held: Item | null = null;
  private holdT = 0;
  private dragging = false;
  private pointerHeld = false;
  private dragFrom = { x: 0, y: 0 };
  private cursor = 0;
  private shake = 0;
  private flash = 0;
  private flashColor = "255,90,110";
  private lastTick = 99;
  private t = 0;
  assist = false;
  muted = false;
  music = false;
  private seq: Item[] = [];
  private onUi: (s: UiState) => void;
  private uiCache = "";

  constructor(canvas: HTMLCanvasElement, onUi: (s: UiState) => void) {
    this.canvas = canvas;
    this.ctx = canvas.getContext("2d", { alpha: false })!;
    this.onUi = onUi;
    this.resize();
    this.buildMenuScene();
    this.last = performance.now();
    this.raf = requestAnimationFrame(this.frame);
  }

  // ---------- lifecycle ----------
  destroy() {
    cancelAnimationFrame(this.raf);
  }

  resize() {
    const rect = this.canvas.getBoundingClientRect();
    const W = Math.max(280, Math.round(rect.width));
    const H = Math.max(320, Math.round(rect.height));
    this.dpr = Math.min(2, window.devicePixelRatio || 1);
    this.W = W;
    this.H = H;
    this.canvas.width = Math.floor(W * this.dpr);
    this.canvas.height = Math.floor(H * this.dpr);
    this.counterY = H * 0.635;
    this.rowY = H * 0.6;
    this.shelfY = H * 0.865;
    this.bg = makeBackdrop(W, H, this.dpr, this.counterY, this.shelfY);
    this.dust = Array.from({ length: 34 }, (_, i) => {
      const r = rng(i * 991 + 5);
      return { x: r() * W, y: r() * H * 0.62, r: 0.8 + r() * 2.4, s: 4 + r() * 12, p: r() * 6.28 };
    });
    this.layout();
  }

  private layout() {
    const n = Math.max(this.items.length, 3);
    this.padX = this.W < 520 ? this.W * 0.015 : Math.min(this.W * 0.06, 46);
    this.cell = (this.W - this.padX * 2) / n;
    const maxH = this.rowY - this.H * 0.3;
    this.size = Math.max(40, Math.min(this.cell * 0.84, maxH, 132));
    const left = (this.W - this.cell * n) / 2;
    this.items.forEach((o, i) => {
      const s = itemSizeFor(o.type, this.size * (o.type === "melon" ? 1.15 : o.type === "box" ? 1.06 : 1));
      o.w = s.w;
      o.h = s.h;
      o.homeX = left + this.cell * (i + 0.5);
      // the shelf is filled right ⟶ left (پُرترین first)
      o.slotX = left + this.cell * (n - 1 - o.slotIndex + 0.5);
      if (o.state === "table") {
        o.tx = o.homeX;
        o.ty = this.rowY;
      } else if (o.state === "placed") {
        o.tx = o.slotX;
        o.ty = this.shelfY;
      }
    });
  }

  private spawn(items: RoundItem[]) {
    this.items = items.map((it, i) => {
      const meta = TYPE_META[it.type];
      return {
        ...it,
        idx: i,
        x: this.W / 2,
        y: this.rowY - 260 - i * 12,
        tx: 0,
        ty: this.rowY,
        vx: 0,
        vy: 0,
        w: 60,
        h: 90,
        state: "table" as const,
        slot: -1,
        slotIndex: i,
        homeX: 0,
        slotX: 0,
        knock: 99,
        reveal: 0,
        revealTo: 0,
        revealTimer: 0,
        seed: i * 1.7 + 0.4,
        hue: meta.palette[i % meta.palette.length],
        rot: 0,
        glow: 0,
        bad: 0,
        wobble: i * 0.8,
      } as Item;
    });
    this.seq = [];
    this.placed = 0;
    this.layout();
  }

  private buildMenuScene() {
    const vals = [0.2, 0.45, 0.68, 0.9];
    const types: Item["type"][] = ["glass", "can", "melon", "glass"];
    this.spawn(types.map((type, i) => ({ id: i, type, value: vals[i] })));
    this.items.forEach((o) => {
      o.y = this.rowY;
      o.ty = this.rowY;
    });
  }

  // ---------- public control ----------
  startGame(startLevel = 1) {
    this.score = 0;
    this.level = Math.max(1, startLevel);
    this.lives = LIVES_START;
    this.combo = 0;
    this.bestCombo = 0;
    this.totalCorrect = 0;
    this.totalWrong = 0;
    this.levelMistakes = 0;
    this.startRound(true);
    audio.setMusic(false);
    this.music = false;
    this.pushUi(true);
  }

  nextLevel() {
    this.level++;
    if (this.level % 3 === 0 && this.lives < LIVES_MAX) this.lives++;
    this.startRound();
  }

  private startRound(fresh = false) {
    const round = buildRound(this.level);
    this.spawn(round.items);
    this.timeLimit = round.time;
    this.timeLeft = round.time;
    this.levelMistakes = 0;
    this.failedInfo = null;
    this.held = null;
    this.dragging = false;
    this.cursor = 0;
    this.phase = "playing";
    this.banner({
      title: `مرحلهٔ ${this.persian(this.level)}`,
      sub: `${seasonFor(this.level).label} · ${this.persian(this.items.length)} شیء — از پُر به خالی بچین`,
      tone: "info",
    });
    if (fresh) audio.click(true);
  }

  restartLevel() {
    this.startRound();
    this.pushUi(true);
  }

  toMenu() {
    this.phase = "menu";
    this.buildMenuScene();
    this.banner(null);
    this.pushUi(true);
  }

  togglePause() {
    if (this.phase === "playing") {
      this.phase = "paused";
      audio.click();
    } else if (this.phase === "paused") {
      this.phase = "playing";
      audio.click(true);
    }
    this.pushUi(true);
  }

  setAssist(v: boolean) {
    this.assist = v;
    this.pushUi(true);
  }
  setMuted(v: boolean) {
    this.muted = v;
    audio.setMuted(v);
    if (v) audio.setMusic(false);
    else if (this.music) audio.setMusic(true);
    this.pushUi(true);
  }
  setMusic(v: boolean) {
    this.music = v;
    audio.setMusic(v && !this.muted);
    this.pushUi(true);
  }

  private bannerTimer = 0;
  private bannerData: UiState["banner"] = null;
  private banner(data: UiState["banner"]) {
    this.bannerData = data;
    this.bannerTimer = data ? 2.1 : 0;
    this.pushUi(true);
  }

  private roundSummary: UiState["roundSummary"] = null;
  private failedInfo: UiState["failedInfo"] = null;
  private summaryData() {
    return this.roundSummary;
  }

  // ---------- input ----------
  private hitTest(x: number, y: number): Item | null {
    let best: Item | null = null;
    let bestD = 1e9;
    for (const o of this.items) {
      const top = o.y - o.h * 1.12;
      const bot = o.y + o.h * 0.06;
      const half = o.w * 0.62;
      if (x > o.x - half && x < o.x + half && y > top && y < bot) {
        const d = Math.hypot(x - o.x, y - (o.y - o.h * 0.5));
        if (d < bestD) {
          bestD = d;
          best = o;
        }
      }
    }
    return best;
  }

  private inShelf(y: number) {
    return y > (this.rowY + this.shelfY) / 2;
  }

  /** The shelf cell currently under an x coordinate; sequence slot 0 is the rightmost cell. */
  private slotAtX(x: number) {
    const n = this.items.length;
    const left = (this.W - this.cell * n) / 2;
    const visualIndex = Math.max(0, Math.min(n - 1, Math.floor((x - left) / this.cell)));
    return n - 1 - visualIndex;
  }

  private slotCenter(slot: number) {
    const n = this.items.length;
    const left = (this.W - this.cell * n) / 2;
    return left + this.cell * (n - 1 - slot + 0.5);
  }

  onPointerDown(x: number, y: number) {
    audio.ensure();
    this.pointerHeld = true;
    this.dragFrom = { x, y };
    this.dragging = false;
    if (this.phase !== "playing") return;
    const hit = this.hitTest(x, y);
    if (hit) {
      if (hit.state === "placed") {
        this.knock(hit);
        return;
      }
      this.grab(hit);
      return;
    }
    if (this.held && this.inShelf(y)) {
      this.placeHeld(x);
    }
  }

  pointerMove(x: number, y: number) {
    if (!this.pointerHeld || !this.held) return;
    if (Math.hypot(x - this.dragFrom.x, y - this.dragFrom.y) > 10) this.dragging = true;
    if (this.dragging) {
      this.held.tx = x;
      this.held.ty = Math.min(y + this.held.h * 0.28, this.shelfY);
    }
  }

  pointerUp(x: number, y: number) {
    this.pointerHeld = false;
    if (this.phase !== "playing" || !this.held) return;
    if (this.dragging) {
      if (this.inShelf(y)) this.placeHeld(x);
      else this.dropBack();
    } else {
      this.holdT = 0;
      this.held.tx = this.held.homeX;
      this.held.ty = this.rowY - this.held.h * 0.42;
    }
    this.dragging = false;
  }

  private grab(o: Item) {
    if (this.held && this.held !== o) this.dropBack();
    this.held = o;
    o.state = "held";
    this.holdT = 0;
    this.cursor = o.idx;
    o.glow = 1;
    this.knock(o);
  }

  private knock(o: Item) {
    o.knock = 0;
    o.vy -= 40;
    audio.knock(o.type, o.value);
    const c = TYPE_META[o.type].accent;
    const n = o.type === "glass" ? 7 : 5;
    for (let i = 0; i < n; i++) {
      const a = -Math.PI / 2 + (Math.random() - 0.5) * 2.2;
      this.particles.push({
        x: o.x,
        y: o.y - o.h * 0.6,
        vx: Math.cos(a) * (30 + Math.random() * 70),
        vy: Math.sin(a) * (40 + Math.random() * 60),
        life: 0,
        max: 0.5 + Math.random() * 0.4,
        size: 2 + Math.random() * 3.4,
        color: o.type === "can" ? "#e3bd7d" : c,
        kind: o.type === "glass" ? "drop" : o.type === "can" ? "grain" : "spark",
        rot: Math.random() * 6,
        vr: (Math.random() - 0.5) * 10,
        g: o.type === "can" ? 520 : 380,
      });
    }
    this.pushUi(true);
  }

  private dropBack() {
    if (!this.held) return;
    const o = this.held;
    o.state = "table";
    o.tx = o.homeX;
    o.ty = this.rowY;
    o.vx *= 0.4;
    this.held = null;
    audio.thunk();
  }

  private placeHeld(targetX?: number) {
    const o = this.held;
    if (!o) return;

    let firstEmpty = -1;
    for (let i = 0; i < this.items.length; i++) {
      if (!this.seq[i]) {
        firstEmpty = i;
        break;
      }
    }
    const slot = targetX === undefined ? firstEmpty : this.slotAtX(targetX);
    if (slot < 0 || this.seq[slot]) {
      this.dropBack();
      return;
    }

    // any order is allowed while playing — correctness is judged only once everything is placed
    o.state = "placed";
    o.slot = slot;
    o.slotIndex = slot;
    o.slotX = this.slotCenter(slot);
    this.seq[slot] = o;
    this.placed++;
    this.held = null;
    o.tx = o.slotX;
    o.ty = this.shelfY;
    o.vy = -160;
    o.vx = 0;

    // neutral feedback only — points & judgement come after the full arrangement
    audio.place(this.placed - 1);
    this.shake = Math.min(14, this.shake + 6);
    o.glow = 1;
    const col = TYPE_META[o.type].accent;
    this.burst(o.slotX, this.shelfY - o.h * 0.45, 14, col, "star");
    this.rings.push({ x: o.slotX, y: this.shelfY, r: o.w * 0.3, max: o.w * 1.5, life: 0, color: col, w: 3 });
    for (let i = 0; i < 5; i++) {
      this.particles.push({
        x: o.slotX + (Math.random() - 0.5) * o.w,
        y: this.shelfY,
        vx: (Math.random() - 0.5) * 60,
        vy: 20 + Math.random() * 40,
        life: 0,
        max: 0.5,
        size: 3 + Math.random() * 3,
        color: "rgba(255,236,200,0.7)",
        kind: "ring",
        rot: 0,
        vr: 0,
        g: 0,
      });
    }
    if (this.placed >= this.items.length) this.evaluateRound();
    this.pushUi(true);
  }

  /** Judges the arrangement only after every object has been placed. */
  private evaluateRound() {
    const expected = [...this.items].sort((a, b) => b.value - a.value);
    let correct = 0;
    const misplaced: Item[] = [];
    this.seq.forEach((o, i) => {
      if (o === expected[i]) correct++;
      else if (o) misplaced.push(o);
    });

    // points are awarded only now, for the objects sitting in their right place
    this.seq.forEach((o, i) => {
      if (o === expected[i]) {
        const pts = scoreForPlacement(this.level, this.combo, this.assist);
        this.score += pts;
        this.combo++;
        this.popup(o.slotX, this.shelfY - o.h - 10, `+${this.persian(pts)}`, "#ffe6a8", 1);
      }
    });
    this.bestCombo = Math.max(this.bestCombo, this.combo);
    this.totalCorrect += correct;

    if (correct === this.items.length) {
      this.levelClear();
      return;
    }

    // wrong arrangement: lose this hand, reveal everything and wait for the retry button
    this.totalWrong += this.items.length - correct;
    this.levelMistakes = this.items.length - correct;
    this.combo = 0;
    this.lives--;
    this.score = Math.max(0, this.score - 20);
    this.failedInfo = { correct, total: this.items.length };
    misplaced.forEach((o) => {
      o.bad = 1;
    });
    this.items.forEach((o) => {
      o.revealTo = 1;
      o.revealTimer = 99;
    });
    audio.error();
    this.shake = Math.min(26, this.shake + 20);
    this.flash = 1;
    this.flashColor = "255,80,100";
    if (this.lives <= 0) {
      this.gameOver();
      return;
    }
    this.phase = "roundfailed";
    this.pushUi(true);
  }

  private levelClear() {
    const perfect = this.levelMistakes === 0;
    const timeBonus = Math.round(this.timeLeft * (perfect ? 6 : 4));
    const bonus = Math.round((160 + this.level * 40) * (perfect ? 1.7 : 1) * (this.assist ? 0.7 : 1));
    this.score += timeBonus + bonus;
    this.roundSummary = { bonus: perfect ? bonus : bonus, timeBonus, perfect };
    this.phase = "levelclear";
    this.items.forEach((o) => {
      o.revealTo = 1;
      o.revealTimer = 99;
    });
    audio.levelClear();
    this.shake = 10;
    this.flash = 0.6;
    this.flashColor = "120,240,200";
    this.banner(null);
    for (let i = 0; i < 70; i++) {
      this.particles.push({
        x: Math.random() * this.W,
        y: -20 - Math.random() * this.H * 0.4,
        vx: (Math.random() - 0.5) * 60,
        vy: 90 + Math.random() * 200,
        life: 0,
        max: 2.6 + Math.random() * 1.4,
        size: 4 + Math.random() * 7,
        color: ["#ffc453", "#64f0c8", "#ff8f6b", "#9b6cff", "#fff4de"][Math.floor(Math.random() * 5)],
        kind: "confetti",
        rot: Math.random() * 6.28,
        vr: (Math.random() - 0.5) * 9,
        g: 60,
      });
    }
    this.pushUi(true);
  }

  private gameOver() {
    this.phase = "gameover";
    this.lives = 0;
    this.held = null;
    this.items.forEach((o) => {
      o.revealTo = 1;
      o.revealTimer = 99;
    });
    audio.gameOver();
    this.shake = 26;
    this.flash = 1;
    this.flashColor = "255,80,100";
    this.banner(null);
    this.pushUi(true);
  }

  /** keyboard: move the selection cursor */
  moveCursor(dir: number) {
    if (this.phase !== "playing") return;
    const n = this.items.length;
    this.cursor = (this.cursor + dir + n) % n;
    const o = this.items[this.cursor];
    if (o) {
      audio.click();
      o.glow = Math.max(o.glow, 0.6);
      o.tx = o.homeX;
      if (o.state === "table") o.ty = this.rowY - o.h * 0.3;
    }
    this.pushUi(true);
  }

  cursorListen() {
    const o = this.items[this.cursor];
    if (!o) return;
    if (o.state === "held") {
      this.knock(o);
      return;
    }
    if (o.state === "placed") {
      this.knock(o);
      return;
    }
    this.grab(o);
  }

  cursorPlace() {
    if (this.phase !== "playing") return;
    const o = this.items[this.cursor];
    if (!o) return;
    if (o.state === "placed") return;
    if (o.state !== "held") this.grab(o);
    this.placeHeld();
  }

  selectIndex(i: number) {
    if (this.phase !== "playing") return;
    if (i < 0 || i >= this.items.length) return;
    this.cursor = i;
    const o = this.items[i];
    if (o && o.state === "table") {
      this.grab(o);
    } else if (o) {
      this.knock(o);
    }
  }

  continueNow() {
    if (this.phase === "levelclear") {
      this.roundSummary = null;
      this.nextLevel();
    } else if (this.phase === "roundfailed") {
      this.restartLevel();
    } else if (this.phase === "paused") {
      this.togglePause();
    }
  }

  quitToMenuIfOver() {
    if (this.phase === "gameover") this.toMenu();
  }

  // ---------- helpers ----------
  private popup(x: number, y: number, text: string, color: string, size: number) {
    this.popups.push({ x, y, text, life: 0, max: 1.15, color, size });
  }

  private burst(x: number, y: number, n: number, color: string, kind: Particle["kind"]) {
    for (let i = 0; i < n; i++) {
      const a = Math.random() * Math.PI * 2;
      const sp = 60 + Math.random() * 220;
      this.particles.push({
        x,
        y,
        vx: Math.cos(a) * sp,
        vy: Math.sin(a) * sp - 40,
        life: 0,
        max: 0.5 + Math.random() * 0.6,
        size: 2.5 + Math.random() * 4.5,
        color,
        kind,
        rot: Math.random() * 6.28,
        vr: (Math.random() - 0.5) * 12,
        g: kind === "grain" ? 700 : 420,
      });
    }
  }

  private persian(n: number) {
    return Math.round(n).toLocaleString("fa-IR");
  }

  private pushUi(force = false) {
    const s: UiState = {
      phase: this.phase,
      score: this.score,
      level: this.level,
      lives: this.lives,
      combo: this.combo,
      bestCombo: this.bestCombo,
      timeLeft: Math.max(0, Math.round(this.timeLeft * 10) / 10),
      timeLimit: this.timeLimit,
      placed: this.placed,
      total: this.items.length,
      assist: this.assist,
      muted: this.muted,
      music: this.music,
      banner: this.bannerData,
      roundSummary: this.summaryData(),
      failedInfo: this.failedInfo,
      totalCorrect: this.totalCorrect,
      totalWrong: this.totalWrong,
    };
    const key = JSON.stringify([
      s.phase,
      s.score,
      s.level,
      s.lives,
      s.combo,
      s.timeLeft,
      s.placed,
      s.total,
      s.assist,
      s.muted,
      s.music,
      s.banner?.title ?? "",
      s.totalWrong,
    ]);
    if (!force && key === this.uiCache) return;
    this.uiCache = key;
    this.onUi(s);
  }

  // ---------- loop ----------
  private frame = (now: number) => {
    this.raf = requestAnimationFrame(this.frame);
    const dt = Math.min(0.033, (now - this.last) / 1000);
    this.last = now;
    this.update(dt);
    this.render();
  };

  private update(dt: number) {
    this.t += dt;
    this.shake *= Math.pow(0.0016, dt);
    this.flash = Math.max(0, this.flash - dt * 2.2);
    if (this.bannerTimer > 0) {
      this.bannerTimer -= dt;
      if (this.bannerTimer <= 0) this.banner(null);
    }

    const running = this.phase === "playing" || this.phase === "levelclear" || this.phase === "menu";

    // items
    for (const o of this.items) {
      const stiff = o.state === "held" ? 340 : 210;
      const damp = o.state === "held" ? 16 : 11;
      o.vx += (o.tx - o.x) * stiff * dt;
      o.vy += (o.ty - o.y) * stiff * dt;
      o.vx *= Math.exp(-damp * dt);
      o.vy *= Math.exp(-damp * dt);
      o.x += o.vx * dt;
      o.y += o.vy * dt;
      o.knock += dt;
      o.glow = Math.max(0, o.glow - dt * 1.6);
      o.bad = Math.max(0, o.bad - dt * 1.1);
      o.reveal += (o.revealTo - o.reveal) * Math.min(1, dt * 5);
      if (o.revealTimer > 0 && o.revealTimer < 90) {
        o.revealTimer -= dt;
        if (o.revealTimer <= 0) o.revealTo = 0;
      }
      const speed = Math.hypot(o.vx, o.vy);
      o.rot = Math.max(-0.22, Math.min(0.22, (o.tx - o.x) * 0.0045)) + (o.state === "held" ? Math.sin(this.t * 6 + o.wobble) * 0.03 : 0);
      if (o.state !== "held" && speed < 4) {
        o.y += Math.sin(this.t * 1.6 + o.wobble) * 0.04;
      }
      // knock ring squash handled in render
    }

    // held auto return
    if (this.held && !this.pointerHeld) {
      this.holdT += dt;
      if (this.holdT > HOLD_LIMIT) this.dropBack();
    }

    // particles
    const ps = this.particles;
    for (let i = ps.length - 1; i >= 0; i--) {
      const p = ps[i];
      p.life += dt;
      if (p.life > p.max || p.y > this.H + 60) {
        ps.splice(i, 1);
        continue;
      }
      p.vy += p.g * dt;
      p.vx *= 0.99;
      p.x += p.vx * dt;
      p.y += p.vy * dt;
      p.rot += p.vr * dt;
      if (p.kind === "drop" && p.y > this.rowY - 2 && p.vy > 0) {
        p.vy *= -0.35;
        p.vx *= 0.6;
        p.y = this.rowY - 2;
      }
    }
    if (ps.length > 320) ps.splice(0, ps.length - 320);

    for (let i = this.rings.length - 1; i >= 0; i--) {
      const r = this.rings[i];
      r.life += dt;
      r.r += (r.max - r.r) * Math.min(1, dt * 8);
      if (r.life > 0.6) this.rings.splice(i, 1);
    }
    for (let i = this.popups.length - 1; i >= 0; i--) {
      const p = this.popups[i];
      p.life += dt;
      p.y -= dt * 46;
      if (p.life > p.max) this.popups.splice(i, 1);
    }
    for (const d of this.dust) {
      d.y -= dt * d.s * 0.35;
      d.x += Math.sin(this.t * 0.5 + d.p) * dt * 6;
      if (d.y < -10) {
        d.y = this.H * 0.62;
        d.x = Math.random() * this.W;
      }
    }

    if (this.phase === "playing" && running) {
      this.timeLeft -= dt;
      const whole = Math.ceil(this.timeLeft);
      if (whole <= 5 && whole !== this.lastTick && whole > 0) {
        this.lastTick = whole;
        audio.tick();
        this.shake = Math.max(this.shake, 4);
      }
      if (this.timeLeft <= 0) {
        this.timeLeft = 0;
        this.lives--;
        this.combo = 0;
        this.totalWrong++;
        audio.error();
        this.flash = 1;
        this.flashColor = "255,80,100";
        this.shake = 22;
        if (this.lives <= 0) this.gameOver();
        else {
          this.banner({ title: "وقت تمام شد!", sub: "یه بار دیگه بچین", tone: "bad" });
          this.restartLevel();
        }
      }
      this.pushUi();
    } else if (this.phase === "levelclear") {
      // no auto-advance: the reveal stays until the player presses «مرحلهٔ بعد» (or Enter/Space)
      this.pushUi();
    } else if (this.phase === "roundfailed") {
      // same: the failed arrangement stays revealed until «تلاش دوباره» is pressed
      this.pushUi();
    } else if (this.phase === "menu") {
      if (Math.random() < dt * 0.7) {
        const o = this.items[Math.floor(Math.random() * this.items.length)];
        if (o) {
          o.knock = 0;
          o.glow = 0.8;
          this.burst(o.x, o.y - o.h * 0.6, 5, TYPE_META[o.type].accent, "drop");
        }
      }
    }
  }

  private render() {
    const ctx = this.ctx;
    const { W, H, dpr } = this;
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.fillStyle = "#0c1626";
    ctx.fillRect(0, 0, W, H);

    const sh = this.shake;
    if (sh > 0.3) {
      const a = Math.random() * 6.28;
      ctx.translate(Math.cos(a) * sh, Math.sin(a) * sh);
    }

    if (this.bg) ctx.drawImage(this.bg, -10, -10, W + 20, H + 20);

    // ambient bokeh + dust
    ctx.globalCompositeOperation = "lighter";
    const gp = this.glow;
    for (let i = 0; i < 7; i++) {
      const x = ((i * 137 + this.t * (8 + i * 2)) % (W + 240)) - 120;
      const y = H * (0.08 + 0.07 * ((i * 3) % 5)) + Math.sin(this.t * 0.5 + i) * 12;
      const s = 120 + i * 26 + Math.sin(this.t + i) * 8;
      ctx.globalAlpha = 0.14 + 0.05 * Math.sin(this.t * 0.8 + i);
      ctx.drawImage(gp, x - s / 2, y - s / 2, s, s);
    }
    ctx.globalAlpha = 1;
    for (const d of this.dust) {
      ctx.fillStyle = "rgba(255,236,200,0.5)";
      ctx.beginPath();
      ctx.arc(d.x, d.y, d.r, 0, 6.283);
      ctx.fill();
    }
    ctx.globalCompositeOperation = "source-over";

    this.drawShelf(ctx);

    // carrying an object? show where it will land
    if (this.held && this.phase === "playing" && this.placed < this.items.length) {
      const o = this.held;
      const tx = this.slotCenter(this.slotAtX(o.tx));
      ctx.save();
      ctx.setLineDash([7, 9]);
      ctx.lineDashOffset = -this.t * 46;
      ctx.strokeStyle = "rgba(255,196,83,0.55)";
      ctx.lineWidth = 2.5;
      ctx.beginPath();
      ctx.moveTo(o.x, o.y - o.h * 0.5);
      ctx.quadraticCurveTo((o.x + tx) / 2, (o.y + this.shelfY) / 2 + 22, tx, this.shelfY - 4);
      ctx.stroke();
      ctx.setLineDash([]);
      ctx.translate(tx, this.shelfY);
      ctx.globalAlpha = 0.14;
      ctx.fillStyle = "#ffc453";
      ctx.beginPath();
      ctx.roundRect(-o.w / 2, -o.h, o.w, o.h, o.w * 0.3);
      ctx.fill();
      ctx.globalAlpha = 0.6;
      ctx.strokeStyle = "rgba(255,196,83,0.8)";
      ctx.lineWidth = 2;
      ctx.stroke();
      ctx.restore();
    }

    // item shadows
    for (const o of this.items) {
      const base = o.state === "placed" ? this.shelfY : this.rowY;
      const lift = Math.max(0, base - o.y);
      const k = Math.max(0.25, 1 - lift / 260);
      ctx.fillStyle = `rgba(10,16,26,${0.36 * k})`;
      ctx.beginPath();
      ctx.ellipse(o.x, base + o.h * 0.02, o.w * 0.55 * k, o.w * 0.16 * k, 0, 0, 6.283);
      ctx.fill();
    }

    const ordered = [...this.items].sort((a, b) => (a.state === "held" ? 1 : 0) - (b.state === "held" ? 1 : 0));
    for (const o of ordered) {
      ctx.save();
      const knockPulse = o.knock < 0.3 ? 1 - o.knock / 0.3 : 0;
      const sq = 1 + knockPulse * 0.09;
      const bob = o.state === "held" ? Math.sin(this.t * 7) * 2 : 0;
      ctx.translate(o.x, o.y + bob);
      ctx.rotate(o.rot);
      ctx.scale(sq / (1 + knockPulse * 0.04), 1 / sq);
      if (o.glow > 0.01) {
        ctx.globalCompositeOperation = "lighter";
        const gs = o.w * (2.2 + o.glow);
        ctx.globalAlpha = o.glow * 0.5;
        ctx.drawImage(this.glowMint, -gs / 2, -o.h - gs / 3, gs, gs);
        ctx.globalAlpha = 1;
        ctx.globalCompositeOperation = "source-over";
      }
      if (o.bad > 0) {
        ctx.globalAlpha = 1;
        ctx.shadowColor = `rgba(255,60,90,${o.bad})`;
        ctx.shadowBlur = 24;
      }
      drawItemBody(ctx, o, this.t);
      ctx.shadowBlur = 0;
      drawKnockFx(ctx, o, this.t);
      ctx.restore();

      if (this.assist && o.knock < 1.6) {
        ctx.save();
        ctx.translate(o.x, o.y);
        drawAssist(ctx, o, 7 + (1 - (AudioEngine.pitchFor(o.type, o.value) - 80) / 1120) * 30);
        ctx.restore();
      }

      if (this.phase === "playing" && o.state === "table") {
        // key badge
        const r = Math.max(9, this.size * 0.14);
        const bx = o.x - o.w * 0.5 - r * 0.2;
        const by = o.y - o.h * 1.02 - r;
        ctx.beginPath();
        ctx.arc(bx, by, r, 0, 6.283);
        ctx.fillStyle = this.cursor === o.idx ? "#ffc453" : "rgba(12,22,38,0.72)";
        ctx.fill();
        ctx.strokeStyle = this.cursor === o.idx ? "#fff4de" : "rgba(255,244,222,0.35)";
        ctx.lineWidth = 2;
        ctx.stroke();
        ctx.fillStyle = this.cursor === o.idx ? "#1b2d46" : "#fff4de";
        ctx.font = `800 ${Math.round(r * 1.25)}px Vazirmatn, sans-serif`;
        ctx.textAlign = "center";
        ctx.textBaseline = "middle";
        ctx.fillText(this.persian(o.idx + 1), bx, by + 1);
        ctx.textBaseline = "alphabetic";
      }
    }

    // rings
    for (const r of this.rings) {
      const p = r.life / 0.6;
      ctx.globalAlpha = (1 - p) * 0.8;
      ctx.strokeStyle = r.color;
      ctx.lineWidth = r.w * (1 - p) + 1;
      ctx.beginPath();
      ctx.ellipse(r.x, r.y, r.r, r.r * 0.3, 0, 0, 6.283);
      ctx.stroke();
    }
    ctx.globalAlpha = 1;

    // particles
    for (const p of this.particles) {
      const k = 1 - p.life / p.max;
      ctx.save();
      ctx.globalAlpha = Math.max(0, k);
      ctx.translate(p.x, p.y);
      ctx.rotate(p.rot);
      ctx.fillStyle = p.color;
      if (p.kind === "star") {
        ctx.beginPath();
        for (let i = 0; i < 10; i++) {
          const a = (i / 10) * 6.283;
          const rr2 = i % 2 ? p.size * 0.45 : p.size * (1 + k * 0.3);
          ctx[i ? "lineTo" : "moveTo"](Math.cos(a) * rr2, Math.sin(a) * rr2);
        }
        ctx.closePath();
        ctx.fill();
      } else if (p.kind === "confetti") {
        ctx.fillRect(-p.size / 2, -p.size / 4, p.size, p.size / 2);
      } else if (p.kind === "grain") {
        ctx.beginPath();
        ctx.ellipse(0, 0, p.size, p.size * 0.78, 0, 0, 6.283);
        ctx.fill();
      } else if (p.kind === "drop") {
        ctx.beginPath();
        ctx.moveTo(0, -p.size * 1.5);
        ctx.quadraticCurveTo(p.size, 0, 0, p.size);
        ctx.quadraticCurveTo(-p.size, 0, 0, -p.size * 1.5);
        ctx.fill();
      } else if (p.kind === "ring") {
        ctx.strokeStyle = p.color;
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.arc(0, 0, p.size * (1 + (1 - k) * 3), 0, 6.283);
        ctx.stroke();
      } else {
        ctx.beginPath();
        ctx.arc(0, 0, p.size * k, 0, 6.283);
        ctx.fill();
      }
      ctx.restore();
    }
    ctx.globalAlpha = 1;

    // popups
    for (const p of this.popups) {
      const k = p.life / p.max;
      const e = k < 0.2 ? k / 0.2 : 1;
      ctx.save();
      ctx.globalAlpha = k > 0.7 ? (1 - k) / 0.3 : e;
      ctx.translate(p.x, p.y);
      ctx.scale(0.7 + e * 0.3 + (1 - Math.min(1, k * 4)) * 0.25, 1);
      ctx.font = `400 ${Math.round(28 * p.size)}px Lalezar, Vazirmatn, sans-serif`;
      ctx.textAlign = "center";
      ctx.lineWidth = 5;
      ctx.strokeStyle = "rgba(8,14,24,0.75)";
      ctx.strokeText(p.text, 0, 0);
      ctx.fillStyle = p.color;
      ctx.fillText(p.text, 0, 0);
      ctx.restore();
    }

    // held-hint timer arc
    if (this.held && !this.pointerHeld) {
      const o = this.held;
      const k = 1 - this.holdT / HOLD_LIMIT;
      ctx.save();
      ctx.translate(o.x, o.y - o.h * 1.25);
      ctx.strokeStyle = k > 0.35 ? "rgba(255,196,83,0.9)" : "rgba(255,93,115,0.9)";
      ctx.lineWidth = 3;
      ctx.beginPath();
      ctx.arc(0, 0, Math.max(10, o.w * 0.2), -Math.PI / 2, -Math.PI / 2 + k * 6.283);
      ctx.stroke();
      ctx.restore();
    }

    // hit flash
    if (this.flash > 0.01) {
      ctx.fillStyle = `rgba(${this.flashColor},${this.flash * 0.3})`;
      ctx.fillRect(-20, -20, W + 40, H + 40);
    }
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);

    // low-time red edge
    if (this.phase === "playing" && this.timeLeft < 6) {
      const a = 0.12 + 0.12 * Math.sin(this.t * 9);
      const g = ctx.createLinearGradient(0, 0, 0, H);
      g.addColorStop(0, `rgba(255,60,90,${a})`);
      g.addColorStop(0.25, "rgba(255,60,90,0)");
      g.addColorStop(0.75, "rgba(255,60,90,0)");
      g.addColorStop(1, `rgba(255,60,90,${a})`);
      ctx.fillStyle = g;
      ctx.fillRect(0, 0, W, H);
    }
  }

  private drawShelf(ctx: CanvasRenderingContext2D) {
    const n = this.items.length;
    if (!n) return;
    const left = (this.W - this.cell * n) / 2;
    const next = this.held ? this.slotAtX(this.held.tx) : -1;
    for (let i = 0; i < n; i++) {
      const seqIdx = n - 1 - i;
      const x = left + this.cell * (i + 0.5);
      const isNext = this.phase === "playing" && seqIdx === next;
      const done = Boolean(this.seq[seqIdx]);
      ctx.save();
      ctx.translate(x, this.shelfY);
      if (isNext) {
        const p = 0.5 + 0.5 * Math.sin(this.t * 5);
        ctx.globalCompositeOperation = "lighter";
        const s = this.cell * (1.3 + p * 0.2);
        ctx.globalAlpha = 0.28 + p * 0.18;
        ctx.drawImage(this.glow, -s / 2, -this.size * 0.75 - s / 2, s, s);
        ctx.globalAlpha = 1;
        ctx.globalCompositeOperation = "source-over";
      }
      ctx.strokeStyle = done ? "rgba(100,240,200,0.55)" : isNext ? "rgba(255,196,83,0.95)" : "rgba(255,244,222,0.22)";
      ctx.lineWidth = isNext ? 3 : 2;
      ctx.setLineDash(done ? [] : isNext ? [] : [7, 7]);
      ctx.beginPath();
      ctx.ellipse(0, 2, this.cell * 0.36, this.cell * 0.09, 0, 0, 6.283);
      ctx.stroke();
      ctx.setLineDash([]);
      if (isNext) {
        const bob = Math.sin(this.t * 5) * 4;
        ctx.fillStyle = "rgba(255,196,83,0.95)";
        ctx.beginPath();
        ctx.moveTo(0, -12 + bob);
        ctx.lineTo(-9, -24 + bob);
        ctx.lineTo(9, -24 + bob);
        ctx.closePath();
        ctx.fill();
      }
      if (!done && this.phase === "playing") {
        ctx.fillStyle = isNext ? "rgba(255,196,83,0.95)" : "rgba(255,244,222,0.35)";
        ctx.font = `400 ${Math.max(11, Math.min(17, this.cell * 0.16))}px Lalezar, Vazirmatn, sans-serif`;
        ctx.textAlign = "center";
        ctx.fillText(this.persian(seqIdx + 1), 0, -this.cell * 0.14);
      } else if (done) {
        ctx.fillStyle = "rgba(100,240,200,0.9)";
        ctx.beginPath();
        ctx.arc(this.cell * 0.3, -this.cell * 0.05, 3.4, 0, 6.283);
        ctx.fill();
      }
      ctx.restore();
    }
    void left;
    // caption on the plank's front face
    const ph = Math.max(16, this.H * 0.035);
    if (this.size > 60) {
      ctx.save();
      ctx.font = `400 ${Math.max(10, Math.min(15, ph * 0.62))}px Lalezar, Vazirmatn, sans-serif`;
      ctx.textAlign = "center";
      ctx.textBaseline = "middle";
      ctx.fillStyle = "rgba(38,18,6,0.55)";
      ctx.fillText("چیدن از پُر (راست) به خالی (چپ)", this.W / 2, this.shelfY + ph * 0.58);
      ctx.restore();
    }
  }

  // exposed for the assist meter in the HUD
  get roundTypes() {
    return [...new Set(this.items.map((i) => i.type))].map((t) => TYPE_META[t].name);
  }
  get typeRule() {
    const t = this.items.find((i) => i.state !== "placed")?.type ?? this.items[0]?.type;
    return t ? TYPE_META[t].rule : "";
  }
  get typesUnlocked() {
    return unlockedTypes(this.level).length;
  }
}
