import type { Item } from "./config";
import { TYPE_META } from "./config";
import brainUrl from "../assets/brain.png";
import environmentUrl from "../assets/game-environment.webp";
import glassUrl from "../assets/glass.png";
import canUrl from "../assets/can.png";
import melonUrl from "../assets/melon.png";
import boxUrl from "../assets/box.png";
import headUrl from "../assets/head.png";

const INK = "#152238";

const environmentImage = typeof Image === "undefined" ? null : new Image();
if (environmentImage) {
  environmentImage.onload = () => window.dispatchEvent(new Event("resize"));
  environmentImage.src = environmentUrl;
}

const glassImage = typeof Image === "undefined" ? null : new Image();
if (glassImage) {
  glassImage.src = glassUrl;
}

const canImage = typeof Image === "undefined" ? null : new Image();
if (canImage) {
  canImage.src = canUrl;
}

const melonImage = typeof Image === "undefined" ? null : new Image();
if (melonImage) {
  melonImage.src = melonUrl;
}

const boxImage = typeof Image === "undefined" ? null : new Image();
if (boxImage) {
  boxImage.src = boxUrl;
}

const headImage = typeof Image === "undefined" ? null : new Image();
if (headImage) {
  headImage.src = headUrl;
}

export function rng(seed: number) {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

function rr(ctx: CanvasRenderingContext2D, x: number, y: number, w: number, h: number, r: number) {
  const rad = Math.min(r, Math.abs(w) / 2, Math.abs(h) / 2);
  ctx.beginPath();
  ctx.moveTo(x + rad, y);
  ctx.lineTo(x + w - rad, y);
  ctx.quadraticCurveTo(x + w, y, x + w, y + rad);
  ctx.lineTo(x + w, y + h - rad);
  ctx.quadraticCurveTo(x + w, y + h, x + w - rad, y + h);
  ctx.lineTo(x + rad, y + h);
  ctx.quadraticCurveTo(x, y + h, x, y + h - rad);
  ctx.lineTo(x, y + rad);
  ctx.quadraticCurveTo(x, y, x + rad, y);
  ctx.closePath();
}

function tumblerPath(ctx: CanvasRenderingContext2D, w: number, h: number, inset = 0) {
  const tw = w / 2 - inset;
  const bw = w * 0.4 - inset;
  const r = Math.max(2, Math.min(h * 0.16, w * 0.16) - inset * 0.5);
  ctx.beginPath();
  ctx.moveTo(-tw, -h + inset * 0.2);
  ctx.lineTo(-bw, -r);
  ctx.quadraticCurveTo(-bw, 0, -bw + r, 0);
  ctx.lineTo(bw - r, 0);
  ctx.quadraticCurveTo(bw, 0, bw, -r);
  ctx.lineTo(tw, -h + inset * 0.2);
  ctx.closePath();
}

function ell(ctx: CanvasRenderingContext2D, cx: number, cy: number, rx: number, ry: number) {
  ctx.beginPath();
  ctx.ellipse(cx, cy, Math.max(0.5, rx), Math.max(0.5, ry), 0, 0, Math.PI * 2);
}

function strokeInk(ctx: CanvasRenderingContext2D, lw: number) {
  ctx.lineJoin = "round";
  ctx.lineCap = "round";
  ctx.strokeStyle = INK;
  ctx.lineWidth = lw;
  ctx.stroke();
}

/* ------------------------------------------------------------------ */
/*  backdrop                                                           */
/* ------------------------------------------------------------------ */

export function makeBackdrop(W: number, H: number, dpr: number, counterY: number, shelfY: number) {
  const c = document.createElement("canvas");
  c.width = Math.floor(W * dpr);
  c.height = Math.floor(H * dpr);
  const ctx = c.getContext("2d")!;
  ctx.scale(dpr, dpr);

  // The supplied illustration is the game world. Draw it cover-style so there are no empty edges.
  if (environmentImage?.complete && environmentImage.naturalWidth > 0) {
    const iw = environmentImage.naturalWidth;
    const ih = environmentImage.naturalHeight;
    const scale = Math.max(W / iw, H / ih);
    const sw = W / scale;
    const sh = H / scale;
    const sx = (iw - sw) / 2;
    const syImg = (ih - sh) / 2;
    ctx.drawImage(environmentImage, sx, syImg, sw, sh, 0, 0, W, H);

    // Keep the sorting shelf readable over the new environment.
    const sy = shelfY;
    const ph = Math.max(16, H * 0.035);
    const sg = ctx.createLinearGradient(0, sy, 0, sy + ph);
    sg.addColorStop(0, "#c98a4d");
    sg.addColorStop(0.5, "#a5652f");
    sg.addColorStop(1, "#6d3f1a");
    ctx.fillStyle = "rgba(0,0,0,0.28)";
    rr(ctx, W * 0.03, sy + 7, W * 0.94, ph, 10);
    ctx.fill();
    ctx.fillStyle = sg;
    rr(ctx, W * 0.03, sy, W * 0.94, ph, 10);
    ctx.fill();
    ctx.strokeStyle = "rgba(255,232,200,0.35)";
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(W * 0.03 + 8, sy + 2.5);
    ctx.lineTo(W * 0.97 - 8, sy + 2.5);
    ctx.stroke();

    const vg = ctx.createRadialGradient(W / 2, H * 0.5, Math.min(W, H) * 0.25, W / 2, H * 0.5, Math.max(W, H) * 0.78);
    vg.addColorStop(0, "rgba(0,0,0,0)");
    vg.addColorStop(1, "rgba(2,6,14,0.42)");
    ctx.fillStyle = vg;
    ctx.fillRect(0, 0, W, H);
    return c;
  }

  const r = rng(1337);

  // --- night kitchen wall ---
  const g = ctx.createLinearGradient(0, 0, 0, counterY);
  g.addColorStop(0, "#213a5c");
  g.addColorStop(0.55, "#182c47");
  g.addColorStop(1, "#101f34");
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, W, counterY + 2);

  // subway tiles
  const tw = Math.max(70, W / 9);
  const th = tw * 0.5;
  ctx.lineWidth = 1.5;
  for (let row = 0; row * th < counterY + th; row++) {
    const off = row % 2 ? tw / 2 : 0;
    for (let x = -tw; x < W + tw; x += tw) {
      const y = row * th;
      ctx.fillStyle = `rgba(255,255,255,${0.018 + r() * 0.02})`;
      rr(ctx, x + off + 2, y + 2, tw - 4, th - 4, 6);
      ctx.fill();
      ctx.strokeStyle = "rgba(255,244,222,0.045)";
      ctx.stroke();
    }
  }

  // warm lamp pools on the wall
  for (let i = 0; i < 3; i++) {
    const cx = W * (0.18 + i * 0.32);
    const rg = ctx.createRadialGradient(cx, -H * 0.05, 0, cx, -H * 0.05, H * 0.6);
    rg.addColorStop(0, "rgba(255,196,83,0.22)");
    rg.addColorStop(1, "rgba(255,196,83,0)");
    ctx.fillStyle = rg;
    ctx.fillRect(0, 0, W, counterY);
  }

  // string lights swag
  const bulbs: [number, number][] = [];
  for (let s = 0; s < 2; s++) {
    const x0 = s ? W * 0.5 : -W * 0.02;
    const x1 = s ? W * 1.02 : W * 0.52;
    const yTop = H * 0.035;
    const sag = H * 0.075;
    ctx.beginPath();
    ctx.moveTo(x0, yTop + 6);
    ctx.quadraticCurveTo((x0 + x1) / 2, yTop + sag, x1, yTop + 4);
    ctx.strokeStyle = "rgba(8,16,28,0.75)";
    ctx.lineWidth = 2.5;
    ctx.stroke();
    for (let i = 0; i <= 6; i++) {
      const t = i / 6;
      const mt = 1 - t;
      const x = mt * mt * x0 + 2 * mt * t * ((x0 + x1) / 2) + t * t * x1;
      const y = mt * mt * (yTop + 6) + 2 * mt * t * (yTop + sag) + t * t * (yTop + 4);
      bulbs.push([x, y]);
    }
  }
  bulbs.forEach(([x, y], i) => {
    ctx.fillStyle = i % 2 ? "#ffcf6b" : "#9ef7dd";
    ctx.beginPath();
    ctx.ellipse(x, y + 9, 5, 7, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = "rgba(255,255,255,0.35)";
    ctx.beginPath();
    ctx.ellipse(x - 1.5, y + 7, 1.6, 2.2, 0, 0, Math.PI * 2);
    ctx.fill();
  });

  // jars on a high shelf silhouette
  ctx.fillStyle = "rgba(8,18,30,0.35)";
  ctx.fillRect(0, H * 0.185, W, 8);
  for (let i = 0; i < 5; i++) {
    const jw = W * 0.052;
    const jh = H * 0.052;
    const x = W * (0.08 + i * 0.21);
    const y = H * 0.185 - jh;
    ctx.fillStyle = i % 2 ? "rgba(16,32,50,0.55)" : "rgba(22,40,58,0.5)";
    rr(ctx, x, y, jw, jh, jw * 0.28);
    ctx.fill();
    ctx.fillStyle = "rgba(255,244,222,0.10)";
    rr(ctx, x + 2, y + 3, 3.5, jh - 8, 2);
    ctx.fill();
    ctx.fillStyle = "rgba(255,196,83,0.16)";
    rr(ctx, x + 2, y + jh * 0.42, jw - 4, jh * 0.4, 3);
    ctx.fill();
    ctx.fillStyle = "rgba(10,20,32,0.7)";
    rr(ctx, x + jw * 0.18, y - 6, jw * 0.64, 7, 3);
    ctx.fill();
  }

  // --- wooden counter ---
  const wg = ctx.createLinearGradient(0, counterY, 0, H);
  wg.addColorStop(0, "#a9682f");
  wg.addColorStop(0.1, "#8b5225");
  wg.addColorStop(0.75, "#5d3418");
  wg.addColorStop(1, "#3d2110");
  ctx.fillStyle = wg;
  ctx.fillRect(0, counterY, W, H - counterY);

  // wood grain
  ctx.save();
  ctx.beginPath();
  ctx.rect(0, counterY, W, H - counterY);
  ctx.clip();
  for (let i = 0; i < 90; i++) {
    const y = counterY + r() * (H - counterY);
    ctx.strokeStyle = `rgba(${r() > 0.5 ? "255,225,190" : "40,18,6"},${0.02 + r() * 0.05})`;
    ctx.lineWidth = 0.6 + r() * 2.4;
    ctx.beginPath();
    const x0 = r() * W;
    ctx.moveTo(x0 - 220, y);
    ctx.bezierCurveTo(x0 - 60, y - 6 + r() * 12, x0 + 60, y + 6 - r() * 12, x0 + 240, y);
    ctx.stroke();
  }
  // table-front edge light
  ctx.fillStyle = "rgba(255,220,160,0.18)";
  ctx.fillRect(0, counterY, W, 3);
  ctx.restore();

  // checkered cloth at the left of the counter
  ctx.save();
  ctx.translate(W * 0.02, counterY + (H - counterY) * 0.12);
  ctx.rotate(-0.06);
  const cw = Math.min(220, W * 0.3);
  ctx.fillStyle = "#f3f0e6";
  rr(ctx, 0, 0, cw, cw * 0.42, 8);
  ctx.fill();
  ctx.clip();
  for (let i = -2; i < 10; i++) {
    for (let j = 0; j < 4; j++) {
      if ((i + j) % 2) continue;
      ctx.fillStyle = "rgba(226,72,86,0.85)";
      ctx.fillRect(i * (cw / 8), j * (cw * 0.105), cw / 8 - 1, cw * 0.105 - 1);
    }
  }
  ctx.restore();

  // --- the sorting shelf plank ---
  const sy = shelfY;
  const ph = Math.max(16, H * 0.035);
  const sg = ctx.createLinearGradient(0, sy, 0, sy + ph);
  sg.addColorStop(0, "#c98a4d");
  sg.addColorStop(0.5, "#a5652f");
  sg.addColorStop(1, "#6d3f1a");
  ctx.fillStyle = "rgba(0,0,0,0.28)";
  rr(ctx, W * 0.03, sy + 7, W * 0.94, ph, 10);
  ctx.fill();
  ctx.fillStyle = sg;
  rr(ctx, W * 0.03, sy, W * 0.94, ph, 10);
  ctx.fill();
  ctx.strokeStyle = "rgba(255,232,200,0.35)";
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.moveTo(W * 0.03 + 8, sy + 2.5);
  ctx.lineTo(W * 0.97 - 8, sy + 2.5);
  ctx.stroke();
  for (const nx of [W * 0.06, W * 0.94]) {
    ctx.fillStyle = "rgba(45,22,8,0.6)";
    ell(ctx, nx, sy + ph * 0.5, 3.4, 3.4);
    ctx.fill();
  }

  // vignette
  const vg = ctx.createRadialGradient(W / 2, H * 0.5, Math.min(W, H) * 0.25, W / 2, H * 0.5, Math.max(W, H) * 0.78);
  vg.addColorStop(0, "rgba(0,0,0,0)");
  vg.addColorStop(1, "rgba(2,6,14,0.62)");
  ctx.fillStyle = vg;
  ctx.fillRect(0, 0, W, H);

  return c;
}

export function makeGlowSprite(size = 96, color = "255,214,140") {
  const c = document.createElement("canvas");
  c.width = c.height = size;
  const ctx = c.getContext("2d")!;
  const g = ctx.createRadialGradient(size / 2, size / 2, 0, size / 2, size / 2, size / 2);
  g.addColorStop(0, `rgba(${color},0.85)`);
  g.addColorStop(0.35, `rgba(${color},0.32)`);
  g.addColorStop(1, `rgba(${color},0)`);
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, size, size);
  return c;
}

/* ------------------------------------------------------------------ */
/*  objects — origin is bottom-centre of the object                    */
/* ------------------------------------------------------------------ */

function waterBody(ctx: CanvasRenderingContext2D, w: number, h: number, value: number, t: number, hue: number) {
  const surf = -h * 0.1 - h * 0.78 * value;
  // the dry part above the waterline reads darker, so the level is unmistakable
  ctx.fillStyle = `hsla(${hue},45%,10%,0.4)`;
  ctx.fillRect(-w, -h * 1.4, w * 2, surf + h * 1.4);
  const grd = ctx.createLinearGradient(0, surf, 0, 0);
  grd.addColorStop(0, `hsla(${hue},95%,66%,0.98)`);
  grd.addColorStop(0.45, `hsla(${hue},90%,49%,0.98)`);
  grd.addColorStop(1, `hsla(${hue},82%,30%,1)`);
  ctx.fillStyle = grd;
  ctx.beginPath();
  ctx.moveTo(-w, surf);
  for (let x = -w; x <= w; x += w / 4) {
    ctx.quadraticCurveTo(x + w / 8, surf + Math.sin(t * 2.4 + x * 0.06) * 2.4, x + w / 4, surf);
  }
  ctx.lineTo(w, 4);
  ctx.lineTo(-w, 4);
  ctx.closePath();
  ctx.fill();
  ctx.strokeStyle = `hsla(${hue},100%,86%,0.85)`;
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.moveTo(-w, surf);
  for (let x = -w; x <= w; x += w / 4) {
    ctx.quadraticCurveTo(x + w / 8, surf + Math.sin(t * 2.4 + x * 0.06) * 2.4, x + w / 4, surf);
  }
  ctx.stroke();
  // bubbles
  const r = rng(41);
  for (let i = 0; i < 7; i++) {
    const bx = (r() - 0.5) * w * 1.4;
    const speed = 0.25 + r() * 0.5;
    const by = -(((t * speed * 40 + r() * 100) % Math.max(10, -surf)) + 4);
    ctx.fillStyle = "rgba(255,255,255,0.5)";
    ell(ctx, bx, by, 1.6 + r() * 2, 1.6 + r() * 2);
    ctx.fill();
  }
}

function drawGlass(ctx: CanvasRenderingContext2D, o: Item, t: number) {
  const { w, h, value, reveal } = o;
  const hue = o.hue;
  const tw = w / 2;

  // Use downloaded glass sprite
  if (glassImage && glassImage.complete && glassImage.naturalWidth > 0) {
    ctx.save();
    ctx.imageSmoothingEnabled = true;
    ctx.imageSmoothingQuality = "high";

    // 1. Draw the glass image sprite
    ctx.drawImage(glassImage, -tw, -h, w, h);

    // 2. Exact water level indicator shown on reveal
    if (reveal > 0.01) {
      ctx.save();
      ctx.globalAlpha = Math.min(0.85, reveal * 0.85);
      tumblerPath(ctx, w * 0.94, h * 0.9, 1.5);
      ctx.clip();
      waterBody(ctx, w * 0.94, h * 0.9, value, t + o.seed, hue);
      ctx.restore();
    }

    ctx.restore();
    return;
  }

  // Fallback procedural tumbler if image is loading
  tumblerPath(ctx, w, h);
  const bodyG = ctx.createLinearGradient(-tw, 0, tw, 0);
  bodyG.addColorStop(0, "rgba(190,232,255,0.42)");
  bodyG.addColorStop(0.32, "rgba(232,250,255,0.2)");
  bodyG.addColorStop(0.68, "rgba(160,215,245,0.28)");
  bodyG.addColorStop(1, "rgba(210,240,255,0.45)");
  ctx.fillStyle = bodyG;
  ctx.fill();

  ctx.save();
  tumblerPath(ctx, w, h, 2.5);
  ctx.clip();
  waterBody(ctx, w, h, value, t + o.seed, hue);

  ctx.restore();

  // rim
  ell(ctx, 0, -h, tw, tw * 0.22);
  ctx.lineWidth = Math.max(3, w * 0.075);
  ctx.strokeStyle = "rgba(236,250,255,0.9)";
  ctx.stroke();

  tumblerPath(ctx, w, h);
  strokeInk(ctx, Math.max(2.4, w * 0.05));
}

function drawCan(ctx: CanvasRenderingContext2D, o: Item, t: number) {
  const { w, h, value, reveal } = o;
  const hue = o.hue;
  const rx = w / 2;
  const ry = rx * 0.26;
  const sheen = ((t * 0.28 + o.seed) % 3) - 0.5;

  // Use downloaded can sprite
  if (canImage && canImage.complete && canImage.naturalWidth > 0) {
    ctx.save();
    ctx.imageSmoothingEnabled = true;
    ctx.imageSmoothingQuality = "high";
    ctx.drawImage(canImage, -w / 2, -h, w, h);
    
    // Show exact legume level on reveal
    if (reveal > 0.01) {
      ctx.save();
      ctx.globalAlpha = reveal;
      rr(ctx, -w * 0.26, -h * 0.74, w * 0.52, h * 0.62, w * 0.1);
      ctx.fillStyle = "rgba(24,16,10,0.9)";
      ctx.fill();
      ctx.save();
      rr(ctx, -w * 0.26, -h * 0.74, w * 0.52, h * 0.62, w * 0.1);
      ctx.clip();
      const lvl = -h * 0.12 - h * 0.58 * value;
      ctx.fillStyle = "#e3bd7d";
      ctx.fillRect(-w * 0.3, lvl, w * 0.6, h);
      const kr = rng(o.id * 13 + 3);
      for (let i = 0; i < 26; i++) {
        const px = -w * 0.3 + kr() * w * 0.6;
        const py = lvl + kr() * (h * 0.6);
        ell(ctx, px, py, w * 0.05, w * 0.04);
        ctx.fillStyle = kr() > 0.5 ? "#f0d199" : "#c99a5d";
        ctx.fill();
      }
      ctx.restore();
      ctx.strokeStyle = "rgba(255,244,222,0.7)";
      ctx.lineWidth = 2;
      ctx.stroke();
      ctx.restore();
    }
    
    ctx.restore();
    return;
  }

  // Fallback procedural metal can
  ctx.beginPath();
  ctx.moveTo(-rx, -h + ry);
  ctx.lineTo(-rx, -ry);
  ctx.quadraticCurveTo(-rx, 0, 0, 0);
  ctx.quadraticCurveTo(rx, 0, rx, -ry);
  ctx.lineTo(rx, -h + ry);
  ctx.closePath();
  const mg = ctx.createLinearGradient(-rx, 0, rx, 0);
  mg.addColorStop(0, "#7d8ea3");
  mg.addColorStop(0.16, "#dfe9f2");
  mg.addColorStop(0.34, "#f6fbff");
  mg.addColorStop(0.55, "#aebdcb");
  mg.addColorStop(0.8, "#7d8ea3");
  mg.addColorStop(1, "#5b6a7d");
  ctx.fillStyle = mg;
  ctx.fill();

  ctx.save();
  ctx.beginPath();
  ctx.rect(-rx, -h + ry * 0.5, w, h - ry * 0.5);
  ctx.clip();

  // paper label
  const lg = ctx.createLinearGradient(-rx, 0, rx, 0);
  lg.addColorStop(0, `hsl(${hue},52%,32%)`);
  lg.addColorStop(0.28, `hsl(${hue},72%,54%)`);
  lg.addColorStop(0.62, `hsl(${hue},66%,45%)`);
  lg.addColorStop(1, `hsl(${hue},50%,28%)`);
  ctx.fillStyle = lg;
  ctx.fillRect(-rx - 2, -h * 0.8, w + 4, h * 0.58);
  ctx.fillStyle = "rgba(255,244,222,0.95)";
  ctx.beginPath();
  for (let x = -rx; x <= rx; x += w / 8) {
    ctx.lineTo(x, -h * 0.79 + Math.sin(x * 0.2) * 1.5);
  }
  ctx.lineTo(rx, -h * 0.24);
  for (let x = rx; x >= -rx; x -= w / 8) {
    ctx.lineTo(x, -h * 0.23 + Math.sin(x * 0.2) * 1.6);
  }
  ctx.closePath();
  ctx.fill();

  // reveal: cutaway window
  if (reveal > 0.01) {
    ctx.save();
    ctx.globalAlpha = reveal;
    rr(ctx, -w * 0.26, -h * 0.74, w * 0.52, h * 0.62, w * 0.1);
    ctx.fillStyle = "rgba(24,16,10,0.9)";
    ctx.fill();
    ctx.save();
    rr(ctx, -w * 0.26, -h * 0.74, w * 0.52, h * 0.62, w * 0.1);
    ctx.clip();
    const lvl = -h * 0.12 - h * 0.58 * value;
    ctx.fillStyle = "#e3bd7d";
    ctx.fillRect(-w * 0.3, lvl, w * 0.6, h);
    const kr = rng(o.id * 13 + 3);
    for (let i = 0; i < 26; i++) {
      const px = -w * 0.3 + kr() * w * 0.6;
      const py = lvl + kr() * (h * 0.6);
      ell(ctx, px, py, w * 0.05, w * 0.04);
      ctx.fillStyle = kr() > 0.5 ? "#f0d199" : "#c99a5d";
      ctx.fill();
    }
    ctx.restore();
    ctx.strokeStyle = "rgba(255,244,222,0.7)";
    ctx.lineWidth = 2;
    ctx.stroke();
    ctx.restore();
  }
  ctx.restore();

  // lid
  ell(ctx, 0, -h + ry * 0.4, rx, ry);
  ctx.fillStyle = "#c9d7e4";
  ctx.fill();
  strokeInk(ctx, Math.max(2.2, w * 0.045));
  ell(ctx, 0, -h + ry * 0.4, rx * 0.78, ry * 0.7);
  ctx.fillStyle = "#aebfcd";
  ctx.fill();
  ctx.strokeStyle = "rgba(255,255,255,0.6)";
  ctx.lineWidth = 1.4;
  ctx.stroke();
  // pull ring
  ctx.save();
  ctx.translate(-rx * 0.12, -h + ry * 0.3);
  ctx.rotate(-0.3);
  rr(ctx, -rx * 0.3, -ry * 0.3, rx * 0.6, ry * 0.7, 3);
  ctx.fillStyle = "#e9f2fa";
  ctx.fill();
  strokeInk(ctx, 1.8);
  ctx.restore();

  // sheen + outline
  ctx.globalAlpha = 0.5;
  ctx.strokeStyle = "#ffffff";
  ctx.lineWidth = w * 0.06;
  const sx = -rx * (0.45 - Math.sin(sheen * 2.2) * 0.06);
  ctx.beginPath();
  ctx.moveTo(sx, -h * 0.86);
  ctx.lineTo(sx, -h * 0.06);
  ctx.stroke();
  ctx.globalAlpha = 1;

  ctx.beginPath();
  ctx.moveTo(-rx, -h + ry);
  ctx.lineTo(-rx, -ry);
  ctx.quadraticCurveTo(-rx, 0, 0, 0);
  ctx.quadraticCurveTo(rx, 0, rx, -ry);
  ctx.lineTo(rx, -h + ry);
  strokeInk(ctx, Math.max(2.4, w * 0.05));
}

/* ---------------- watermelon ---------------- */

const MELON_P_TOP = 2.3;
const MELON_P_BOT = 3.1;

/** Half-thickness of the lying melon at x — the bottom is flatter because it rests on its own weight. */
function melonHalf(x: number, rx: number, ry: number, bottom: boolean) {
  const u = Math.min(1, Math.abs(x) / rx);
  const p = bottom ? MELON_P_BOT : MELON_P_TOP;
  const taper = x < 0 ? 1 - 0.07 * u : 1; // the stem end is slightly narrower
  return ry * Math.pow(Math.max(0, 1 - Math.pow(u, p)), 1 / p) * taper;
}

function melonOutline(rx: number, ry: number, cy: number, seed: number) {
  const N = 22;
  const pts: number[] = [];
  for (let k = 0; k <= N; k++) {
    const x = -rx * Math.cos((Math.PI * k) / N);
    const wob = 1 + 0.012 * Math.sin(k * 1.3 + seed);
    pts.push(x, cy - melonHalf(x, rx, ry, false) * wob);
  }
  for (let k = N - 1; k >= 1; k--) {
    const x = -rx * Math.cos((Math.PI * k) / N);
    pts.push(x, cy + melonHalf(x, rx, ry, true));
  }
  return pts;
}

function traceSmooth(ctx: CanvasRenderingContext2D, pts: number[]) {
  const n = pts.length / 2;
  ctx.beginPath();
  ctx.moveTo((pts[(n - 1) * 2] + pts[0]) / 2, (pts[(n - 1) * 2 + 1] + pts[1]) / 2);
  for (let i = 0; i < n; i++) {
    const j = ((i + 1) % n) * 2;
    ctx.quadraticCurveTo(pts[i * 2], pts[i * 2 + 1], (pts[i * 2] + pts[j]) / 2, (pts[i * 2 + 1] + pts[j + 1]) / 2);
  }
  ctx.closePath();
}

interface MelonLook {
  rx: number;
  ry: number;
  cy: number;
  w: number;
  h: number;
  pts: number[];
  seed: number;
  lightTop: string;
  light: string;
  lightLow: string;
  dark: string;
}

/** Rind, torn stripes, texture and shading. The caller has already clipped to the body. */
function melonSkin(ctx: CanvasRenderingContext2D, m: MelonLook) {
  const { rx, ry, cy, w, h, pts } = m;
  const r = rng(m.seed);

  // Downloaded watermelon sprite (season 3) — caller has already clipped to the body.
  if (melonImage && melonImage.complete && melonImage.naturalWidth > 0) {
    const bw = rx * 2;
    const bh = ry * 2;
    const iw = melonImage.naturalWidth;
    const ih = melonImage.naturalHeight;
    const scale = Math.max(bw / iw, bh / ih);
    const sw = bw / scale;
    const sh = bh / scale;
    const sx = (iw - sw) / 2;
    const sy = (ih - sh) / 2;
    ctx.save();
    ctx.imageSmoothingEnabled = true;
    ctx.imageSmoothingQuality = "high";
    ctx.drawImage(melonImage, sx, sy, sw, sh, -rx, cy - ry, bw, bh);
    ctx.restore();
    return;
  }

  const base = ctx.createLinearGradient(0, -h, 0, 0);
  base.addColorStop(0, m.lightTop);
  base.addColorStop(0.55, m.light);
  base.addColorStop(1, m.lightLow);
  ctx.fillStyle = base;
  traceSmooth(ctx, pts);
  ctx.fill();

  // a point on the rind at position x and angle th around the long axis
  const projY = (x: number, th: number) => {
    const a = Math.max(-1.5708, Math.min(1.5708, th));
    const s = Math.sin(a);
    return cy - s * melonHalf(x, rx, ry, s < 0);
  };

  // dark stripes with flame-like jagged edges, converging at the stem and blossom ends
  const M = 32;
  const xs: number[] = [];
  for (let k = 0; k <= M; k++) xs.push(-rx * Math.cos((Math.PI * k) / M));
  const spacing = 0.42;
  const phase = (r() - 0.5) * spacing;
  const veins: number[][] = [];
  ctx.beginPath();
  for (let s = -4; s <= 4; s++) {
    const th0 = s * spacing + phase;
    if (Math.abs(th0) > 1.75) continue;
    const ph = r() * 6.28;
    const up: number[] = [];
    const dn: number[] = [];
    const mid: number[] = [];
    for (let k = 0; k <= M; k++) {
      const x = xs[k];
      const u = x / rx;
      const half = 0.1 * (0.86 + 0.24 * Math.sin(u * 2.3 + ph));
      const wave = 0.045 * Math.sin(u * 5.2 + ph * 1.7);
      const sign = k % 2 ? 1 : -1;
      up.push(x, projY(x, th0 + half + wave + sign * 0.06 * (0.4 + 0.6 * r())));
      dn.push(x, projY(x, th0 - half + wave - sign * 0.06 * (0.4 + 0.6 * r())));
      mid.push(x, projY(x, th0 + wave));
    }
    ctx.moveTo(up[0], up[1]);
    for (let k = 1; k <= M; k++) ctx.lineTo(up[k * 2], up[k * 2 + 1]);
    for (let k = M; k >= 0; k--) ctx.lineTo(dn[k * 2], dn[k * 2 + 1]);
    ctx.closePath();
    veins.push(mid);
  }
  ctx.fillStyle = m.dark;
  ctx.fill();

  // faint light vein inside every stripe
  ctx.beginPath();
  for (const v of veins) {
    ctx.moveTo(v[0], v[1]);
    for (let k = 1; k < v.length / 2; k++) ctx.lineTo(v[k * 2], v[k * 2 + 1]);
  }
  ctx.strokeStyle = "rgba(168,222,128,0.2)";
  ctx.lineWidth = Math.max(0.8, w * 0.009);
  ctx.stroke();

  // creamy field spot where it lay on the ground (identical on every melon, so it is not a hint)
  ctx.save();
  ctx.translate(rx * (0.04 + (r() - 0.5) * 0.24), -ry * 0.1);
  ctx.scale(1, 0.42);
  const fs = ctx.createRadialGradient(0, 0, 0, 0, 0, rx * 0.5);
  fs.addColorStop(0, "rgba(234,218,136,0.85)");
  fs.addColorStop(0.6, "rgba(214,212,126,0.4)");
  fs.addColorStop(1, "rgba(196,206,118,0)");
  ctx.fillStyle = fs;
  ctx.beginPath();
  ctx.arc(0, 0, rx * 0.5, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();

  // fine mottling of the rind
  const fleck = (color: string, count: number) => {
    ctx.beginPath();
    for (let i = 0; i < count; i++) {
      const x = (r() * 2 - 1) * rx * 0.9;
      const y = projY(x, (r() * 2 - 1) * 1.45);
      const sz = Math.max(0.5, w * 0.007) * (0.6 + r() * 0.9);
      ctx.moveTo(x + sz, y);
      ctx.arc(x, y, sz, 0, Math.PI * 2);
    }
    ctx.fillStyle = color;
    ctx.fill();
  };
  fleck("rgba(214,246,178,0.24)", 30);
  fleck("rgba(10,46,18,0.22)", 22);

  // form shading — light from the top-left
  const form = ctx.createRadialGradient(-rx * 0.22, cy - ry * 0.48, rx * 0.12, -rx * 0.1, cy, rx * 1.2);
  form.addColorStop(0, "rgba(255,255,228,0.16)");
  form.addColorStop(0.5, "rgba(0,0,0,0)");
  form.addColorStop(1, "rgba(3,22,8,0.52)");
  ctx.fillStyle = form;
  ctx.fillRect(-rx - 4, -h - 4, w + 8, h + 8);

  const low = ctx.createLinearGradient(0, cy, 0, 0);
  low.addColorStop(0, "rgba(4,26,10,0)");
  low.addColorStop(1, "rgba(4,26,10,0.5)");
  ctx.fillStyle = low;
  ctx.fillRect(-rx - 4, cy, w + 8, ry + 4);

  // crisp rim light on top, warm bounce light from the wood below
  ctx.save();
  ctx.beginPath();
  ctx.rect(-rx * 2, -h * 2, rx * 4, h * 2 + cy - ry * 0.15);
  ctx.clip();
  traceSmooth(ctx, pts);
  ctx.strokeStyle = "rgba(226,255,196,0.22)";
  ctx.lineWidth = Math.max(3, w * 0.05);
  ctx.stroke();
  ctx.restore();
  ctx.save();
  ctx.beginPath();
  ctx.rect(-rx * 2, cy + ry * 0.5, rx * 4, h);
  ctx.clip();
  traceSmooth(ctx, pts);
  ctx.strokeStyle = "rgba(255,210,150,0.16)";
  ctx.lineWidth = Math.max(3, w * 0.045);
  ctx.stroke();
  ctx.restore();

  // soft waxy sheen — a matte rind, no balloon-like specular blob
  ctx.save();
  ctx.translate(-rx * 0.24, cy - ry * 0.5);
  ctx.rotate(-0.06);
  ctx.scale(1, 0.32);
  const sheen = ctx.createRadialGradient(0, 0, 0, 0, 0, rx * 0.6);
  sheen.addColorStop(0, "rgba(255,255,236,0.28)");
  sheen.addColorStop(0.6, "rgba(255,255,236,0.09)");
  sheen.addColorStop(1, "rgba(255,255,236,0)");
  ctx.fillStyle = sheen;
  ctx.beginPath();
  ctx.arc(0, 0, rx * 0.6, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();
  ctx.beginPath();
  for (let k = 0; k <= 8; k++) {
    const x = -rx * (0.74 - k * 0.055);
    const y = cy - melonHalf(x, rx, ry, false) * 0.8;
    if (k === 0) ctx.moveTo(x, y);
    else ctx.lineTo(x, y);
  }
  ctx.strokeStyle = "rgba(242,255,226,0.32)";
  ctx.lineWidth = Math.max(1.3, w * 0.02);
  ctx.lineCap = "round";
  ctx.lineJoin = "round";
  ctx.stroke();

  // blossom-end scar and the stem dimple
  ell(ctx, rx * 0.95, cy + ry * 0.04, Math.max(1.2, rx * 0.03), Math.max(1.6, ry * 0.08));
  ctx.fillStyle = "rgba(118,98,50,0.85)";
  ctx.fill();
  ell(ctx, -rx * 0.955, cy - ry * 0.04, Math.max(1.4, rx * 0.035), Math.max(2, ry * 0.12));
  ctx.fillStyle = "rgba(10,40,16,0.55)";
  ctx.fill();
}

/** Short dry stem with a leaf and a curly tendril at the stem end. */
function melonStem(ctx: CanvasRenderingContext2D, m: MelonLook) {
  const { rx, ry, cy, w } = m;
  const sx = -rx * 0.97;
  const sy = cy - ry * 0.06;
  const qx = -rx * 1.1;
  const qy = cy - ry * 0.02;
  const ex = -rx * 1.1;
  const ey = cy - ry * 0.36;
  const sw = Math.max(2.6, w * 0.055);

  // curly tendril (behind the stem)
  const R0 = Math.max(3, rx * 0.085);
  const tcx = ex - R0 * 0.2;
  const tcy = ey - R0;
  ctx.beginPath();
  for (let j = 0; j <= 22; j++) {
    const a = Math.PI / 2 + (j / 22) * Math.PI * 3.2;
    const rad = R0 * (1 - (j / 22) * 0.72);
    const x = tcx + Math.cos(a) * rad;
    const y = tcy + Math.sin(a) * rad;
    if (j === 0) ctx.moveTo(x, y);
    else ctx.lineTo(x, y);
  }
  const tw = Math.max(1.1, w * 0.016);
  ctx.lineCap = "round";
  ctx.lineJoin = "round";
  ctx.strokeStyle = INK;
  ctx.lineWidth = tw + 1.8;
  ctx.stroke();
  ctx.strokeStyle = "#8cc152";
  ctx.lineWidth = tw;
  ctx.stroke();

  // stem stub
  ctx.beginPath();
  ctx.moveTo(sx, sy);
  ctx.quadraticCurveTo(qx, qy, ex, ey);
  ctx.strokeStyle = INK;
  ctx.lineWidth = sw + 2.6;
  ctx.stroke();
  ctx.strokeStyle = "#7f923e";
  ctx.lineWidth = sw;
  ctx.stroke();
  ctx.strokeStyle = "rgba(255,255,220,0.28)";
  ctx.lineWidth = Math.max(0.8, sw * 0.28);
  ctx.stroke();
  ell(ctx, ex, ey, sw * 0.55, sw * 0.45);
  ctx.fillStyle = "#d4bd83";
  ctx.fill();
  strokeInk(ctx, 1.4);

  // leaf resting on the shoulder
  const tt = 0.5;
  const bx = (1 - tt) * (1 - tt) * sx + 2 * (1 - tt) * tt * qx + tt * tt * ex;
  const by = (1 - tt) * (1 - tt) * sy + 2 * (1 - tt) * tt * qy + tt * tt * ey;
  const lx = -rx * 0.62;
  const ly = cy - ry * 1.02;
  const dx = lx - bx;
  const dy = ly - by;
  const len = Math.hypot(dx, dy) || 1;
  const nx = -dy / len;
  const ny = dx / len;
  const wid = len * 0.34;
  const mx = bx + dx * 0.45;
  const my = by + dy * 0.45;
  ctx.beginPath();
  ctx.moveTo(bx, by);
  ctx.quadraticCurveTo(mx + nx * wid, my + ny * wid, lx, ly);
  ctx.quadraticCurveTo(mx - nx * wid * 0.8, my - ny * wid * 0.8, bx, by);
  ctx.closePath();
  const lg = ctx.createLinearGradient(bx, by, lx, ly);
  lg.addColorStop(0, "#3f9a3a");
  lg.addColorStop(1, "#80d45b");
  ctx.fillStyle = lg;
  ctx.fill();
  strokeInk(ctx, Math.max(1.6, w * 0.022));
  ctx.beginPath();
  ctx.moveTo(bx + dx * 0.08, by + dy * 0.08);
  ctx.quadraticCurveTo(mx + nx * wid * 0.12, my + ny * wid * 0.12, bx + dx * 0.86, by + dy * 0.86);
  ctx.strokeStyle = "rgba(30,90,34,0.75)";
  ctx.lineWidth = Math.max(0.9, w * 0.011);
  ctx.stroke();
}

/** Cross-section of the cut melon: pale with white seeds when unripe, deep red with dark seeds when ripe. */
function melonFace(
  ctx: CanvasRenderingContext2D,
  m: MelonLook,
  fx: number,
  fy: number,
  a: number,
  r: number,
  value: number,
) {
  const ripe = Math.max(0, Math.min(1, value));
  const fr = rng(m.seed + 71);
  ctx.save();
  ctx.translate(fx, fy);
  ctx.scale(a / r, 1);

  // dark skin ring
  ctx.beginPath();
  ctx.arc(0, 0, r, 0, Math.PI * 2);
  ctx.fillStyle = m.dark;
  ctx.fill();

  // white-green rind
  const rind = ctx.createRadialGradient(0, 0, r * 0.78, 0, 0, r * 0.94);
  rind.addColorStop(0, "#f8fbe9");
  rind.addColorStop(1, "#b9de8e");
  ctx.beginPath();
  ctx.arc(0, 0, r * 0.94, 0, Math.PI * 2);
  ctx.fillStyle = rind;
  ctx.fill();

  // flesh
  const hue = (26 - 34 * ripe + 360) % 360;
  const sat = 50 + 34 * ripe;
  const lit = 84 - 30 * ripe;
  const flesh = ctx.createRadialGradient(-r * 0.15, -r * 0.22, r * 0.05, 0, 0, r * 0.82);
  flesh.addColorStop(0, `hsl(${hue}, ${Math.min(100, sat + 6)}%, ${Math.min(95, lit + 6)}%)`);
  flesh.addColorStop(0.72, `hsl(${hue}, ${sat}%, ${lit}%)`);
  flesh.addColorStop(1, `hsl(${hue}, ${sat * 0.6}%, ${Math.min(94, lit + 10)}%)`);
  ctx.beginPath();
  ctx.arc(0, 0, r * 0.82, 0, Math.PI * 2);
  ctx.fillStyle = flesh;
  ctx.fill();

  // seeds
  const k = Math.max(0, Math.min(1, (ripe - 0.25) / 0.5));
  const sk = k * k * (3 - 2 * k);
  const cr = Math.round(242 + (40 - 242) * sk);
  const cg = Math.round(234 + (26 - 234) * sk);
  const cb = Math.round(208 + (18 - 208) * sk);
  ctx.fillStyle = `rgb(${cr},${cg},${cb})`;
  ctx.strokeStyle = `rgba(110,70,40,${0.5 * (1 - sk)})`;
  ctx.lineWidth = Math.max(0.6, r * 0.012);
  const seed = (px: number, py: number, ang: number, s: number) => {
    ctx.save();
    ctx.translate(px, py);
    ctx.rotate(ang);
    ctx.beginPath();
    ctx.moveTo(s, 0);
    ctx.bezierCurveTo(s * 0.3, -s * 0.52, -s * 0.78, -s * 0.46, -s * 0.78, 0);
    ctx.bezierCurveTo(-s * 0.78, s * 0.46, s * 0.3, s * 0.52, s, 0);
    ctx.fill();
    if (sk < 0.9) ctx.stroke();
    ctx.restore();
  };
  const ns = 11;
  for (let i = 0; i < ns; i++) {
    const ang = (i / ns) * Math.PI * 2 + (fr() - 0.5) * 0.35;
    const rad = r * (0.5 + fr() * 0.12);
    seed(Math.cos(ang) * rad, Math.sin(ang) * rad, ang + Math.PI, r * 0.085);
  }
  for (let i = 0; i < 4; i++) {
    const ang = (i / 4) * Math.PI * 2 + 0.6 + (fr() - 0.5) * 0.4;
    const rad = r * (0.24 + fr() * 0.06);
    seed(Math.cos(ang) * rad, Math.sin(ang) * rad, ang + Math.PI, r * 0.07);
  }

  // juicy sparkle + wet highlight
  ctx.fillStyle = "rgba(255,255,255,0.32)";
  ctx.beginPath();
  for (let i = 0; i < 12; i++) {
    const ang = fr() * Math.PI * 2;
    const rad = r * fr() * 0.72;
    const s = r * (0.012 + fr() * 0.016);
    ctx.moveTo(Math.cos(ang) * rad + s, Math.sin(ang) * rad);
    ctx.arc(Math.cos(ang) * rad, Math.sin(ang) * rad, s, 0, Math.PI * 2);
  }
  ctx.fill();
  ctx.beginPath();
  ctx.arc(0, 0, r * 0.66, Math.PI * 1.08, Math.PI * 1.42);
  ctx.strokeStyle = "rgba(255,255,255,0.42)";
  ctx.lineWidth = r * 0.055;
  ctx.lineCap = "round";
  ctx.stroke();
  ctx.restore();

  ell(ctx, fx, fy, a, r);
  strokeInk(ctx, Math.max(2, m.w * 0.026));
}

function drawMelon(ctx: CanvasRenderingContext2D, o: Item, t: number) {
  const { w, h, value, reveal } = o;
  const rx = w / 2;
  const ry = h / 2;
  const cy = -ry;
  const bh = 96 + ((o.hue || 110) - 110) * 0.3;
  const m: MelonLook = {
    rx,
    ry,
    cy,
    w,
    h,
    pts: melonOutline(rx, ry, cy, o.id * 1.9 + 0.7),
    seed: o.id * 977 + 13,
    lightTop: `hsl(${bh - 12}, 58%, 68%)`,
    light: `hsl(${bh - 6}, 50%, 57%)`,
    lightLow: `hsl(${bh}, 46%, 44%)`,
    dark: `hsl(${bh + 34}, 60%, 21%)`,
  };
  const lw = Math.max(2.4, w * 0.032);

  // Use downloaded watermelon sprite without any oval outline
  if (melonImage && melonImage.complete && melonImage.naturalWidth > 0) {
    ctx.save();
    ctx.imageSmoothingEnabled = true;
    ctx.imageSmoothingQuality = "high";
    ctx.drawImage(melonImage, -rx, -h, w, h);

    // The sliced face sits exactly in the middle of the melon and is a circle,
    // so the split looks natural instead of a floating squashed oval.
    if (reveal > 0.01) {
      const faceR = Math.min(ry * 0.98, rx * 0.62);
      const faceX = rx * 0.18;
      const faceY = cy;

      ctx.save();
      ctx.globalAlpha = Math.min(1, reveal * 1.35);

      // Dark cut rim right on the slice plane
      ell(ctx, faceX, faceY, faceR + lw * 0.55, faceR + lw * 0.55);
      ctx.fillStyle = "rgba(52, 22, 10, 0.55)";
      ctx.fill();

      ctx.save();
      ell(ctx, faceX, faceY, faceR, faceR);
      ctx.clip();
      // melonFace draws in a circle of radius `r` centred on (fx, fy);
      // pass an equal aspect so it stays perfectly round.
      melonFace(ctx, m, faceX, faceY, faceR, faceR, value);
      ctx.restore();

      // Crisp rim of the cut flesh
      ell(ctx, faceX, faceY, faceR, faceR);
      ctx.strokeStyle = "rgba(255, 235, 226, 0.55)";
      ctx.lineWidth = Math.max(1.2, w * 0.011);
      ctx.stroke();
      ctx.restore();
    }

    ctx.restore();
    return;
  }

  if (reveal <= 0.01) {
    ctx.save();
    traceSmooth(ctx, m.pts);
    ctx.clip();
    melonSkin(ctx, m);
    ctx.restore();
  } else {
    // cut open: the front-right part lifts away and shows the flesh inside
    const cutX = rx * 0.16;
    const hT = melonHalf(cutX, rx, ry, false);
    const hB = melonHalf(cutX, rx, ry, true);
    const fr = ((hT + hB) / 2) * 0.985;
    const fy = cy + (hB - hT) / 2;
    const fa = fr * 0.52;
    const piecePath = () => {
      ctx.beginPath();
      ctx.rect(cutX, -h * 3, rx * 3, h * 5);
      ctx.moveTo(cutX + fa, fy);
      ctx.ellipse(cutX, fy, fa, fr, 0, 0, Math.PI * 2);
    };

    // the half that stays on the table
    ctx.save();
    ctx.beginPath();
    ctx.rect(-rx * 3, -h * 3, rx * 3 + cutX, h * 5);
    ctx.clip();
    ctx.save();
    traceSmooth(ctx, m.pts);
    ctx.clip();
    melonSkin(ctx, m);
    ctx.restore();
    ctx.restore();

    melonFace(ctx, m, cutX, fy, fa, fr, value);

    // the removed piece lifts off and fades out
    if (reveal < 0.97) {
      const e = reveal;
      const pcx = rx * 0.55;
      ctx.save();
      ctx.globalAlpha = Math.pow(1 - e, 1.4);
      ctx.translate(pcx + rx * 0.15 * e, cy - h * 0.6 * e);
      ctx.rotate(0.4 * e);
      ctx.translate(-pcx, -cy);
      ctx.save();
      traceSmooth(ctx, m.pts);
      ctx.clip();
      piecePath();
      ctx.clip();
      melonSkin(ctx, m);
      ctx.restore();
      ctx.save();
      piecePath();
      ctx.clip();
      ctx.restore();
      ctx.beginPath();
      ctx.ellipse(cutX, fy, fa, fr, 0, Math.PI / 2, Math.PI * 1.5);
      strokeInk(ctx, lw * 0.8);
      ctx.restore();
    }
  }

  if (!(melonImage && melonImage.complete && melonImage.naturalWidth > 0)) {
    melonStem(ctx, m);
  }
  void t;
}


/* ---------------- human head (پس‌گردنی) ---------------- */

type HeadLook = {
  light: string;
  mid: string;
  deep: string;
  shade: string;
  cheek: string;
  lip: string;
  brow: string;
  hair: [string, string, string];
  iris: [string, string];
  shirt: string;
  shirtDark: string;
};

const HEAD_LOOKS: HeadLook[] = [
  {
    light: "#fbe0c4", mid: "#f0c19a", deep: "#d39a6c", shade: "#a86f47", cheek: "#e8836f",
    lip: "#c4606a", brow: "#40291c", hair: ["#3a2b21", "#6b4c34", "#1b120c"],
    iris: ["#7a5a34", "#3a2a18"], shirt: "#2f6f8f", shirtDark: "#1d4c66",
  },
  {
    light: "#f3c8a2", mid: "#dfa67c", deep: "#b87c52", shade: "#8f5a37", cheek: "#d8725f",
    lip: "#b0525c", brow: "#2a1d16", hair: ["#211a16", "#453327", "#0d0a08"],
    iris: ["#5b4630", "#2a1f14"], shirt: "#8f5a8a", shirtDark: "#663b64",
  },
  {
    light: "#fde2c6", mid: "#f2c8a1", deep: "#d09a70", shade: "#a5714b", cheek: "#ea8b76",
    lip: "#c96870", brow: "#533821", hair: ["#7c5732", "#a87a48", "#432c15"],
    iris: ["#4e8a5c", "#245030"], shirt: "#c2703f", shirtDark: "#8f4e28",
  },
  {
    light: "#e8b78c", mid: "#cf9266", deep: "#a76f48", shade: "#7d4f31", cheek: "#c96254",
    lip: "#a54a50", brow: "#1f1510", hair: ["#171110", "#332622", "#080606"],
    iris: ["#3f3a34", "#1a1714"], shirt: "#5c6b4a", shirtDark: "#3d4a30",
  },
];


/* ---------------- human head (سیلی) ---------------- */

/* ---------------- human brain sprite (فصل پنجم) ---------------- */

let brainSprite: HTMLCanvasElement | null = null;
let brainLoading = false;

function keyOutBackground(img: HTMLImageElement): HTMLCanvasElement {
  const c = document.createElement("canvas");
  c.width = img.naturalWidth || img.width || 2;
  c.height = img.naturalHeight || img.height || 2;
  const g = c.getContext("2d", { willReadFrequently: true })!;
  g.drawImage(img, 0, 0);
  try {
    const w = c.width;
    const h = c.height;
    if (w > 0 && h > 0) {
      const data = g.getImageData(0, 0, w, h);
      const px = data.data;
      const visited = new Uint8Array(w * h);
      const stack: number[] = [];
      const isBg = (i: number) => {
        const r = px[i];
        const gg = px[i + 1];
        const b = px[i + 2];
        const a = px[i + 3];
        if (a === 0) return false;
        const mn = Math.min(r, gg, b);
        const mx = Math.max(r, gg, b);
        return mn > 188 && mx - mn < 34;
      };
      const pushIf = (x: number, y: number) => {
        if (x < 0 || y < 0 || x >= w || y >= h) return;
        const id = y * w + x;
        if (visited[id]) return;
        visited[id] = 1;
        if (isBg(id * 4)) stack.push(id);
      };
      for (let x = 0; x < w; x++) {
        pushIf(x, 0);
        pushIf(x, h - 1);
      }
      for (let y = 0; y < h; y++) {
        pushIf(0, y);
        pushIf(w - 1, y);
      }
      while (stack.length) {
        const id = stack.pop()!;
        px[id * 4 + 3] = 0;
        const x = id % w;
        const y = (id / w) | 0;
        if (x > 0) {
          const n = id - 1;
          if (!visited[n]) {
            visited[n] = 1;
            if (isBg(n * 4)) stack.push(n);
          }
        }
        if (x < w - 1) {
          const n = id + 1;
          if (!visited[n]) {
            visited[n] = 1;
            if (isBg(n * 4)) stack.push(n);
          }
        }
        if (y > 0) {
          const n = id - w;
          if (!visited[n]) {
            visited[n] = 1;
            if (isBg(n * 4)) stack.push(n);
          }
        }
        if (y < h - 1) {
          const n = id + w;
          if (!visited[n]) {
            visited[n] = 1;
            if (isBg(n * 4)) stack.push(n);
          }
        }
      }
      g.putImageData(data, 0, 0);
    }
  } catch {
    /* keep original pixels if cleanup fails */
  }
  return c;
}

function getBrainSprite(): HTMLCanvasElement | null {
  if (brainSprite) return brainSprite;
  if (brainLoading) return null;
  if (typeof window === "undefined" || typeof Image === "undefined") return null;
  brainLoading = true;
  const img = new Image();
  img.onload = () => {
    try {
      brainSprite = keyOutBackground(img);
    } catch {
      const c = document.createElement("canvas");
      c.width = img.naturalWidth || 2;
      c.height = img.naturalHeight || 2;
      c.getContext("2d")!.drawImage(img, 0, 0);
      brainSprite = c;
    }
  };
  img.onerror = () => {
    brainLoading = false;
  };
  img.src = brainUrl;
  return null;
}

function drawSlicedBrain(
  ctx: CanvasRenderingContext2D,
  cx: number,
  baseY: number,
  maxW: number,
  maxH: number,
  value: number,
  _seed: number,
  lw: number,
) {
  const fullness = Math.max(0, Math.min(1, value));
  const vScale = 0.28 + 0.72 * fullness;
  const bw = maxW * (0.64 + 0.36 * vScale);
  const bh = maxH * (0.42 + 0.58 * vScale);

  const sprite = getBrainSprite();
  if (!sprite || !sprite.width || !sprite.height) {
    ctx.save();
    ell(ctx, cx, baseY - bh / 2, bw / 2, bh / 2);
    ctx.fillStyle = "#f5a8b8";
    ctx.fill();
    strokeInk(ctx, Math.max(1.2, lw));
    ctx.restore();
    return;
  }
  const imgAspect = sprite.width / sprite.height;
  let dw = bw;
  let dh = bw / imgAspect;
  if (dh > bh) {
    dh = bh;
    dw = dh * imgAspect;
  }
  const dx = cx - dw / 2;
  const dy = baseY - dh;
  ctx.save();
  ctx.imageSmoothingEnabled = true;
  ctx.imageSmoothingQuality = "high";
  ctx.shadowColor = "rgba(40,8,18,0.35)";
  ctx.shadowBlur = Math.max(4, dw * 0.08);
  ctx.shadowOffsetY = Math.max(2, dh * 0.03);
  ctx.drawImage(sprite, dx, dy, dw, dh);
  ctx.restore();
  void lw;
  void _seed;
}

function drawHead(ctx: CanvasRenderingContext2D, o: Item, t: number) {
  const { w, h, value, reveal } = o;
  const L = HEAD_LOOKS[o.id % HEAD_LOOKS.length];
  const lw = Math.max(1.4, w * 0.022);
  const e = reveal * reveal * (3 - 2 * reveal);

  // Hit reaction timing (slap wince & eye blink)
  const sinceHit = o.knock;
  const hit = Math.max(0, 1 - sinceHit / 0.9);
  const blink = Math.max(0, 1 - sinceHit / 0.52);

  const cy = -h * 0.655;
  const rx = w * 0.355;
  const ry = h * 0.305;
  const chinY = cy + ry;
  const eyeY = cy - ry * 0.02;
  const browY = cy - ry * 0.3;
  const noseY = cy + ry * 0.3;
  const mouthY = cy + ry * 0.58;

  // The slice plane for the top 1/3 skull separation (well above the brows, slicing top 1/3 dome)
  const cutY = cy - ry * 0.48;
  const cutRx = rx * 0.88;
  const cutRy = ry * 0.25;

  const headReady = Boolean(headImage && headImage.complete && headImage.naturalWidth > 0);
  if (!headReady) {
  /* ================= 1. Clean, Casual T-Shirt & Natural Neck ================= */
  // Natural neck originating behind chin and smoothly descending into T-shirt
  const neck = () => {
    ctx.beginPath();
    ctx.moveTo(-w * 0.155, chinY - h * 0.05);
    ctx.bezierCurveTo(-w * 0.16, -h * 0.33, -w * 0.18, -h * 0.27, -w * 0.205, -h * 0.22);
    ctx.quadraticCurveTo(0, -h * 0.175, w * 0.205, -h * 0.22);
    ctx.bezierCurveTo(w * 0.18, -h * 0.27, w * 0.16, -h * 0.33, w * 0.155, chinY - h * 0.05);
    ctx.closePath();
  };
  neck();
  const neckGrad = ctx.createLinearGradient(-w * 0.18, 0, w * 0.18, 0);
  neckGrad.addColorStop(0, L.deep);
  neckGrad.addColorStop(0.28, L.mid);
  neckGrad.addColorStop(0.72, L.light);
  neckGrad.addColorStop(1, L.deep);
  ctx.fillStyle = neckGrad;
  ctx.fill();
  ctx.save();
  neck();
  ctx.clip();
  // Soft chin shadow on neck
  const neckShade = ctx.createLinearGradient(0, chinY, 0, chinY + h * 0.08);
  neckShade.addColorStop(0, "rgba(80,46,31,0.36)");
  neckShade.addColorStop(1, "rgba(80,46,31,0)");
  ctx.fillStyle = neckShade;
  ctx.fillRect(-w * 0.22, chinY, w * 0.44, h * 0.09);
  ctx.restore();

  // Natural casual T-Shirt torso with relaxed shoulder slopes
  const torso = () => {
    ctx.beginPath();
    ctx.moveTo(-w * 0.54, 2);
    ctx.lineTo(-w * 0.53, -h * 0.08);
    // Left shoulder slope
    ctx.bezierCurveTo(-w * 0.51, -h * 0.165, -w * 0.41, -h * 0.21, -w * 0.28, -h * 0.23);
    // Crew neck cutout on T-shirt
    ctx.quadraticCurveTo(0, -h * 0.245, w * 0.28, -h * 0.23);
    // Right shoulder slope
    ctx.bezierCurveTo(w * 0.41, -h * 0.21, w * 0.51, -h * 0.165, w * 0.53, -h * 0.08);
    ctx.lineTo(w * 0.54, 2);
    ctx.closePath();
  };
  torso();
  const tshirtGrad = ctx.createLinearGradient(-w * 0.5, -h * 0.23, w * 0.5, 2);
  tshirtGrad.addColorStop(0, L.shirtDark);
  tshirtGrad.addColorStop(0.32, L.shirt);
  tshirtGrad.addColorStop(0.68, L.shirt);
  tshirtGrad.addColorStop(1, L.shirtDark);
  ctx.fillStyle = tshirtGrad;
  ctx.fill();
  ctx.save();
  torso();
  ctx.clip();
  // Natural fabric drape and soft lighting
  const fabricShine = ctx.createRadialGradient(-w * 0.18, -h * 0.16, 0, -w * 0.18, -h * 0.16, w * 0.35);
  fabricShine.addColorStop(0, "rgba(255, 255, 255, 0.18)");
  fabricShine.addColorStop(0.6, "rgba(255, 255, 255, 0.04)");
  fabricShine.addColorStop(1, "rgba(0, 0, 0, 0.22)");
  ctx.fillStyle = fabricShine;
  ctx.fillRect(-w * 0.6, -h * 0.25, w * 1.2, h * 0.3);

  // Short sleeve seam lines
  for (const sgn of [-1, 1] as const) {
    ctx.beginPath();
    ctx.moveTo(sgn * w * 0.35, -h * 0.21);
    ctx.quadraticCurveTo(sgn * w * 0.39, -h * 0.12, sgn * w * 0.41, 2);
    ctx.strokeStyle = "rgba(0, 0, 0, 0.15)";
    ctx.lineWidth = Math.max(1, w * 0.011);
    ctx.stroke();
  }
  ctx.restore();
  torso();
  strokeInk(ctx, lw);

  // Clean, seamless T-Shirt round crewneck rib collar sitting naturally at base of neck
  ctx.beginPath();
  ctx.moveTo(-w * 0.185, -h * 0.232);
  ctx.quadraticCurveTo(0, -h * 0.178, w * 0.185, -h * 0.232);
  ctx.strokeStyle = L.shirtDark;
  ctx.lineWidth = Math.max(3.8, w * 0.046);
  ctx.lineCap = "round";
  ctx.stroke();

  // Subtle interior collar rib highlight
  ctx.beginPath();
  ctx.moveTo(-w * 0.17, -h * 0.234);
  ctx.quadraticCurveTo(0, -h * 0.182, w * 0.17, -h * 0.234);
  ctx.strokeStyle = "rgba(255, 255, 255, 0.22)";
  ctx.lineWidth = Math.max(1, w * 0.012);
  ctx.stroke();

  /* ================= 4. Ears ================= */
  for (const sgn of [-1, 1] as const) {
    const ex = sgn * rx * 0.99;
    const ey = cy + ry * 0.12;
    ell(ctx, ex, ey, w * 0.07, h * 0.075);
    ctx.fillStyle = L.mid;
    ctx.fill();
    strokeInk(ctx, lw * 0.65);
    ell(ctx, ex, ey, w * 0.033, h * 0.038);
    ctx.strokeStyle = "rgba(118, 70, 44, 0.42)";
    ctx.lineWidth = Math.max(1, w * 0.011);
    ctx.stroke();
    ell(ctx, ex - sgn * w * 0.006, ey + h * 0.005, w * 0.013, h * 0.02);
    ctx.fillStyle = "rgba(118, 70, 44, 0.26)";
    ctx.fill();
  }

  /* ================= 5. Head / Face (Lower Sliced Skull or Full Dome) ================= */
  // Full skull silhouette
  const fullSkull = () => {
    ctx.beginPath();
    ctx.moveTo(0, cy - ry);
    ctx.bezierCurveTo(rx * 0.53, cy - ry, rx * 0.94, cy - ry * 0.62, rx, cy - ry * 0.02);
    ctx.bezierCurveTo(rx * 1.03, cy + ry * 0.48, rx * 0.88, cy + ry * 0.79, rx * 0.56, cy + ry * 0.91);
    ctx.quadraticCurveTo(rx * 0.34, cy + ry * 1.02, 0, chinY);
    ctx.quadraticCurveTo(-rx * 0.34, cy + ry * 1.02, -rx * 0.56, cy + ry * 0.91);
    ctx.bezierCurveTo(-rx * 0.88, cy + ry * 0.79, -rx * 1.03, cy + ry * 0.48, -rx, cy - ry * 0.02);
    ctx.bezierCurveTo(-rx * 0.94, cy - ry * 0.62, -rx * 0.53, cy - ry, 0, cy - ry);
    ctx.closePath();
  };

  // Lower sliced skull silhouette (below cutY)
  const slicedLowerSkull = () => {
    ctx.beginPath();
    ctx.moveTo(-cutRx, cutY);
    ctx.bezierCurveTo(-rx * 0.98, cy - ry * 0.1, -rx * 1.02, cy + ry * 0.48, -rx * 0.56, cy + ry * 0.91);
    ctx.quadraticCurveTo(-rx * 0.34, cy + ry * 1.02, 0, chinY);
    ctx.quadraticCurveTo(rx * 0.34, cy + ry * 1.02, rx * 0.56, cy + ry * 0.91);
    ctx.bezierCurveTo(rx * 1.02, cy + ry * 0.48, rx * 0.98, cy - ry * 0.1, cutRx, cutY);
    ctx.ellipse(0, cutY, cutRx, cutRy, 0, 0, Math.PI, false);
    ctx.closePath();
  };

  // Draw face base skin
  if (e <= 0.01) {
    fullSkull();
  } else {
    slicedLowerSkull();
  }
  const skinGrad = ctx.createLinearGradient(-rx * 0.6, cy - ry, rx * 0.7, chinY);
  skinGrad.addColorStop(0, L.light);
  skinGrad.addColorStop(0.42, L.mid);
  skinGrad.addColorStop(1, L.deep);
  ctx.fillStyle = skinGrad;
  ctx.fill();

  ctx.save();
  if (e <= 0.01) {
    fullSkull();
  } else {
    slicedLowerSkull();
  }
  ctx.clip();

  // Face 3D form shading
  const formGrad = ctx.createLinearGradient(rx * 0.18, 0, rx, 0);
  formGrad.addColorStop(0, "rgba(0, 0, 0, 0)");
  formGrad.addColorStop(0.62, "rgba(130, 78, 50, 0.12)");
  formGrad.addColorStop(1, "rgba(130, 78, 50, 0.26)");
  ctx.fillStyle = formGrad;
  ctx.fillRect(rx * 0.16, cy - ry, rx, ry * 2);

  // If unrevealed, draw shiny bald crown dome highlights
  if (e <= 0.01) {
    const domeGrad = ctx.createRadialGradient(-rx * 0.14, cy - ry * 0.62, rx * 0.05, -rx * 0.1, cy - ry * 0.45, rx * 0.85);
    domeGrad.addColorStop(0, "rgba(255, 252, 244, 0.55)");
    domeGrad.addColorStop(0.5, "rgba(255, 250, 238, 0.18)");
    domeGrad.addColorStop(1, "rgba(255, 250, 238, 0)");
    ctx.fillStyle = domeGrad;
    ctx.fillRect(-rx, cy - ry, rx * 2, ry * 1.1);
    ctx.beginPath();
    ctx.ellipse(-rx * 0.16, cy - ry * 0.66, rx * 0.34, ry * 0.14, -0.22, 0, Math.PI * 2);
    ctx.fillStyle = "rgba(255, 255, 255, 0.25)";
    ctx.fill();
  }

  // Cheeks & Slap marks
  for (const sgn of [-1, 1] as const) {
    const b = ctx.createRadialGradient(sgn * rx * 0.56, cy + ry * 0.3, 0, sgn * rx * 0.56, cy + ry * 0.3, rx * 0.32);
    b.addColorStop(0, `rgba(222, 122, 102, ${0.18 + hit * 0.34})`);
    b.addColorStop(1, "rgba(222, 122, 102, 0)");
    ctx.fillStyle = b;
    ctx.fillRect(sgn * rx * 0.56 - rx * 0.34, cy + ry * 0.08, rx * 0.68, ry * 0.44);
  }
  if (hit > 0.02) {
    const mark = ctx.createRadialGradient(-rx * 0.54, cy + ry * 0.18, 0, -rx * 0.54, cy + ry * 0.18, rx * 0.34);
    mark.addColorStop(0, `rgba(206, 72, 62, ${0.34 * hit})`);
    mark.addColorStop(1, "rgba(206, 72, 62, 0)");
    ctx.fillStyle = mark;
    ctx.fillRect(-rx, cy - ry * 0.1, rx * 0.9, ry * 0.66);
  }

  // Jaw shade
  const jawShade = ctx.createLinearGradient(0, cy + ry * 0.66, 0, chinY);
  jawShade.addColorStop(0, "rgba(126, 76, 48, 0)");
  jawShade.addColorStop(1, "rgba(126, 76, 48, 0.18)");
  ctx.fillStyle = jawShade;
  ctx.fillRect(-rx, cy + ry * 0.62, rx * 2, ry * 0.42);

  ctx.restore();

  // Outline lower skull
  if (e <= 0.01) {
    fullSkull();
    strokeInk(ctx, lw);
  } else {
    slicedLowerSkull();
    strokeInk(ctx, lw);
  }

  /* ================= 6. Full Caricature Beard ================= */
  const beardTop = cy + ry * 0.19;
  const beardBottom = chinY + h * 0.07;
  const fullBeard = () => {
    ctx.beginPath();
    ctx.moveTo(-rx * 0.91, beardTop);
    ctx.bezierCurveTo(-rx * 1.0, cy + ry * 0.57, -rx * 0.92, chinY - h * 0.012, -rx * 0.81, chinY + h * 0.018);
    ctx.quadraticCurveTo(-rx * 0.76, beardBottom - h * 0.028, -rx * 0.61, beardBottom - h * 0.02);
    ctx.lineTo(-rx * 0.52, beardBottom - h * 0.005);
    ctx.quadraticCurveTo(-rx * 0.32, beardBottom - h * 0.018, -rx * 0.22, beardBottom + h * 0.002);
    ctx.quadraticCurveTo(0, beardBottom + h * 0.02, rx * 0.22, beardBottom + h * 0.002);
    ctx.quadraticCurveTo(rx * 0.32, beardBottom - h * 0.018, rx * 0.52, beardBottom - h * 0.005);
    ctx.lineTo(rx * 0.61, beardBottom - h * 0.02);
    ctx.quadraticCurveTo(rx * 0.76, beardBottom - h * 0.028, rx * 0.81, chinY + h * 0.018);
    ctx.bezierCurveTo(rx * 0.92, chinY - h * 0.012, rx * 1.0, cy + ry * 0.57, rx * 0.91, beardTop);
    ctx.bezierCurveTo(rx * 0.76, beardTop + h * 0.012, rx * 0.56, mouthY - h * 0.018, rx * 0.38, mouthY + h * 0.018);
    ctx.quadraticCurveTo(rx * 0.33, mouthY + h * 0.078, 0, mouthY + h * 0.076);
    ctx.quadraticCurveTo(-rx * 0.33, mouthY + h * 0.078, -rx * 0.38, mouthY + h * 0.018);
    ctx.bezierCurveTo(-rx * 0.56, mouthY - h * 0.018, -rx * 0.76, beardTop + h * 0.012, -rx * 0.91, beardTop);
    ctx.closePath();
  };
  fullBeard();
  const beardColor = ctx.createLinearGradient(-rx * 0.6, beardTop, rx * 0.55, beardBottom);
  beardColor.addColorStop(0, "#684936");
  beardColor.addColorStop(0.35, "#493026");
  beardColor.addColorStop(0.72, "#30211b");
  beardColor.addColorStop(1, "#1b1512");
  ctx.fillStyle = beardColor;
  ctx.fill();

  ctx.save();
  fullBeard();
  ctx.clip();
  ctx.lineCap = "round";
  for (const side of [-1, 1] as const) {
    for (let i = 0; i < 7; i++) {
      const sx = side * rx * (0.24 + i * 0.1);
      const sy = beardTop + h * (0.025 + i * 0.005);
      const ex = side * rx * (0.08 + i * 0.09);
      const ey = beardBottom - h * (0.005 + i * 0.001);
      ctx.beginPath();
      ctx.moveTo(sx, sy);
      ctx.bezierCurveTo(sx + side * rx * 0.12, sy + h * 0.11, ex + side * rx * 0.09, ey - h * 0.045, ex, ey);
      ctx.strokeStyle = i % 2 ? "rgba(17, 11, 9, 0.32)" : "rgba(168, 120, 79, 0.2)";
      ctx.lineWidth = Math.max(1.2, w * 0.033);
      ctx.stroke();
    }
  }
  ctx.restore();
  fullBeard();
  strokeInk(ctx, lw * 0.85);

  /* ================= 7. Brows, Eyes, Nose, Mouth, Moustache ================= */
  // Animated expressive brows (wince & lift on hit)
  const browLift = -blink * h * 0.028;
  const browTilt = -blink * 0.32;
  for (const sgn of [-1, 1] as const) {
    ctx.save();
    ctx.translate(sgn * rx * 0.36, browY + browLift);
    ctx.rotate(sgn * browTilt);
    ctx.beginPath();
    ctx.moveTo(sgn * -rx * 0.26, h * 0.024);
    ctx.bezierCurveTo(sgn * -rx * 0.12, -h * 0.043, sgn * rx * 0.12, -h * 0.046, sgn * rx * 0.28, h * 0.004);
    ctx.bezierCurveTo(sgn * rx * 0.13, h * 0.01, sgn * -rx * 0.1, h * 0.028, sgn * -rx * 0.25, h * 0.04);
    ctx.closePath();
    ctx.fillStyle = L.brow;
    ctx.fill();
    ctx.restore();
  }

  // Animated Eyes (snaps shut when slapped!)
  for (const sgn of [-1, 1] as const) {
    const ex = sgn * rx * 0.42;
    const ew = rx * 0.215;
    const eh = ry * 0.115;
    const open = 1 - blink;
    const eyeH = eh * (0.12 + 0.88 * open);

    // Socket shadow
    const socket = ctx.createRadialGradient(ex, eyeY - eh * 0.35, 0, ex, eyeY - eh * 0.25, ew * 1.45);
    socket.addColorStop(0, "rgba(138, 82, 54, 0.18)");
    socket.addColorStop(1, "rgba(138, 82, 54, 0)");
    ctx.fillStyle = socket;
    ctx.fillRect(ex - ew * 1.5, eyeY - eh * 2.6, ew * 3, eh * 5);

    if (open > 0.16) {
      ctx.beginPath();
      ctx.ellipse(ex, eyeY, ew, eyeH, 0, 0, Math.PI * 2);
      ctx.fillStyle = "#fdf8f0";
      ctx.fill();
      ctx.strokeStyle = "rgba(70, 46, 32, 0.5)";
      ctx.lineWidth = Math.max(0.9, w * 0.008);
      ctx.stroke();

      const ir = rx * 0.095 * (0.5 + 0.5 * open);
      const iy = eyeY + eyeH * 0.06;
      const ig = ctx.createRadialGradient(ex, iy - ir * 0.3, 0, ex, iy, ir);
      ig.addColorStop(0, L.iris[0]);
      ig.addColorStop(1, L.iris[1]);
      ell(ctx, ex, iy, ir, ir);
      ctx.fillStyle = ig;
      ctx.fill();
      ell(ctx, ex, iy, ir * 0.44, ir * 0.44);
      ctx.fillStyle = "#12100d";
      ctx.fill();
      ell(ctx, ex - ir * 0.32, iy - ir * 0.34, Math.max(0.9, w * 0.0075), Math.max(0.9, w * 0.0075));
      ctx.fillStyle = "#fff";
      ctx.fill();
    }

    // Upper lid / closed lash
    const lidDrop = eyeY - eh * (0.12 + 1.05 * open);
    ctx.beginPath();
    ctx.moveTo(ex - ew, eyeY + eh * 0.08);
    ctx.quadraticCurveTo(ex - ew * 0.2, lidDrop, ex + ew, eyeY + eh * 0.02);
    ctx.strokeStyle = L.brow;
    ctx.lineWidth = Math.max(1.4, w * 0.016);
    ctx.lineCap = "round";
    ctx.stroke();

    if (open <= 0.16) {
      // Squeezed closed lash line on hit!
      ctx.beginPath();
      ctx.moveTo(ex - ew * 0.92, eyeY + eh * 0.02);
      ctx.quadraticCurveTo(ex, eyeY + eh * 1.05, ex + ew * 0.92, eyeY + eh * 0.02);
      ctx.strokeStyle = L.brow;
      ctx.lineWidth = Math.max(1.6, w * 0.019);
      ctx.stroke();
      for (const dir of [-1, 1] as const) {
        ctx.beginPath();
        ctx.moveTo(ex + dir * ew * 0.72, eyeY + eh * 0.2);
        ctx.lineTo(ex + dir * ew * 1.12, eyeY + eh * 0.62);
        ctx.lineWidth = Math.max(1, w * 0.012);
        ctx.stroke();
      }
    }

    // Lower lid
    ctx.beginPath();
    ctx.moveTo(ex - ew * 0.86, eyeY + eh * 0.98);
    ctx.quadraticCurveTo(ex, eyeY + eh * (1.42 + blink * 0.35), ex + ew * 0.86, eyeY + eh * 0.88);
    ctx.strokeStyle = "rgba(126, 80, 52, 0.22)";
    ctx.lineWidth = Math.max(0.8, w * 0.008);
    ctx.stroke();
  }

  // Caricature Nose
  ctx.beginPath();
  ctx.moveTo(-w * 0.014, eyeY + ry * 0.12);
  ctx.bezierCurveTo(-w * 0.026, cy + ry * 0.18, -w * 0.058, noseY + ry * 0.02, -w * 0.076, noseY + ry * 0.075);
  ctx.bezierCurveTo(-w * 0.09, noseY + ry * 0.16, -w * 0.04, noseY + ry * 0.22, w * 0.018, noseY + ry * 0.2);
  ctx.bezierCurveTo(w * 0.085, noseY + ry * 0.2, w * 0.11, noseY + ry * 0.13, w * 0.075, noseY + ry * 0.055);
  ctx.bezierCurveTo(w * 0.045, noseY + ry * 0.0, w * 0.03, cy + ry * 0.2, w * 0.018, eyeY + ry * 0.1);
  ctx.closePath();
  const noseGrad = ctx.createRadialGradient(-w * 0.024, noseY + ry * 0.045, 0, w * 0.01, noseY + ry * 0.11, w * 0.11);
  noseGrad.addColorStop(0, L.light);
  noseGrad.addColorStop(0.58, L.mid);
  noseGrad.addColorStop(1, L.deep);
  ctx.fillStyle = noseGrad;
  ctx.fill();
  strokeInk(ctx, lw * 0.85);

  ell(ctx, -w * 0.028, noseY + ry * 0.055, w * 0.022, h * 0.016);
  ctx.fillStyle = "rgba(255, 250, 240, 0.48)";
  ctx.fill();
  for (const sgn of [-1, 1] as const) {
    ell(ctx, sgn * w * 0.043, noseY + ry * 0.16, w * 0.011, h * 0.006);
    ctx.fillStyle = "rgba(83, 48, 34, 0.62)";
    ctx.fill();
  }

  // Mouth
  const pout = blink;
  const mw = rx * (0.3 - pout * 0.06);
  ctx.beginPath();
  ctx.moveTo(-mw, mouthY + pout * h * 0.014);
  ctx.quadraticCurveTo(-mw * 0.4, mouthY - h * (0.018 + pout * 0.014), 0, mouthY - h * 0.01);
  ctx.quadraticCurveTo(mw * 0.4, mouthY - h * (0.018 + pout * 0.014), mw, mouthY + pout * h * 0.014);
  ctx.quadraticCurveTo(mw * 0.42, mouthY + h * (0.038 - pout * 0.02), 0, mouthY + h * (0.038 - pout * 0.02));
  ctx.quadraticCurveTo(-mw * 0.42, mouthY + h * (0.038 - pout * 0.02), -mw, mouthY + pout * h * 0.014);
  ctx.closePath();
  const lipGrad = ctx.createLinearGradient(0, mouthY - h * 0.02, 0, mouthY + h * 0.05);
  lipGrad.addColorStop(0, L.lip);
  lipGrad.addColorStop(1, "rgba(148, 82, 78, 0.92)");
  ctx.fillStyle = lipGrad;
  ctx.fill();
  ctx.strokeStyle = "rgba(92, 44, 42, 0.42)";
  ctx.lineWidth = Math.max(0.9, w * 0.008);
  ctx.stroke();

  // Curled Moustache
  const moustacheY = mouthY - h * 0.045;
  const moustacheGrad = ctx.createLinearGradient(0, moustacheY - h * 0.08, 0, moustacheY + h * 0.03);
  moustacheGrad.addColorStop(0, "#594033");
  moustacheGrad.addColorStop(0.5, "#30211b");
  moustacheGrad.addColorStop(1, "#1b1512");
  for (const sgn of [-1, 1] as const) {
    ctx.beginPath();
    ctx.moveTo(sgn * w * 0.008, moustacheY + h * 0.008);
    ctx.bezierCurveTo(sgn * w * 0.055, moustacheY - h * 0.025, sgn * w * 0.11, moustacheY - h * 0.065, sgn * w * 0.17, moustacheY - h * 0.045);
    ctx.quadraticCurveTo(sgn * w * 0.235, moustacheY - h * 0.022, sgn * w * 0.265, moustacheY - h * 0.085);
    ctx.quadraticCurveTo(sgn * w * 0.29, moustacheY - h * 0.03, sgn * w * 0.245, moustacheY + h * 0.012);
    ctx.bezierCurveTo(sgn * w * 0.17, moustacheY + h * 0.048, sgn * w * 0.09, moustacheY + h * 0.032, sgn * w * 0.035, moustacheY + h * 0.014);
    ctx.quadraticCurveTo(sgn * w * 0.018, moustacheY + h * 0.006, sgn * w * 0.008, moustacheY + h * 0.008);
    ctx.closePath();
    ctx.fillStyle = moustacheGrad;
    ctx.fill();
    strokeInk(ctx, Math.max(1.1, w * 0.014));
  }

  } else if (headImage) {
    // Use downloaded head sprite (season 5) — aspect-preserving, bottom-aligned
    const iw = headImage.naturalWidth;
    const ih = headImage.naturalHeight;
    const sc = Math.min(w / iw, h / ih);
    const dw = iw * sc;
    const dh = ih * sc;
    ctx.save();
    ctx.imageSmoothingEnabled = true;
    ctx.imageSmoothingQuality = "high";
    ctx.drawImage(headImage, -dw / 2, -dh, dw, dh);
    ctx.restore();
  }

  /* ================= 8. REVEAL: Top 1/3 Skull Slices Off + Exposed Brain ================= */
  if (e > 0.01) {
    ctx.save();

    // A. Open Skull Cavity Cross-Section Bowl (at cutY, above eyebrows)
    ell(ctx, 0, cutY, cutRx, cutRy);
    const cutBone = ctx.createLinearGradient(0, cutY - cutRy, 0, cutY + cutRy);
    cutBone.addColorStop(0, "#f8eedc");
    cutBone.addColorStop(0.4, "#ebd6b8");
    cutBone.addColorStop(1, "#cda982");
    ctx.fillStyle = cutBone;
    ctx.fill();
    strokeInk(ctx, Math.max(1.8, lw));

    // Inner cranial hollow (crimson lining + dark void)
    const innerRx = cutRx * 0.86;
    const innerRy = cutRy * 0.82;
    ell(ctx, 0, cutY, innerRx, innerRy);
    const cavityGrad = ctx.createRadialGradient(0, cutY - innerRy * 0.3, 0, 0, cutY, innerRx);
    cavityGrad.addColorStop(0, "#4a1c28");
    cavityGrad.addColorStop(0.7, "#280c14");
    cavityGrad.addColorStop(1, "#18040a");
    ctx.fillStyle = cavityGrad;
    ctx.fill();

    // B. Exposed Sliced Brain sitting inside & rising above the cut plane!
    const brainBaseY = cutY + cutRy * 0.45;
    const brainMaxW = cutRx * 1.82;
    const brainMaxH = ry * 1.15;
    drawSlicedBrain(ctx, 0, brainBaseY, brainMaxW, brainMaxH, value, o.id * 811 + 23, lw);

    // Cut rim bone highlight
    ctx.beginPath();
    ctx.ellipse(0, cutY, cutRx, cutRy, 0, Math.PI * 0.08, Math.PI * 0.92);
    ctx.strokeStyle = "rgba(255, 255, 245, 0.7)";
    ctx.lineWidth = Math.max(1.2, w * 0.012);
    ctx.stroke();


    ctx.restore();
  }

  void t;
}


function drawBox(ctx: CanvasRenderingContext2D, o: Item, t: number) {
  const { w, h, value, reveal } = o;

  if (boxImage?.complete && boxImage.naturalWidth > 0) {
    ctx.save();
    ctx.imageSmoothingEnabled = true;
    ctx.imageSmoothingQuality = "high";
    ctx.drawImage(boxImage, -w / 2, -h, w, h);

    // Keep the end-of-round contents reveal while replacing only the box artwork.
    if (reveal > 0.01) {
      ctx.globalAlpha = Math.min(1, reveal);
      const wx = -w * 0.06;
      const wy = -h * 0.64;
      const ww = w * 0.39;
      const wh = h * 0.57;
      rr(ctx, wx, wy, ww, wh, w * 0.025);
      ctx.fillStyle = "rgba(36,24,14,0.94)";
      ctx.fill();
      ctx.save();
      rr(ctx, wx, wy, ww, wh, w * 0.025);
      ctx.clip();
      const count = 1 + Math.round(value * 7);
      const step = wh * 0.105;
      const base = wy + wh * 0.91;
      for (let i = 0; i < count; i++) {
        const py = base - i * step;
        const plateW = ww * (0.42 + (i % 3) * 0.035);
        ell(ctx, wx + ww * 0.56, py, plateW, step * 0.39);
        ctx.fillStyle = i % 2 ? "#e4e8e4" : "#d4e0e4";
        ctx.fill();
        ctx.strokeStyle = i % 3 === 0 ? "#b36a50" : "#718fa4";
        ctx.lineWidth = Math.max(1, w * 0.012);
        ctx.stroke();
      }
      ctx.restore();
      rr(ctx, wx, wy, ww, wh, w * 0.025);
      ctx.strokeStyle = "rgba(255,231,190,0.78)";
      ctx.lineWidth = Math.max(1.4, w * 0.018);
      ctx.stroke();
    }

    ctx.restore();
    return;
  }

  const hw = w * 0.5;
  const depth = w * 0.19;
  const frontH = h * 0.76;
  const xL = -hw;
  const xR = hw - depth;
  const xBackR = hw;
  const xBackL = xL + depth;
  const yT = -frontH;
  const yBack = yT - depth * 0.57;
  const ySideB = -depth * 0.57;
  const line = Math.max(2, w * 0.03);
  const e = reveal * reveal * (3 - 2 * reveal);
  const kh = 29 + ((o.hue - 26) * 0.12);
  const rnd = rng(o.id * 619 + 37);
  const tapeW = w * 0.09;

  const topPath = () => {
    ctx.beginPath();
    ctx.moveTo(xL, yT);
    ctx.lineTo(xR, yT);
    ctx.lineTo(xBackR, yBack);
    ctx.lineTo(xBackL, yBack);
    ctx.closePath();
  };
  const frontPath = () => {
    ctx.beginPath();
    ctx.moveTo(xL, yT);
    ctx.lineTo(xR, yT);
    ctx.lineTo(xR, 0);
    ctx.lineTo(xL, 0);
    ctx.closePath();
  };
  const sidePath = () => {
    ctx.beginPath();
    ctx.moveTo(xR, yT);
    ctx.lineTo(xBackR, yBack);
    ctx.lineTo(xBackR, ySideB);
    ctx.lineTo(xR, 0);
    ctx.closePath();
  };

  // Side wall: darker kraft, a few shallow corrugation lines, and printed handling marks.
  sidePath();
  const sideG = ctx.createLinearGradient(xR, 0, xBackR, 0);
  sideG.addColorStop(0, `hsl(${kh}, 43%, 38%)`);
  sideG.addColorStop(1, `hsl(${kh - 1}, 40%, 28%)`);
  ctx.fillStyle = sideG;
  ctx.fill();
  ctx.save();
  sidePath();
  ctx.clip();
  ctx.strokeStyle = "rgba(255,228,184,0.09)";
  ctx.lineWidth = Math.max(0.7, w * 0.009);
  for (let i = 0; i < 8; i++) {
    const x = xR + depth * (0.12 + i * 0.105);
    ctx.beginPath();
    ctx.moveTo(x, yT + 4);
    ctx.lineTo(x + depth * 0.45, -3);
    ctx.stroke();
  }
  // two upward arrows, the familiar shipping mark
  ctx.strokeStyle = "rgba(245,226,190,0.78)";
  ctx.lineWidth = Math.max(1.4, w * 0.018);
  ctx.lineCap = "round";
  ctx.lineJoin = "round";
  for (let i = 0; i < 2; i++) {
    const ax = xR + depth * (0.3 + i * 0.38);
    const ay = yT + frontH * 0.54;
    ctx.beginPath();
    ctx.moveTo(ax, ay + 6);
    ctx.lineTo(ax, ay - 5);
    ctx.lineTo(ax - 3, ay - 1);
    ctx.moveTo(ax, ay - 5);
    ctx.lineTo(ax + 3, ay - 1);
    ctx.stroke();
  }
  ctx.restore();

  // Front wall: warm uncoated kraft with subtle paper grain and box-fold score lines.
  frontPath();
  const frontG = ctx.createLinearGradient(xL, yT, xR, 0);
  frontG.addColorStop(0, `hsl(${kh}, 43%, 41%)`);
  frontG.addColorStop(0.23, `hsl(${kh + 1}, 47%, 53%)`);
  frontG.addColorStop(0.72, `hsl(${kh}, 46%, 50%)`);
  frontG.addColorStop(1, `hsl(${kh - 1}, 40%, 39%)`);
  ctx.fillStyle = frontG;
  ctx.fill();
  ctx.save();
  frontPath();
  ctx.clip();

  // Sparse natural paper fibers; restrained so the carton still reads cleanly at game scale.
  for (let i = 0; i < 34; i++) {
    const px = xL + rnd() * (xR - xL);
    const py = yT + rnd() * frontH;
    const len = w * (0.018 + rnd() * 0.075);
    ctx.strokeStyle = rnd() > 0.48 ? "rgba(255,237,201,0.13)" : "rgba(78,42,17,0.12)";
    ctx.lineWidth = 0.5 + rnd() * 0.8;
    ctx.beginPath();
    ctx.moveTo(px, py);
    ctx.lineTo(px + len, py + (rnd() - 0.5) * 2.5);
    ctx.stroke();
  }

  // Long scored folds and a slightly compressed lower edge.
  ctx.strokeStyle = "rgba(88,48,20,0.24)";
  ctx.lineWidth = Math.max(0.8, w * 0.012);
  ctx.beginPath();
  ctx.moveTo(xL + 5, yT + 2);
  ctx.lineTo(xL + 5, -4);
  ctx.moveTo(xR - 5, yT + 2);
  ctx.lineTo(xR - 5, -4);
  ctx.moveTo(xL + 3, -4);
  ctx.lineTo(xR - 3, -4);
  ctx.stroke();
  ctx.strokeStyle = "rgba(255,235,197,0.16)";
  ctx.lineWidth = 1.1;
  ctx.beginPath();
  ctx.moveTo(xL + 5, yT + 4);
  ctx.lineTo(xL + 5, -7);
  ctx.stroke();

  // Printed recycling / carton stamp, intentionally small like real shipping print.
  ctx.fillStyle = "rgba(67,42,22,0.62)";
  ctx.textAlign = "left";
  ctx.font = `700 ${Math.max(6, w * 0.055)}px Vazirmatn, sans-serif`;
  ctx.fillText("گوش‌چین", xR - w * 0.27, yT + frontH * 0.31);
  ctx.font = `500 ${Math.max(5, w * 0.036)}px Vazirmatn, sans-serif`;
  ctx.fillText("کارتن بازیافتی", xR - w * 0.27, yT + frontH * 0.39);
  ctx.strokeStyle = "rgba(67,42,22,0.52)";
  ctx.lineWidth = Math.max(0.8, w * 0.012);
  ctx.beginPath();
  ctx.arc(xR - w * 0.16, yT + frontH * 0.55, w * 0.075, 0.55, 5.7);
  ctx.stroke();
  ctx.beginPath();
  ctx.moveTo(xR - w * 0.22, yT + frontH * 0.52);
  ctx.lineTo(xR - w * 0.17, yT + frontH * 0.47);
  ctx.lineTo(xR - w * 0.16, yT + frontH * 0.53);
  ctx.stroke();

  // Aged kraft shipping label with fragile-glass mark and a compact barcode.
  const lx = xL + w * 0.085;
  const ly = yT + frontH * 0.2;
  const labelW = w * 0.32;
  const labelH = frontH * 0.43;
  ctx.save();
  ctx.translate(lx + labelW / 2, ly + labelH / 2);
  ctx.rotate(-0.012);
  ctx.fillStyle = "#f1e3c7";
  rr(ctx, -labelW / 2, -labelH / 2, labelW, labelH, Math.max(2, w * 0.018));
  ctx.fill();
  ctx.strokeStyle = "rgba(87,57,30,0.48)";
  ctx.lineWidth = Math.max(0.9, w * 0.012);
  ctx.stroke();
  // small wine-glass pictogram
  const gx = -labelW * 0.28;
  const gy = -labelH * 0.17;
  ctx.strokeStyle = "#a64334";
  ctx.lineWidth = Math.max(1.2, w * 0.016);
  ctx.beginPath();
  ctx.moveTo(gx - labelW * 0.09, gy - labelH * 0.15);
  ctx.lineTo(gx + labelW * 0.09, gy - labelH * 0.15);
  ctx.quadraticCurveTo(gx + labelW * 0.07, gy + labelH * 0.08, gx, gy + labelH * 0.08);
  ctx.quadraticCurveTo(gx - labelW * 0.07, gy + labelH * 0.08, gx - labelW * 0.09, gy - labelH * 0.15);
  ctx.moveTo(gx, gy + labelH * 0.08);
  ctx.lineTo(gx, gy + labelH * 0.25);
  ctx.moveTo(gx - labelW * 0.07, gy + labelH * 0.25);
  ctx.lineTo(gx + labelW * 0.07, gy + labelH * 0.25);
  ctx.stroke();
  ctx.textAlign = "center";
  ctx.fillStyle = "#543b24";
  ctx.font = `700 ${Math.max(6, w * 0.058)}px Vazirmatn, sans-serif`;
  ctx.fillText("شکستنی", labelW * 0.18, -labelH * 0.02);
  ctx.font = `500 ${Math.max(5, w * 0.041)}px Vazirmatn, sans-serif`;
  ctx.fillText("ظروف آشپزخانه", labelW * 0.18, labelH * 0.15);
  // barcode at the foot of the label
  ctx.fillStyle = "rgba(49,39,29,0.75)";
  for (let i = 0; i < 17; i++) {
    const bw = i % 4 === 0 ? 1.6 : i % 2 === 0 ? 1 : 0.65;
    ctx.fillRect(-labelW * 0.4 + i * labelW * 0.024, labelH * 0.29, bw, labelH * 0.14);
  }
  ctx.restore();

  // Translucent brown packing tape, pressed across the front seam.
  const tapeG = ctx.createLinearGradient(-tapeW / 2, 0, tapeW / 2, 0);
  tapeG.addColorStop(0, "rgba(177,128,63,0.61)");
  tapeG.addColorStop(0.45, "rgba(242,205,137,0.76)");
  tapeG.addColorStop(1, "rgba(155,106,50,0.58)");
  ctx.fillStyle = tapeG;
  ctx.fillRect(-tapeW / 2, yT, tapeW, frontH * 0.72);
  ctx.strokeStyle = "rgba(255,238,194,0.3)";
  ctx.lineWidth = 1;
  ctx.beginPath();
  ctx.moveTo(-tapeW / 2 + 1, yT + 2);
  ctx.lineTo(-tapeW / 2 + 1, yT + frontH * 0.72);
  ctx.moveTo(tapeW / 2 - 1, yT + 2);
  ctx.lineTo(tapeW / 2 - 1, yT + frontH * 0.72);
  ctx.stroke();
  // paper-tape torn end
  ctx.beginPath();
  ctx.moveTo(-tapeW / 2, yT + frontH * 0.72);
  ctx.lineTo(-tapeW * 0.2, yT + frontH * 0.7);
  ctx.lineTo(0, yT + frontH * 0.73);
  ctx.lineTo(tapeW * 0.22, yT + frontH * 0.7);
  ctx.lineTo(tapeW / 2, yT + frontH * 0.72);
  ctx.strokeStyle = "rgba(101,68,35,0.44)";
  ctx.lineWidth = 1.2;
  ctx.stroke();
  ctx.restore();

  // Closed RSC top: four flaps meet at the center, then the tape crosses that seam.
  if (e < 0.995) {
    topPath();
    const topG = ctx.createLinearGradient(0, yBack, 0, yT);
    topG.addColorStop(0, `hsl(${kh + 2}, 44%, 61%)`);
    topG.addColorStop(1, `hsl(${kh}, 43%, 49%)`);
    ctx.fillStyle = topG;
    ctx.fill();

    // two long RSC flaps meet down the middle; a faint cross score suggests the short flaps
    ctx.strokeStyle = "rgba(89,52,24,0.55)";
    ctx.lineWidth = Math.max(1, w * 0.014);
    ctx.beginPath();
    ctx.moveTo(0, yT + 1);
    ctx.lineTo(depth, yBack + 1);
    ctx.moveTo(xL + depth * 0.52, (yT + yBack) / 2);
    ctx.lineTo(xR + depth * 0.46, (yT + yBack) / 2);
    ctx.stroke();

    // tape continuing over the top center seam
    ctx.beginPath();
    ctx.moveTo(-tapeW * 0.5, yT);
    ctx.lineTo(depth - tapeW * 0.5, yBack);
    ctx.lineTo(depth + tapeW * 0.5, yBack);
    ctx.lineTo(tapeW * 0.5, yT);
    ctx.closePath();
    ctx.fillStyle = "rgba(221,180,111,0.77)";
    ctx.fill();
    ctx.strokeStyle = "rgba(255,238,194,0.3)";
    ctx.lineWidth = 1;
    ctx.stroke();

    // light crease around the top edge and slightly worn corrugated corners
    topPath();
    ctx.strokeStyle = "rgba(255,233,194,0.56)";
    ctx.lineWidth = Math.max(1.2, w * 0.016);
    ctx.stroke();
  }

  // Reveal: the carton opens like a regular slotted shipping box.
  if (e > 0.01) {
    // rear major flap, raised behind the parcel
    ctx.save();
    ctx.globalAlpha = e;
    ctx.beginPath();
    ctx.moveTo(xBackL, yBack);
    ctx.lineTo(xBackR, yBack);
    ctx.lineTo(xBackR - depth * 0.08, yBack - depth * 0.95);
    ctx.lineTo(xBackL + depth * 0.06, yBack - depth * 0.92);
    ctx.closePath();
    const flapG = ctx.createLinearGradient(0, yBack - depth, 0, yBack);
    flapG.addColorStop(0, `hsl(${kh + 1}, 43%, 57%)`);
    flapG.addColorStop(1, `hsl(${kh}, 42%, 44%)`);
    ctx.fillStyle = flapG;
    ctx.fill();
    strokeInk(ctx, line * 0.72);
    ctx.restore();

    // dark interior with an irregular layer of packing paper
    ctx.save();
    ctx.globalAlpha = e;
    topPath();
    const insideG = ctx.createLinearGradient(0, yBack, 0, yT);
    insideG.addColorStop(0, "#392719");
    insideG.addColorStop(1, "#1e170f");
    ctx.fillStyle = insideG;
    ctx.fill();
    strokeInk(ctx, line * 0.7);
    ctx.save();
    topPath();
    ctx.clip();
    ctx.beginPath();
    ctx.moveTo(xL + depth * 0.12, yT - depth * 0.05);
    ctx.quadraticCurveTo(-w * 0.15, yT - depth * 0.4, depth * 0.48, yBack + depth * 0.1);
    ctx.quadraticCurveTo(xR, yT - depth * 0.25, xR + depth * 0.03, yT - depth * 0.02);
    ctx.closePath();
    ctx.fillStyle = "rgba(221,190,137,0.66)";
    ctx.fill();
    ctx.strokeStyle = "rgba(255,234,193,0.42)";
    ctx.lineWidth = Math.max(1, w * 0.014);
    ctx.stroke();

    // reveal a few ceramic rims on top of the packing
    const topItems = 1 + Math.round(value * 3);
    for (let i = 0; i < topItems; i++) {
      const px = xL + depth * (0.55 + (i * 0.31) % 1.2);
      const py = yT - depth * (0.12 + (i % 2) * 0.11);
      ell(ctx, px, py, w * 0.085, depth * 0.12);
      ctx.fillStyle = i % 2 ? "#e8e3d6" : "#d4e1e6";
      ctx.fill();
      ctx.strokeStyle = "#8c7560";
      ctx.lineWidth = 1.2;
      ctx.stroke();
    }
    ctx.restore();

    // front cutaway shows the stack height without leaking the answer before the reveal
    const wx = xL + w * 0.44;
    const wy = yT + frontH * 0.16;
    const ww = w * 0.39;
    const wh = frontH * 0.75;
    ctx.fillStyle = "rgba(36,24,14,0.94)";
    rr(ctx, wx, wy, ww, wh, w * 0.025);
    ctx.fill();
    ctx.save();
    rr(ctx, wx, wy, ww, wh, w * 0.025);
    ctx.clip();

    // corrugated cut edge: liner / fluting / liner layers
    ctx.fillStyle = "#bd8a55";
    ctx.fillRect(wx, wy, w * 0.025, wh);
    ctx.fillStyle = "#e0b678";
    ctx.fillRect(wx + w * 0.025, wy, w * 0.018, wh);
    ctx.fillStyle = "#987049";
    ctx.fillRect(wx + w * 0.043, wy, w * 0.012, wh);
    for (let y = wy + 2; y < wy + wh - 2; y += 5) {
      ctx.beginPath();
      ctx.moveTo(wx + w * 0.025, y);
      ctx.quadraticCurveTo(wx + w * 0.034, y + 2.5, wx + w * 0.043, y + 5);
      ctx.strokeStyle = "rgba(103,68,39,0.65)";
      ctx.lineWidth = 1;
      ctx.stroke();
    }

    const count = 1 + Math.round(value * 7);
    const step = wh * 0.105;
    const base = wy + wh * 0.91;
    for (let i = 0; i < count; i++) {
      const py = base - i * step;
      const plateW = ww * (0.42 + (i % 3) * 0.035);
      // softly visible contents behind the cut edge
      ctx.fillStyle = i % 2 ? "rgba(204,219,225,0.26)" : "rgba(226,207,178,0.22)";
      ell(ctx, wx + ww * 0.56, py - step * 0.22, plateW * 0.88, step * 0.65);
      ctx.fill();
      // stacked ceramic plate with an inset rim
      ell(ctx, wx + ww * 0.56, py, plateW, step * 0.39);
      ctx.fillStyle = i % 2 ? "#e4e8e4" : "#d4e0e4";
      ctx.fill();
      ctx.strokeStyle = i % 3 === 0 ? "#b36a50" : "#718fa4";
      ctx.lineWidth = Math.max(1, w * 0.012);
      ctx.stroke();
      ell(ctx, wx + ww * 0.56, py, plateW * 0.7, step * 0.2);
      ctx.strokeStyle = "rgba(255,255,255,0.56)";
      ctx.lineWidth = 0.8;
      ctx.stroke();
    }
    ctx.restore();
    ctx.strokeStyle = "rgba(255,231,190,0.78)";
    ctx.lineWidth = Math.max(1.4, w * 0.018);
    rr(ctx, wx, wy, ww, wh, w * 0.025);
    ctx.stroke();

    // side flaps fold out to either side
    ctx.beginPath();
    ctx.moveTo(xL, yT);
    ctx.lineTo(xBackL, yBack);
    ctx.lineTo(xL - depth * 0.52, yBack - depth * 0.02);
    ctx.lineTo(xL - depth * 0.4, yT + depth * 0.24);
    ctx.closePath();
    ctx.fillStyle = `hsl(${kh}, 42%, 51%)`;
    ctx.fill();
    strokeInk(ctx, line * 0.72);

    ctx.beginPath();
    ctx.moveTo(xR, yT);
    ctx.lineTo(xBackR, yBack);
    ctx.lineTo(xBackR + depth * 0.48, yBack + depth * 0.07);
    ctx.lineTo(xR + depth * 0.42, yT + depth * 0.26);
    ctx.closePath();
    ctx.fillStyle = `hsl(${kh - 1}, 39%, 40%)`;
    ctx.fill();
    strokeInk(ctx, line * 0.72);

    // front major flap folds down toward the viewer
    ctx.beginPath();
    ctx.moveTo(xL, yT);
    ctx.lineTo(xR, yT);
    ctx.lineTo(xR - depth * 0.08, yT + depth * 0.72);
    ctx.lineTo(xL + depth * 0.08, yT + depth * 0.72);
    ctx.closePath();
    const ff = ctx.createLinearGradient(0, yT, 0, yT + depth);
    ff.addColorStop(0, `hsl(${kh + 1}, 43%, 50%)`);
    ff.addColorStop(1, `hsl(${kh}, 40%, 41%)`);
    ctx.fillStyle = ff;
    ctx.fill();
    strokeInk(ctx, line * 0.75);
    ctx.restore();
  }

  // Carton outline, board thickness at corners, and a small glint on the tape.
  frontPath();
  strokeInk(ctx, line);
  sidePath();
  strokeInk(ctx, line);
  ctx.strokeStyle = "rgba(255,230,190,0.35)";
  ctx.lineWidth = Math.max(1, w * 0.012);
  ctx.beginPath();
  ctx.moveTo(xL + 2, yT + 4);
  ctx.lineTo(xL + 2, -4);
  ctx.moveTo(xR - 2, yT + 4);
  ctx.lineTo(xR - 2, -4);
  ctx.stroke();

  const glintY = yT + ((t * 12 + o.seed * 9) % Math.max(8, frontH * 0.72));
  ctx.strokeStyle = "rgba(255,246,221,0.12)";
  ctx.lineWidth = 1.2;
  ctx.beginPath();
  ctx.moveTo(-tapeW * 0.38, glintY);
  ctx.lineTo(tapeW * 0.38, glintY + 1);
  ctx.stroke();
}

export function drawItemBody(ctx: CanvasRenderingContext2D, o: Item, t: number) {
  switch (o.type) {
    case "glass":
      return drawGlass(ctx, o, t);
    case "can":
      return drawCan(ctx, o, t);
    case "melon":
      return drawMelon(ctx, o, t);
    case "box":
      return drawBox(ctx, o, t);
    case "head":
      return drawHead(ctx, o, t);
  }
}

/** knock rings + sparkles drawn right after the object */
export function drawKnockFx(ctx: CanvasRenderingContext2D, o: Item, t: number) {
  const k = o.knock;
  if (k <= 0) return;
  const p = 1 - Math.min(1, k / 0.4);
  if (p <= 0) return;
  const r = o.w * (0.42 + (1 - p) * 0.62);
  ctx.save();
  ctx.globalAlpha = p * 0.5;
  ctx.strokeStyle = TYPE_META[o.type].accent;
  ctx.lineWidth = 1.5 + p * 2.5;
  ell(ctx, 0, -o.h * 0.55, r, r * 0.58);
  ctx.stroke();
  ctx.globalAlpha = p * 0.24;
  ell(ctx, 0, -o.h * 0.55, r * 1.28, r * 0.8);
  ctx.stroke();
  ctx.restore();
  void t;
}

/** assist: little oscilloscope showing the pitch of the last knock */
export function drawAssist(ctx: CanvasRenderingContext2D, o: Item, period: number) {
  const k = o.knock;
  if (k > 1.6) return;
  const alpha = k < 0.2 ? k / 0.2 : 1 - Math.max(0, (k - 1) / 0.6);
  const ww = o.w * 1.1;
  ctx.save();
  ctx.globalAlpha = Math.max(0, alpha) * 0.95;
  ctx.translate(-ww / 2, -o.h - o.w * 0.42);
  ctx.fillStyle = "rgba(8,16,28,0.6)";
  rr(ctx, -4, -8, ww + 8, 16, 8);
  ctx.fill();
  ctx.strokeStyle = period > 26 ? "#ff8f6b" : period > 17 ? "#ffc453" : "#7ad9ff";
  ctx.lineWidth = 2.2;
  ctx.beginPath();
  for (let x = 0; x <= ww; x += 2) {
    const y = Math.sin((x / period) * Math.PI * 2) * 5;
    if (x === 0) ctx.moveTo(x, y);
    else ctx.lineTo(x, y);
  }
  ctx.stroke();
  ctx.restore();
}
