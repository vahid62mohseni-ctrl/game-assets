/**
 * گوش‌چین — audio engine
 * All sounds are synthesized with WebAudio so the game stays dependency free.
 * Core rule of the design: the FULLER an object is, the LOWER (بم‌تر) its knock pitch.
 */

export type KnockType = "glass" | "can" | "melon" | "box" | "head";

const PENTA = [523.25, 587.33, 659.25, 783.99, 880.0, 1046.5, 1174.7, 1318.5, 1567.98];

export class AudioEngine {
  private ac: AudioContext | null = null;
  private master: GainNode | null = null;
  private wet: GainNode | null = null;
  private noiseBuf: AudioBuffer | null = null;
  private musicGain: GainNode | null = null;
  private musicTimer: number | null = null;
  private musicStep = 0;
  muted = false;
  musicOn = false;

  ensure(): AudioContext | null {
    if (typeof window === "undefined") return null;
    if (!this.ac) {
      const AC: typeof AudioContext =
        window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (!AC) return null;
      try {
        this.ac = new AC();
      } catch {
        return null;
      }
      const ac = this.ac;
      this.master = ac.createGain();
      this.master.gain.value = this.muted ? 0 : 0.9;
      const comp = ac.createDynamicsCompressor();
      comp.threshold.value = -14;
      comp.ratio.value = 7;
      comp.attack.value = 0.003;
      comp.release.value = 0.18;
      this.master.connect(comp).connect(ac.destination);

      // tiny algorithmic reverb for satisfying "room" knocks
      const conv = ac.createConvolver();
      const len = Math.floor(ac.sampleRate * 1.1);
      const buf = ac.createBuffer(2, len, ac.sampleRate);
      for (let c = 0; c < 2; c++) {
        const d = buf.getChannelData(c);
        for (let i = 0; i < len; i++) {
          d[i] = (Math.random() * 2 - 1) * Math.pow(1 - i / len, 3.2);
        }
      }
      conv.buffer = buf;
      this.wet = ac.createGain();
      this.wet.gain.value = 0.24;
      this.wet.connect(conv).connect(this.master);

      // noise buffer
      const nlen = Math.floor(ac.sampleRate * 1.2);
      this.noiseBuf = ac.createBuffer(1, nlen, ac.sampleRate);
      const nd = this.noiseBuf.getChannelData(0);
      for (let i = 0; i < nlen; i++) nd[i] = Math.random() * 2 - 1;

      this.musicGain = ac.createGain();
      this.musicGain.gain.value = 0.0;
      this.musicGain.connect(this.master);
    }
    if (this.ac.state === "suspended") void this.ac.resume();
    return this.ac;
  }

  setMuted(m: boolean) {
    this.muted = m;
    if (this.master && this.ac) {
      this.master.gain.setTargetAtTime(m ? 0 : 0.9, this.ac.currentTime, 0.05);
    }
  }

  // ---------- primitives ----------
  private osc(
    ac: AudioContext,
    opts: {
      type?: OscillatorType;
      f0: number;
      f1?: number;
      t0: number;
      dur: number;
      peak: number;
      attack?: number;
      dest?: AudioNode;
      sendWet?: number;
      detune?: number;
    },
  ) {
    const o = ac.createOscillator();
    const g = ac.createGain();
    o.type = opts.type ?? "sine";
    if (opts.detune) o.detune.value = opts.detune;
    o.frequency.setValueAtTime(Math.max(20, opts.f0), opts.t0);
    if (opts.f1) o.frequency.exponentialRampToValueAtTime(Math.max(20, opts.f1), opts.t0 + opts.dur);
    const atk = opts.attack ?? 0.004;
    g.gain.setValueAtTime(0.0001, opts.t0);
    g.gain.exponentialRampToValueAtTime(Math.max(0.0002, opts.peak), opts.t0 + atk);
    g.gain.exponentialRampToValueAtTime(0.0001, opts.t0 + opts.dur);
    o.connect(g);
    g.connect(opts.dest ?? ac.destination);
    if (opts.sendWet && this.wet) {
      const s = ac.createGain();
      s.gain.value = opts.sendWet;
      g.connect(s).connect(this.wet);
    }
    o.start(opts.t0);
    o.stop(opts.t0 + opts.dur + 0.05);
  }

  private noise(
    ac: AudioContext,
    opts: {
      f0: number;
      f1?: number;
      q?: number;
      type?: BiquadFilterType;
      t0: number;
      dur: number;
      peak: number;
      sendWet?: number;
      dest?: AudioNode;
    },
  ) {
    if (!this.noiseBuf) return;
    const src = ac.createBufferSource();
    src.buffer = this.noiseBuf;
    src.playbackRate.value = 0.85 + Math.random() * 0.4;
    const filt = ac.createBiquadFilter();
    filt.type = opts.type ?? "bandpass";
    filt.frequency.setValueAtTime(Math.max(40, opts.f0), opts.t0);
    if (opts.f1) filt.frequency.exponentialRampToValueAtTime(Math.max(40, opts.f1), opts.t0 + opts.dur);
    filt.Q.value = opts.q ?? 1.2;
    const g = ac.createGain();
    g.gain.setValueAtTime(0.0001, opts.t0);
    g.gain.exponentialRampToValueAtTime(Math.max(0.0002, opts.peak), opts.t0 + 0.006);
    g.gain.exponentialRampToValueAtTime(0.0001, opts.t0 + opts.dur);
    src.connect(filt).connect(g);
    g.connect(opts.dest ?? this.master!);
    if (opts.sendWet && this.wet) {
      const s = ac.createGain();
      s.gain.value = opts.sendWet;
      g.connect(s).connect(this.wet);
    }
    src.start(opts.t0, Math.random() * 0.4);
    src.stop(opts.t0 + opts.dur + 0.05);
  }

  /** Reference pitch (Hz) for a given fill value — used by the assist meter too. */
  static pitchFor(type: KnockType, v: number): number {
    const x = Math.min(1, Math.max(0, v));
    switch (type) {
      case "glass":
        return 340 + (1 - x) * 830;
      case "can":
        return 205 + (1 - x) * 175;
      case "melon":
        return 84 + (1 - x) * 120;
      case "box":
        // جعبهٔ پُر پایین و جعبهٔ خالی بالاتر است؛ فاصلهٔ فرکانس برای تشخیص روشن‌تر بازتر شده.
        return 78 + (1 - x) * 236;
      case "head":
        // سرِ پُر سیلیِ بم و گوشتی؛ سرِ خالی سیلیِ زیر و تیز.
        // بیش از سه اکتاو فاصله تا تفکیک با گوش به‌راحتی انجام شود.
        return 92 + (1 - x) * 838;
    }
  }

  // ---------- game sounds ----------
  knock(type: KnockType, value: number) {
    const ac = this.ensure();
    if (!ac || this.muted) return;
    const t = ac.currentTime + 0.001;
    const f = AudioEngine.pitchFor(type, value);

    if (type === "glass") {
      this.osc(ac, { type: "sine", f0: f, f1: f * 0.995, t0: t, dur: 1.15, peak: 0.34, sendWet: 0.5 });
      this.osc(ac, { type: "sine", f0: f * 2.72, t0: t, dur: 0.42, peak: 0.11, sendWet: 0.35 });
      this.osc(ac, { type: "triangle", f0: f * 4.2, t0: t, dur: 0.16, peak: 0.05 });
      this.noise(ac, { f0: f * 3.1, f1: f * 1.2, q: 0.9, t0: t, dur: 0.06, peak: 0.16 });
      // liquid body
      this.noise(ac, { type: "lowpass", f0: 520 + f * 0.35, f1: 180, q: 3, t0: t, dur: 0.16, peak: 0.1 });
    } else if (type === "can") {
      // --- قوطی فلزی ---
      // هرچه پُرتر: زنگِ بدنه زودتر می‌میرد و صدا خفه‌تر و بم‌تر می‌شود.
      const full = value;
      const ringDur = 0.1 + (1 - full) * 1.05; // قوطی خالی تا ~۱٫۱ ثانیه زنگ می‌زند
      const ringAmt = 1 - full * 0.74; // حبوبات ارتعاش بدنه را می‌خورد

      // مدهای استوانه‌ای فلز — ناهماهنگ (inharmonic)، دقیقاً مثل قوطی واقعی
      const modes = [1, 1.82, 2.67, 3.61, 4.48];
      modes.forEach((m, i) => {
        this.osc(ac, {
          type: i === 0 ? "triangle" : "sine",
          f0: f * m,
          f1: f * m * 0.994,
          t0: t + i * 0.0012,
          dur: Math.max(0.05, ringDur / (1 + i * 0.34)),
          peak: (0.2 * ringAmt) / (1 + i * 1.05),
          sendWet: 0.42,
        });
      });

      // برخورد ناخن/انگشت با ورق فلز: کلیکِ خیلی کوتاه و روشن
      this.noise(ac, { f0: 4300 - full * 1700, f1: 1500, q: 1.1, t0: t, dur: 0.028, peak: 0.2 });
      this.noise(ac, { type: "highpass", f0: 3100, q: 0.7, t0: t, dur: 0.016, peak: 0.11 });

      // تپِ جرم محتویات: قوطیِ پُر یک تقِ بم و توپُر دارد
      this.osc(ac, {
        type: "sine",
        f0: 155 + full * 45,
        f1: 68,
        t0: t,
        dur: 0.12 + full * 0.13,
        peak: 0.11 + full * 0.24,
      });
      this.noise(ac, {
        type: "lowpass",
        f0: 460 + full * 220,
        f1: 120,
        q: 1.2,
        t0: t,
        dur: 0.09 + full * 0.09,
        peak: 0.1 + full * 0.17,
      });

      // خوردنِ حبوبات به هم: تیک‌های ریز؛ در قوطیِ خالی بیشتر و جلق‌تر
      const grains = Math.round(1 + (1 - full) * 9);
      for (let i = 0; i < grains; i++) {
        this.noise(ac, {
          f0: (full > 0.6 ? 900 : 1500) + Math.random() * (full > 0.6 ? 1300 : 2600),
          q: 7,
          t0: t + 0.02 + Math.random() * (0.06 + (1 - full) * 0.22),
          dur: 0.018 + Math.random() * 0.022,
          peak: 0.012 + (1 - full) * 0.055,
        });
      }

      // نشستِ جرم در قوطیِ پر: غرشِ کوتاهِ بم
      if (full > 0.42) {
        this.noise(ac, {
          type: "lowpass",
          f0: 320,
          f1: 85,
          q: 1,
          t0: t + 0.028,
          dur: 0.17,
          peak: (full - 0.42) * 0.34,
        });
      }

      // برگشتِ دومِ ورق فلز (دوبونس)
      this.osc(ac, {
        type: "triangle",
        f0: f * 1.03,
        f1: f * 0.99,
        t0: t + 0.052,
        dur: Math.max(0.05, ringDur * 0.42),
        peak: 0.055 * ringAmt,
        sendWet: 0.3,
      });
    } else if (type === "melon") {
      const hollow = 0.5 + value * 0.6;
      this.osc(ac, { type: "sine", f0: f, f1: f * 0.86, t0: t, dur: 0.5 + hollow * 0.5, peak: 0.42, attack: 0.006, sendWet: 0.55 });
      this.osc(ac, { type: "sine", f0: f * 1.98, f1: f * 1.7, t0: t, dur: 0.24, peak: 0.11 });
      this.osc(ac, { type: "triangle", f0: f * 3.4, t0: t, dur: 0.09, peak: 0.05 * (1 - value * 0.6) });
      this.noise(ac, { type: "lowpass", f0: 900 - value * 420, f1: 200, q: 1.2, t0: t, dur: 0.13, peak: 0.13 });
    } else if (type === "box") {
      // --- ضربهٔ یک‌تکه به کارتن مقوایی ---
      // یک برخورد خشک و کوتاه، به‌علاوهٔ رزونانسِ پنل؛ بدون لایه‌های خیس/قل‌قل‌مانند.
      const full = value;
      const empty = 1 - full;

      // صدای تماس دست با کاغذ کرافت: خشِ کوتاه و پهن‌باند
      this.noise(ac, {
        type: "bandpass",
        f0: 920 - full * 220,
        f1: 470,
        q: 0.72,
        t0: t,
        dur: 0.024 + empty * 0.01,
        peak: 0.22,
      });

      // نوسانِ صفحه‌های مقوا؛ جعبهٔ خالی کمی بیشتر می‌لرزد و پُر زودتر خفه می‌شود
      [1, 1.58, 2.24].forEach((m, i) => {
        this.osc(ac, {
          type: i === 0 ? "triangle" : "sine",
          f0: f * m,
          f1: f * m * (0.72 - i * 0.035),
          t0: t + i * 0.002,
          dur: (0.1 + empty * 0.22) / (1 + i * 0.65),
          peak: (0.2 * (0.72 + empty * 0.28)) / (1 + i * 1.15),
          sendWet: 0.07,
        });
      });

      // وزنِ محتویات داخل کارتن، فقط یک تپِ بم و کوتاه زیرِ ضربه
      this.osc(ac, {
        type: "triangle",
        f0: 68 + empty * 24,
        f1: 43,
        t0: t,
        dur: 0.105 + full * 0.055,
        peak: 0.1 + full * 0.16,
      });
    } else {
      // --- سیلیِ کف دست به گونه: فقط نویز، بدون هیچ نوسانِ طبل‌مانند ---
      // ساختار و جنس صدا همان نسخهٔ تأییدشده است؛ فقط بلندی (peak) و
      // گسترهٔ ضریب «k» بیشتر شده تا زیر و بمی گزینه‌ها واضح‌تر تفکیک شود.
      const full = value;
      const empty = 1 - full;
      // گسترهٔ فرکانسی خیلی پهن‌تر: حدود ۵ برابر بین پُرترین و خالی‌ترین
      const k = 0.32 * Math.pow(6.2, empty); // نِمایی: ۰٫۳۲ تا ۱٫۹۸ — هر پله ~۱٫۵ برابر
      // بلندی صدا هم با پُری تغییر می‌کند: سرِ پُر بلندتر، سرِ خالی کم‌صداتر
      const loud = 0.14 * Math.pow(8.5, full); // ۰٫۱۴ تا ۱٫۱۹ — هر پله ~۱٫۳۵ برابر بلندتر // ۰٫۳ (خالی) تا ۱٫۲۵ (پُر) — تفاوت بلندیِ کاملاً محسوس
      const crack = t + 0.012;

      // هوای عبوری از کف دست، خیلی کوتاه و کم‌حجم
      this.noise(ac, {
        type: "highpass",
        f0: 2400 * k,
        q: 0.55,
        t0: t,
        dur: 0.014,
        peak: 0.03 * loud,
      });

      // ترکِ سیلی روی پوست — هستهٔ صدا
      this.noise(ac, {
        type: "highpass",
        f0: 2100 * k,
        q: 0.5,
        t0: crack,
        dur: 0.018 + empty * 0.012,
        peak: 0.2 * loud,
      });
      this.noise(ac, {
        type: "bandpass",
        f0: 1650 * k,
        f1: 900 * k,
        q: 1.1,
        t0: crack,
        dur: 0.03,
        peak: 0.09 * loud,
      });

      // گوشت گونه: بم و سنگین برای پُر، نازک برای خالی
      this.noise(ac, {
        type: "lowpass",
        f0: 780 * k,
        f1: 240 * k,
        q: 0.7,
        t0: crack,
        dur: 0.04 + full * 0.02,
        peak: (0.06 + full * 0.1) * loud,
      });

      // خشِ پوست و مو
      this.noise(ac, {
        type: "bandpass",
        f0: 1100 * k,
        f1: 520 * k,
        q: 1.4,
        t0: crack + 0.004,
        dur: 0.024,
        peak: (0.05 + empty * 0.1) * loud,
      });

      // تشدید باریک روی همان نویز: گامِ صدا (بم/زیر) را قابل تشخیص می‌کند
      const ring = 80 * Math.pow(21, empty); // ۸۰ تا ۱۶۸۰ هرتز با پله‌های مساوی // ۹۵ تا ۱۴۲۵ هرتز — بازهٔ بسیار پهن برای بم/زیر
      this.noise(ac, {
        type: "bandpass",
        f0: ring,
        f1: ring * 0.98,
        q: 34,
        t0: crack,
        dur: 0.34 + empty * 0.2,
        peak: 0.5 * loud,
        sendWet: 0.22,
      });
      this.noise(ac, {
        type: "bandpass",
        f0: ring * 2,
        f1: ring * 1.97,
        q: 24,
        t0: crack,
        dur: 0.1,
        peak: 0.3 * loud,
      });

      // کوتاه و خوش‌گام: ارتفاعِ صدا با پُری سر تغییر می‌کند (۱۸۰ تا ۶۴۰ هرتز)
      const tone = 170 * Math.pow(4.6, empty); // ۱۷۰ تا ۷۸۰ هرتز با پله‌های مساوی
      this.osc(ac, {
        type: "triangle",
        f0: tone * 1.5,
        f1: tone,
        attack: 0.001,
        t0: crack,
        dur: 0.085 + full * 0.05,
        peak: 0.62 * loud,
        sendWet: 0.1,
      });
      this.osc(ac, {
        type: "sine",
        f0: tone * 2,
        f1: tone * 1.9,
        attack: 0.001,
        t0: crack,
        dur: 0.045,
        peak: 0.16 * loud,
      });
    }
  }

  place(combo: number) {
    const ac = this.ensure();
    if (!ac || this.muted) return;
    const t = ac.currentTime;
    const f = PENTA[Math.min(combo, PENTA.length - 1)];
    this.osc(ac, { type: "triangle", f0: f, t0: t, dur: 0.24, peak: 0.2 });
    this.osc(ac, { type: "sine", f0: f * 2, t0: t, dur: 0.18, peak: 0.09, sendWet: 0.4 });
    this.noise(ac, { type: "lowpass", f0: 700, f1: 200, q: 1, t0: t, dur: 0.08, peak: 0.12 });
  }

  thunk() {
    const ac = this.ensure();
    if (!ac || this.muted) return;
    const t = ac.currentTime;
    this.noise(ac, { type: "lowpass", f0: 460, f1: 120, q: 1.4, t0: t, dur: 0.1, peak: 0.2 });
  }

  error() {
    const ac = this.ensure();
    if (!ac || this.muted) return;
    const t = ac.currentTime;
    this.osc(ac, { type: "sawtooth", f0: 230, f1: 70, t0: t, dur: 0.38, peak: 0.16 });
    this.osc(ac, { type: "square", f0: 118, f1: 58, t0: t + 0.02, dur: 0.3, peak: 0.08 });
    this.noise(ac, { type: "bandpass", f0: 800, f1: 200, q: 1, t0: t, dur: 0.22, peak: 0.12 });
  }

  sparkle() {
    const ac = this.ensure();
    if (!ac || this.muted) return;
    const t = ac.currentTime;
    [1568, 2093, 2637].forEach((f, i) =>
      this.osc(ac, { type: "sine", f0: f, t0: t + i * 0.045, dur: 0.3, peak: 0.07, sendWet: 0.5 }),
    );
  }

  levelClear() {
    const ac = this.ensure();
    if (!ac || this.muted) return;
    const t = ac.currentTime;
    [523.25, 659.25, 783.99, 1046.5].forEach((f, i) => {
      this.osc(ac, { type: "triangle", f0: f, t0: t + i * 0.09, dur: 0.42, peak: 0.2, sendWet: 0.45 });
      this.osc(ac, { type: "sine", f0: f * 2, t0: t + i * 0.09, dur: 0.28, peak: 0.07 });
    });
    this.noise(ac, { type: "highpass", f0: 3200, q: 0.7, t0: t + 0.1, dur: 0.5, peak: 0.06, sendWet: 0.6 });
  }

  gameOver() {
    const ac = this.ensure();
    if (!ac || this.muted) return;
    const t = ac.currentTime;
    [440, 392, 330, 262].forEach((f, i) =>
      this.osc(ac, { type: "triangle", f0: f, f1: f * 0.97, t0: t + i * 0.13, dur: 0.5, peak: 0.17, sendWet: 0.4 }),
    );
    this.noise(ac, { type: "lowpass", f0: 400, f1: 90, q: 1, t0: t, dur: 0.6, peak: 0.14 });
  }

  click(high = false) {
    const ac = this.ensure();
    if (!ac || this.muted) return;
    const t = ac.currentTime;
    this.osc(ac, { type: "sine", f0: high ? 1180 : 760, f1: high ? 820 : 520, t0: t, dur: 0.09, peak: 0.11 });
    this.noise(ac, { type: "highpass", f0: 2600, q: 0.8, t0: t, dur: 0.03, peak: 0.05 });
  }

  tick() {
    const ac = this.ensure();
    if (!ac || this.muted) return;
    this.osc(ac, { type: "sine", f0: 1500, t0: ac.currentTime, dur: 0.06, peak: 0.05 });
  }

  // ---------- ambient menu music ----------
  setMusic(on: boolean) {
    this.musicOn = on;
    const ac = this.ensure();
    if (!ac || !this.musicGain) return;
    this.musicGain.gain.setTargetAtTime(on && !this.muted ? 0.18 : 0, ac.currentTime, 0.4);
    if (on && this.musicTimer === null) {
      this.musicTimer = window.setInterval(() => this.musicTick(), 470);
    }
  }

  private musicTick() {
    const ac = this.ac;
    if (!ac || !this.musicGain || this.muted || !this.musicOn) return;
    const t = ac.currentTime + 0.01;
    const pattern = [0, 2, 1, 4, 3, 1, 5, 2];
    const idx = pattern[this.musicStep % pattern.length];
    const scale = [392, 440, 523.25, 587.33, 659.25, 783.99];
    this.osc(ac, {
      type: "triangle",
      f0: scale[idx % scale.length],
      t0: t,
      dur: 0.9,
      peak: 0.09,
      dest: this.musicGain,
    });
    if (this.musicStep % 4 === 0) {
      this.osc(ac, { type: "sine", f0: 130.8, t0: t, dur: 1.4, peak: 0.3, dest: this.musicGain });
    }
    if (this.musicStep % 2 === 1) {
      this.noise(ac, {
        type: "highpass",
        f0: 6200,
        q: 0.8,
        t0: t + 0.22,
        dur: 0.05,
        peak: 0.05,
        dest: this.musicGain!,
      });
    }
    this.musicStep++;
  }
}

export const audio = new AudioEngine();
