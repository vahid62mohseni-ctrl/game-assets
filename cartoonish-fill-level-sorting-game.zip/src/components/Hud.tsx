import { AudioLines, Heart, Pause, Sparkles, Volume2, VolumeX } from "lucide-react";
import type { UiState } from "../game/engine";
import { fmt } from "../game/config";

const fa = (n: number) => Math.round(n).toLocaleString("fa-IR");

function IconButton({
  label,
  onClick,
  active,
  children,
}: {
  label: string;
  onClick: () => void;
  active?: boolean;
  children: React.ReactNode;
}) {
  return (
    <button
      onClick={onClick}
      title={label}
      aria-label={label}
      className={`btn-3d grid size-10 place-items-center rounded-xl border sm:size-11 ${
        active
          ? "border-amber-glow/70 bg-amber-glow/25 text-amber-glow"
          : "border-cream/15 bg-night-900/55 text-cream/75 hover:text-cream"
      }`}
    >
      {children}
    </button>
  );
}

export default function Hud({
  ui,
  onPause,
  onMute,
  onAssist,
}: {
  ui: UiState;
  onPause: () => void;
  onMute: () => void;
  onAssist: () => void;
}) {
  const pct = ui.timeLimit ? Math.max(0, Math.min(1, ui.timeLeft / ui.timeLimit)) : 1;
  const danger = ui.timeLeft <= 6;
  const barColor = pct > 0.55 ? "bg-mint" : pct > 0.25 ? "bg-amber-glow" : "bg-berry";
  const playing =
    ui.phase === "playing" || ui.phase === "paused" || ui.phase === "levelclear" || ui.phase === "roundfailed";

  return (
    <div className="pointer-events-none absolute inset-x-0 top-0 z-20 select-none p-2 sm:p-3">
      <div className="mx-auto flex w-full max-w-5xl items-start justify-between gap-2">
        {/* level + lives */}
        <div className="flex flex-col gap-1.5">
          <div className="chip flex items-center gap-2 rounded-2xl px-2.5 py-1.5">
            <span className="grid size-6 place-items-center rounded-lg bg-amber-glow font-display text-base text-night-900">
              {fa(ui.level)}
            </span>
            <span className="font-display text-base leading-none text-cream/90">مرحله</span>
          </div>
          <div className="flex items-center gap-1 ps-1">
            {Array.from({ length: Math.max(ui.lives, 3) }).map((_, i) => (
              <Heart
                key={i}
                className={`size-4 transition-transform sm:size-[18px] ${
                  i < ui.lives ? "scale-100 text-berry drop-shadow-[0_0_6px_rgba(255,93,115,.65)]" : "text-cream/20"
                }`}
                fill="currentColor"
              />
            ))}
          </div>
        </div>

        {/* score + timer */}
        <div className="flex min-w-0 flex-1 flex-col items-center">
          <div className="relative">
            <div className="absolute -inset-x-6 -inset-y-1 rounded-2xl bg-amber-glow/12 blur-md" />
            <div className="relative flex items-baseline gap-2">
              <span className="font-display text-[11px] tracking-wide text-amber-glow/80">امتیاز</span>
              <span className="font-display text-shadow-hard text-4xl leading-none tabular-nums text-cream sm:text-5xl">
                {fmt(ui.score)}
              </span>
            </div>
          </div>
          {ui.combo >= 2 && (
            <div
              key={ui.combo}
              className="anim-pop mt-1 flex items-center gap-1 rounded-full bg-mint/20 px-2.5 py-0.5 text-mint ring-1 ring-mint/45"
            >
              <Sparkles className="size-3.5" />
              <span className="font-display text-sm leading-none">ترکیب {fa(ui.combo)}×</span>
            </div>
          )}
          <div className="mt-1.5 flex w-40 items-center gap-2 sm:w-64">
            <div className="relative h-2.5 flex-1 overflow-hidden rounded-full bg-night-900/70 ring-1 ring-cream/12">
              <div
                className={`h-full rounded-full transition-[width] duration-150 ease-linear ${barColor} ${
                  danger ? "animate-pulse" : ""
                }`}
                style={{ width: `${pct * 100}%` }}
              />
            </div>
            <span
              className={`font-display text-sm leading-none tabular-nums ${danger ? "text-berry" : "text-cream/70"}`}
            >
              {fa(ui.timeLeft)}s
            </span>
          </div>
        </div>

        {/* buttons */}
        <div className="flex items-center gap-1.5">
          <div className="pointer-events-auto">
            <IconButton label="کمک صوتی (A)" onClick={onAssist} active={ui.assist}>
              <AudioLines className="size-5" />
            </IconButton>
          </div>
          <div className="pointer-events-auto">
            <IconButton label="صدا (M)" onClick={onMute} active={!ui.muted}>
              {ui.muted ? <VolumeX className="size-5" /> : <Volume2 className="size-5" />}
            </IconButton>
          </div>
          <div className="pointer-events-auto">
            <IconButton label="توقف (P)" onClick={onPause}>
              <Pause className="size-5" />
            </IconButton>
          </div>
        </div>
      </div>

      {/* slot progress */}
      {playing && (
        <div className="mx-auto mt-1.5 flex w-fit items-center gap-1.5 rounded-full bg-night-900/45 px-3 py-1 ring-1 ring-cream/10">
          <span className="font-display text-xs text-cream/60">قفسه</span>
          {Array.from({ length: ui.total }).map((_, i) => (
            <span
              key={i}
              className={`size-2 rounded-full transition-all duration-200 ${
                i < ui.placed ? "scale-110 bg-mint shadow-[0_0_8px_rgba(100,240,200,.8)]" : "bg-cream/20"
              }`}
            />
          ))}
          <span className="ms-1 font-display text-xs text-mint/90">
            {fa(ui.placed)}/{fa(ui.total)}
          </span>
        </div>
      )}
    </div>
  );
}
