import {
  ArrowLeft,
  Keyboard,
  MousePointer2,
  PartyPopper,
  Play,
  RotateCcw,
  Trophy,
  Volume2,
  VolumeX,
  Hand,
  Waves,
  Layers,
  Settings2,
} from "lucide-react";
import type { UiState } from "../game/engine";
import menuPosterUrl from "../assets/menu-poster.webp";
import { LEVELS_PER_SEASON, SEASONS, TYPE_META, fmt, seasonStartLevel, type ScoreEntry } from "../game/config";
import ScoreBoard from "./ScoreBoard";

const fa = (n: number) => Math.round(n).toLocaleString("fa-IR");

export function Overlay({ children, dim = 0.78 }: { children: React.ReactNode; dim?: number }) {
  return (
    <div
      className="absolute inset-0 z-30 grid place-items-center overflow-y-auto p-3"
      style={{
        background: `radial-gradient(120% 80% at 50% 0%, rgba(9,20,36,${dim * 0.75}) 0%, rgba(6,12,22,${dim}) 70%)`,
        backdropFilter: "blur(3px)",
      }}
    >
      {children}
    </div>
  );
}

function Wave({ period, color, label }: { period: number; color: string; label: string }) {
  const pts: string[] = [];
  for (let x = 0; x <= 160; x += 2) {
    pts.push(`${x === 0 ? "M" : "L"}${x},${12 + Math.sin((x / period) * Math.PI * 2) * 8}`);
  }
  return (
    <div className="flex items-center gap-2">
      <svg viewBox="0 0 160 24" className="h-6 w-full max-w-40" fill="none">
        <path d={pts.join(" ")} stroke={color} strokeWidth="2.6" strokeLinecap="round" />
      </svg>
      <span className="shrink-0 font-display text-sm" style={{ color }}>
        {label}
      </span>
    </div>
  );
}

function Step({ n, title, text }: { n: number; title: string; text: string }) {
  return (
    <li className="flex gap-3">
      <span className="mt-0.5 grid size-7 shrink-0 place-items-center rounded-lg bg-night-700 font-display text-base text-amber-glow">
        {fa(n)}
      </span>
      <span className="text-sm leading-6 text-cream/80">
        <b className="font-display text-base font-normal text-cream">{title}</b> — {text}
      </span>
    </li>
  );
}

/** The first page: the supplied brain poster with only Play and Option. */
export function SplashScreen({ onPlay, onOption }: { onPlay: () => void; onOption: () => void }) {
  return (
    <div className="absolute inset-0 z-30 overflow-hidden bg-night-900">
      <img
        src={menuPosterUrl}
        alt=""
        aria-hidden="true"
        draggable={false}
        className="absolute inset-0 size-full object-cover object-center"
      />
      <div className="pointer-events-none absolute inset-0 bg-gradient-to-b from-night-900/5 via-transparent to-night-900/55" />
      <div className="absolute inset-x-0 bottom-[max(2rem,env(safe-area-inset-bottom))] flex justify-center px-4">
        <div className="flex w-full max-w-md gap-3">
          <button
            onClick={onPlay}
            className="btn-3d flex min-h-16 flex-1 items-center justify-center gap-3 rounded-2xl bg-amber-glow px-6 font-display text-3xl tracking-wider text-night-900 shadow-[0_8px_0_0_#b9832f,0_20px_36px_-12px_rgba(255,196,83,.6)] active:shadow-[0_4px_0_0_#b9832f]"
          >
            <Play className="size-7 fill-current" />
            PLAY
          </button>
          <button
            onClick={onOption}
            className="btn-3d flex min-h-16 flex-1 items-center justify-center gap-3 rounded-2xl border-2 border-cream/60 bg-night-900/75 px-5 font-display text-2xl tracking-wider text-cream shadow-[0_7px_0_0_rgba(4,10,18,.8)] backdrop-blur-sm"
          >
            <Settings2 className="size-6" />
            OPTION
          </button>
        </div>
      </div>
    </div>
  );
}

export function StartScreen({
  scores,
  best,
  assist,
  onAssist,
  music,
  onMusic,
  onStart,
  onBack,
}: {
  scores: ScoreEntry[];
  best: number;
  assist: boolean;
  onAssist: () => void;
  music: boolean;
  onMusic: () => void;
  onStart: (startLevel?: number) => void;
  onBack: () => void;
}) {
  const SEASON_ICON: Record<string, string> = { glass: "🥛", can: "🥫", box: "📦", melon: "🍉", head: "🧠" };
  const legend: Array<{ k: keyof typeof TYPE_META; at: number }> = [
    { k: "glass", at: 1 },
    { k: "can", at: 3 },
    { k: "melon", at: 5 },
    { k: "box", at: 7 },
  ];
  return (
    <Overlay>
      <div className="anim-pop panel grid w-full max-w-4xl gap-5 rounded-3xl p-5 sm:p-7 md:grid-cols-[1.05fr_0.95fr]">
        {/* title + CTA */}
        <div className="flex flex-col">
          <div className="mb-3 flex items-center justify-between gap-2">
            <button
              onClick={onBack}
              className="btn-3d rounded-xl border border-cream/15 bg-night-900/55 px-3 py-1.5 text-sm text-cream/75"
            >
              <ArrowLeft className="me-1 inline size-4" /> بازگشت
            </button>
            <div className="flex items-center gap-2">
              <span className="anim-glow rounded-full bg-amber-glow/15 px-3 py-1 font-display text-xs text-amber-glow ring-1 ring-amber-glow/40">
                گزینه‌ها و فصل‌ها
              </span>
              {best > 0 && (
                <span className="rounded-full bg-mint/12 px-3 py-1 text-xs text-mint ring-1 ring-mint/30">
                  رکورد شما {fmt(best)}
                </span>
              )}
            </div>
          </div>
          <h1 className="font-display text-6xl leading-[0.95] text-cream text-shadow-hard sm:text-7xl">
            گوش<span className="text-amber-glow">‌</span>چین
          </h1>
          <p className="mt-2 max-w-md text-[15px] leading-7 text-cream/70">
            لیوان‌ها پر از آب‌اند، اما هیچ‌کدام دیده نمی‌شوند. فقط با <b className="text-cream">زدن</b> و{" "}
            <b className="text-cream">شنیدن</b> بفهم کدام پُرتر است و آن‌ها را از پُر به خالی در قفسه بچین.
          </p>

          <div className="mt-4 rounded-2xl border border-amber-glow/25 bg-night-900/50 p-3.5">
            <div className="mb-2 flex items-center gap-2 font-display text-lg text-amber-glow">
              <Waves className="size-4" /> قانون طلایی
            </div>
            <Wave period={34} color="#7ad9ff" label="پُر ⟵ بم" />
            <div className="my-1.5 h-px bg-cream/10" />
            <Wave period={9} color="#64f0c8" label="خالی ⟵ زیر" />
            <p className="mt-2 text-xs leading-5 text-cream/55">
              هرچه یک شیء پُرتر باشد، ارتعاش کندتر و صدا بم‌تر است. هندوانهٔ رسیده هم «گود»تر صدا می‌کند.
            </p>
          </div>

          {/* انتخاب فصل — هر چهار فصل از ابتدا باز هستند */}
          <div className="mt-4 rounded-2xl border border-grape/30 bg-night-900/50 p-3.5">
            <div className="mb-2.5 flex items-center gap-2">
              <Layers className="size-4 text-grape" />
              <span className="font-display text-lg text-cream">انتخاب فصل</span>
              <span className="rounded-full bg-grape/18 px-2 py-0.5 text-[10px] text-grape">
                همه باز است · هر فصل {fa(LEVELS_PER_SEASON)} مرحله
              </span>
            </div>
            <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
              {SEASONS.map((s, i) => {
                const meta = TYPE_META[s.type];
                const first = seasonStartLevel(i);
                return (
                  <button
                    key={s.type}
                    onClick={() => onStart(first)}
                    className={`btn-3d group rounded-2xl border border-cream/12 bg-night-800/70 p-2.5 text-right hover:border-amber-glow/60 ${
                      i === 4 ? "col-span-2 border-[#ff9dc0]/45 bg-[#ff9dc0]/10 sm:col-span-4" : ""
                    }`}
                  >
                    <div className="flex items-center gap-2">
                      <span className="grid size-8 shrink-0 place-items-center rounded-xl bg-night-900/70 text-lg">
                        {SEASON_ICON[s.type]}
                      </span>
                      <span className="min-w-0">
                        <span className="block font-display text-sm leading-tight text-cream">
                          فصل {fa(i + 1)}
                        </span>
                        <span className="block truncate text-[10px] text-cream/50">{meta.name}</span>
                      </span>
                    </div>
                    <div className="mt-1.5 text-[10px] leading-4 text-cream/55">{meta.sub}</div>
                    <div
                      className="mt-1.5 h-1 w-full rounded-full"
                      style={{ background: `linear-gradient(90deg, ${meta.accent}, transparent)` }}
                    />
                    <div className="mt-1 font-display text-[11px] text-amber-glow/85">
                      مرحله {fa(first)} تا {fa(first + LEVELS_PER_SEASON - 1)}
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          <div className="mt-4 flex flex-wrap items-center gap-2.5">
            <button
              onClick={() => onStart()}
              className="btn-3d flex items-center gap-2 rounded-2xl bg-amber-glow px-7 py-3.5 font-display text-2xl text-night-900 shadow-[0_8px_0_0_#b9832f,0_20px_36px_-12px_rgba(255,196,83,.6)] active:shadow-[0_4px_0_0_#b9832f]"
            >
              <Play className="size-6 fill-current" />
              شروع بازی
            </button>
            <button
              onClick={onAssist}
              className={`btn-3d rounded-2xl border px-3.5 py-3 text-sm ${
                assist ? "border-mint/60 bg-mint/20 text-mint" : "border-cream/15 bg-night-900/50 text-cream/70"
              }`}
            >
              نمایش خطِ صدا (کمک) {assist ? "روشن" : "خاموش"}
            </button>
            <button
              onClick={onMusic}
              className="btn-3d grid size-11 place-items-center rounded-2xl border border-cream/15 bg-night-900/50 text-cream/70"
              aria-label="موسیقی"
            >
              {music ? <Volume2 className="size-5" /> : <VolumeX className="size-5" />}
            </button>
          </div>
          <p className="mt-2 text-[11px] text-cream/40">
            با کمکِ «خطِ صدا» بازی راحت‌تر است ولی امتیازش ۳۰٪ کمتر.
          </p>
        </div>

        {/* how to + scores */}
        <div className="flex flex-col gap-4">
          <div className="rounded-2xl border border-cream/12 bg-night-900/45 p-4">
            <div className="mb-3 flex items-center gap-2 font-display text-lg text-cream">
              <Keyboard className="size-4 text-mint" /> چطور بازی کنیم
            </div>
            <ol className="space-y-2.5">
              <Step n={1} title="بزن و گوش بده" text="روی هر شیء کلیک کن تا صدای کوبیدنش را بشنوی." />
              <Step
                n={2}
                title="در دست نگه دار"
                text="با یک ضربه، شیء بالا می‌آید و در دستت می‌ماند؛ دوباره بزن تا دوباره گوش بدهی."
              />
              <Step
                n={3}
                title="بکش و بینداز توی قفسه"
                text="آن را بکش و در قفسه رها کن (یا Enter بزن) تا در خانهٔ بعدی بنشیند."
              />
              <Step
                n={4}
                title="از پُر به خالی"
                text="چیدمان باید از پُرترین (سمت راست) به خالی‌ترین (سمت چپ) باشد. اشتباه = یک جان کمتر."
              />
            </ol>
            <div className="mt-3 flex flex-wrap items-center gap-1.5 text-[11px]">
              <span className="flex items-center gap-1 rounded-lg bg-night-700 px-2 py-1 text-cream/70">
                <MousePointer2 className="size-3" /> کلیک
              </span>
              <span className="flex items-center gap-1 rounded-lg bg-night-700 px-2 py-1 text-cream/70">
                <Hand className="size-3" /> کشیدن
              </span>
              <span className="rounded-lg bg-night-700 px-2 py-1 font-mono text-cream/70">Space</span>
              <span className="rounded-lg bg-night-700 px-2 py-1 font-mono text-cream/70">Enter</span>
              <span className="rounded-lg bg-night-700 px-2 py-1 font-mono text-cream/70">1…6</span>
              <span className="rounded-lg bg-night-700 px-2 py-1 font-mono text-cream/70">P</span>
            </div>
          </div>

          <div className="rounded-2xl border border-cream/12 bg-night-900/45 p-4">
            <div className="mb-2.5 font-display text-lg text-cream">جعبه‌ابزار صدا</div>
            <div className="grid grid-cols-2 gap-2">
              {legend.map(({ k, at }) => (
                <div
                  key={k}
                  className={`rounded-xl border px-2.5 py-2 ${
                    k === "glass" ? "border-mint/35 bg-mint/8" : "border-cream/10 bg-night-800/60"
                  }`}
                >
                  <div className="flex items-center justify-between gap-1">
                    <span className="font-display text-sm text-cream">{TYPE_META[k].name}</span>
                    <span className="text-[10px] text-cream/45">{at > 1 ? `مرحله ${fa(at)}` : "از ابتدا"}</span>
                  </div>
                  <div className="mt-0.5 text-[11px] leading-4 text-cream/55">{TYPE_META[k].sub}</div>
                </div>
              ))}
            </div>
          </div>

          <div className="rounded-2xl border border-cream/12 bg-night-900/45 p-4">
            <ScoreBoard scores={scores} />
          </div>
        </div>
      </div>
    </Overlay>
  );
}

export function PauseScreen({
  onResume,
  onRestart,
  onMenu,
  ui,
}: {
  onResume: () => void;
  onRestart: () => void;
  onMenu: () => void;
  ui: UiState;
}) {
  return (
    <Overlay dim={0.72}>
      <div className="anim-pop panel w-full max-w-md rounded-3xl p-6 text-center">
        <div className="font-display text-5xl text-cream">توقف</div>
        <p className="mt-1 text-sm text-cream/60">
          {fa(ui.placed)} از {fa(ui.total)} شیء چیده شده — امتیاز {fmt(ui.score)}
        </p>
        <div className="mt-5 grid gap-2">
          <button
            onClick={onResume}
            className="btn-3d mx-auto flex w-full items-center justify-center gap-2 rounded-2xl bg-amber-glow px-6 py-3 font-display text-xl text-night-900 shadow-[0_6px_0_0_#b9832f]"
          >
            <Play className="size-5 fill-current" /> ادامهٔ بازی
          </button>
          <div className="grid grid-cols-2 gap-2">
            <button
              onClick={onRestart}
              className="btn-3d rounded-2xl border border-cream/15 bg-night-900/60 px-4 py-2.5 text-sm text-cream/80"
            >
              <RotateCcw className="me-1 inline size-4" /> این مرحله
            </button>
            <button
              onClick={onMenu}
              className="btn-3d rounded-2xl border border-cream/15 bg-night-900/60 px-4 py-2.5 text-sm text-cream/80"
            >
              <ArrowLeft className="me-1 inline size-4" /> منوی اصلی
            </button>
          </div>
        </div>
        <p className="mt-4 rounded-xl bg-night-900/60 p-2.5 text-[11px] leading-5 text-cream/50">
          {ui.assist ? "خطِ صدا روشن است — امتیاز ۳۰٪ کمتر." : "راهنما: Space برای گوش دادن، Enter برای چیدن."}
        </p>
      </div>
    </Overlay>
  );
}

export function GameOverScreen({
  ui,
  best,
  isRecord,
  scores,
  name,
  setName,
  onSave,
  saved,
  onRestart,
  onMenu,
}: {
  ui: UiState;
  best: number;
  isRecord: boolean;
  scores: ScoreEntry[];
  name: string;
  setName: (v: string) => void;
  onSave: () => void;
  saved: boolean;
  onRestart: () => void;
  onMenu: () => void;
}) {
  return (
    <Overlay dim={0.8}>
      <div className="anim-pop panel grid w-full max-w-3xl gap-5 rounded-3xl p-6 sm:grid-cols-[1.05fr_0.95fr]">
        <div>
          <div className="font-display text-5xl text-berry text-shadow-hard">بازی تمام شد</div>
          {isRecord ? (
            <div className="shine mt-3 inline-flex items-center gap-2 rounded-full bg-amber-glow px-4 py-1.5 font-display text-lg text-night-900">
              <PartyPopper className="size-5" /> رکورد تازه!
            </div>
          ) : (
            <div className="mt-3 inline-flex items-center gap-2 rounded-full bg-night-900/60 px-4 py-1.5 text-sm text-cream/65">
              <Trophy className="size-4 text-amber-glow" /> بهترین رکورد {fmt(best)}
            </div>
          )}
          <div className="mt-4 rounded-2xl border border-cream/12 bg-night-900/50 p-4">
            <div className="text-[11px] text-cream/50">امتیاز نهایی</div>
            <div className="font-display text-6xl leading-none tabular-nums text-cream">{fmt(ui.score)}</div>
            <div className="mt-3 grid grid-cols-2 gap-2 text-center sm:grid-cols-4">
              {[
                ["مرحله", fa(ui.level)],
                ["بهترین ترکیب", `${fa(ui.bestCombo)}×`],
                ["درست", fa(ui.totalCorrect)],
                ["غلط", fa(ui.totalWrong)],
              ].map(([l, v]) => (
                <div key={l} className="rounded-xl bg-night-800/70 px-2 py-1.5">
                  <div className="font-display text-xl text-amber-glow">{v}</div>
                  <div className="text-[10px] text-cream/50">{l}</div>
                </div>
              ))}
            </div>
          </div>

          <div className="mt-3 flex items-center gap-2">
            <input
              value={name}
              maxLength={14}
              onChange={(e) => setName(e.target.value)}
              placeholder="نامت را بنویس"
              className="min-w-0 flex-1 rounded-xl border border-cream/15 bg-night-900/70 px-3 py-2.5 text-sm text-cream outline-none placeholder:text-cream/35 focus:border-amber-glow/60"
            />
            <button
              onClick={onSave}
              disabled={saved}
              className="btn-3d shrink-0 rounded-xl border border-amber-glow/50 bg-amber-glow/18 px-4 py-2.5 text-sm text-amber-glow disabled:opacity-45"
            >
              {saved ? "ثبت شد" : "ثبت رکورد"}
            </button>
          </div>

          <div className="mt-3 flex gap-2">
            <button
              onClick={onRestart}
              className="btn-3d flex flex-1 items-center justify-center gap-2 rounded-2xl bg-amber-glow px-5 py-3 font-display text-xl text-night-900 shadow-[0_6px_0_0_#b9832f]"
            >
              <RotateCcw className="size-5" /> دوباره بازی (R)
            </button>
            <button
              onClick={onMenu}
              className="btn-3d rounded-2xl border border-cream/15 bg-night-900/60 px-4 py-3 text-sm text-cream/75"
            >
              منو
            </button>
          </div>
        </div>

        <div className="rounded-2xl border border-cream/12 bg-night-900/45 p-4">
          <ScoreBoard scores={scores} />
        </div>
      </div>
    </Overlay>
  );
}

/** Shown after a wrong full arrangement: objects stay revealed until retry is pressed. */
export function RoundFailedCard({ ui, onRetry }: { ui: UiState; onRetry: () => void }) {
  const f = ui.failedInfo;
  return (
    <div className="pointer-events-none absolute inset-x-0 top-28 z-[25] flex justify-center px-3 sm:top-32">
      <div className="anim-pop panel pointer-events-auto w-full max-w-md rounded-3xl p-5 text-center">
        <div className="font-display text-4xl text-berry">درست نیست!</div>
        <p className="mt-1 text-sm text-cream/65">
          این دست رو باختی — نگاه کن داخلِ هر کدام چقدر بود؛ آن‌هایی که قرمز شدند جایشان اشتباه بود.
        </p>
        <div className="mt-3 flex items-stretch justify-center gap-2">
          {[
            ["درست چیده‌شده", `${fa(f?.correct ?? 0)} از ${fa(f?.total ?? ui.total)}`],
            ["جان باقی‌مانده", fa(ui.lives)],
            ["امتیاز کل", fmt(ui.score)],
          ].map(([l, v]) => (
            <div key={l} className="flex-1 rounded-xl bg-night-900/60 px-2 py-2">
              <div className="font-display text-lg text-amber-glow">{v}</div>
              <div className="text-[10px] text-cream/50">{l}</div>
            </div>
          ))}
        </div>
        <button
          onClick={onRetry}
          className="btn-3d mt-4 w-full rounded-2xl bg-amber-glow px-5 py-2.5 font-display text-lg text-night-900 shadow-[0_5px_0_0_#b9832f]"
        >
          تلاش دوباره ←
        </button>
      </div>
    </div>
  );
}

export function LevelClearCard({ ui, onContinue }: { ui: UiState; onContinue: () => void }) {
  const s = ui.roundSummary;
  return (
    <div className="pointer-events-none absolute inset-x-0 top-28 z-[25] flex justify-center px-3 sm:top-32">
      <div className="anim-pop panel pointer-events-auto w-full max-w-md rounded-3xl p-5 text-center">
        <div className="font-display text-4xl text-mint">{s?.perfect ? "چیدمان کامل!" : "مرحله تمام شد!"}</div>
        <p className="mt-1 text-sm text-cream/65">
          حالا نگاه کن داخلِ هر شی چه خبر بود — {fa(ui.total)} تا، درست از پُر به خالی.
        </p>
        <div className="mt-3 flex items-stretch justify-center gap-2">
          {[
            ["پاداش چیدمان", fmt(s?.bonus ?? 0)],
            ["پاداش زمان", fmt(s?.timeBonus ?? 0)],
            ["امتیاز کل", fmt(ui.score)],
          ].map(([l, v]) => (
            <div key={l} className="flex-1 rounded-xl bg-night-900/60 px-2 py-2">
              <div className="font-display text-lg text-amber-glow">{v}</div>
              <div className="text-[10px] text-cream/50">{l}</div>
            </div>
          ))}
        </div>
        <button
          onClick={onContinue}
          className="btn-3d mt-4 w-full rounded-2xl bg-mint px-5 py-2.5 font-display text-lg text-night-900 shadow-[0_5px_0_0_#2fae8d]"
        >
          مرحلهٔ بعد ←
        </button>
      </div>
    </div>
  );
}

/** Shown right after a loss: keeps the revealed objects visible until the player asks for the result. */
export function GameOverRevealCard({ onContinue }: { onContinue: () => void }) {
  return (
    <div className="pointer-events-none absolute inset-x-0 top-28 z-[25] flex justify-center px-3 sm:top-32">
      <div className="anim-pop panel pointer-events-auto flex w-full max-w-lg items-center gap-3 rounded-2xl px-4 py-3">
        <div className="min-w-0 flex-1 text-right">
          <div className="font-display text-2xl leading-tight text-berry">بازی تمام شد</div>
          <div className="text-[12px] leading-5 text-cream/65">
            نگاه کن داخلِ هر کدام چقدر بود؛ ترتیب درست از پُر (راست) به خالی (چپ) است.
          </div>
        </div>
        <button
          onClick={onContinue}
          className="btn-3d shrink-0 rounded-2xl bg-amber-glow px-4 py-2.5 font-display text-lg text-night-900 shadow-[0_5px_0_0_#b9832f]"
        >
          دیدن نتیجه ←
        </button>
      </div>
    </div>
  );
}

export function Banner({ ui }: { ui: UiState }) {
  if (!ui.banner) return null;
  const tone =
    ui.banner.tone === "good"
      ? "border-mint/45 bg-mint/15 text-mint"
      : ui.banner.tone === "bad"
        ? "border-berry/45 bg-berry/15 text-berry"
        : "border-amber-glow/45 bg-amber-glow/12 text-amber-glow";
  return (
    <div className="pointer-events-none absolute inset-x-0 top-28 z-20 grid place-items-center sm:top-32">
      <div key={ui.banner.title + ui.banner.sub} className={`anim-slide rounded-2xl border px-5 py-2 text-center ${tone} bg-night-900/70`}>
        <div className="font-display text-2xl leading-tight">{ui.banner.title}</div>
        {ui.banner.sub && <div className="text-[12px] leading-5 text-cream/70">{ui.banner.sub}</div>}
      </div>
    </div>
  );
}

export function BottomHints({ ui }: { ui: UiState }) {
  const touch = typeof window !== "undefined" && window.matchMedia?.("(pointer: coarse)").matches;
  return (
    <div className="pointer-events-none absolute inset-x-0 bottom-0 z-20 flex justify-center p-2">
      <div className="chip flex max-w-full items-center gap-2 overflow-hidden rounded-2xl px-3 py-1.5 text-[11px] text-cream/70">
        <span className="font-display text-sm text-cream/85">
          {ui.phase === "playing" && ui.placed === 0 ? "اول پُرترین را پیدا کن" : "پُرترین ⟵ راست · خالی‌ترین ⟵ چپ"}
        </span>
        <span className="hidden h-4 w-px bg-cream/20 sm:block" />
        <span className="hidden sm:inline">
          {touch
            ? "بزن تا صدا کند · بکش توی قفسه تا بچیند"
            : "کلیک: گوش دادن · Space: صدا · Enter: بچین · 1-6: انتخاب · P: توقف"}
        </span>
      </div>
    </div>
  );
}
