import { useCallback, useEffect, useMemo, useRef, useState, useSyncExternalStore } from "react";
import { GameCanvas } from "./components/GameCanvas";
import { Hud, PauseButton } from "./components/Hud";
import { MemoryPanel } from "./components/MemoryPanel";
import { GameOverModal, PauseModal, SettingsModal, StartScreen } from "./components/Overlays";
import { PressButton } from "./components/PressButton";
import { AudioEngine } from "./game/audio";
import { Engine } from "./game/engine";
import { computeLayout } from "./game/layout";
import { loadSettings, saveSettings, type Settings } from "./game/storage";
import { useViewport } from "./hooks/useViewport";

// Singletons: the engine and audio live outside React so the game loop never depends on renders.
const initialSettings = loadSettings();
const engine = new Engine();
const audio = new AudioEngine(initialSettings);
engine.onSound = (n) => audio.play(n);

if (import.meta.env.DEV) {
  (window as unknown as { __dough: Engine }).__dough = engine;
}

export default function App() {
  const snap = useSyncExternalStore(engine.subscribe, engine.getSnapshot);
  const vp = useViewport();
  const layout = useMemo(() => computeLayout(vp.w, vp.h), [vp.w, vp.h]);
  if (import.meta.env.DEV) (window as unknown as { __layout: typeof layout }).__layout = layout;
  const [settings, setSettings] = useState<Settings>(initialSettings);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [keyDown, setKeyDown] = useState(false);
  const settingsOpenRef = useRef(false);
  settingsOpenRef.current = settingsOpen;

  const inGame = snap.phase !== "MENU" && snap.phase !== "GAME_OVER";

  // ---- actions ---------------------------------------------------------------------------
  const start = useCallback(() => {
    audio.unlock();
    audio.play("click");
    engine.startRun();
  }, []);

  const doCut = useCallback(() => {
    audio.unlock();
    engine.cut();
    try {
      navigator.vibrate?.(10);
    } catch {
      /* ignore */
    }
  }, []);

  const pause = useCallback(() => {
    audio.play("click");
    engine.pause();
  }, []);

  const resume = useCallback(() => {
    audio.play("click");
    engine.resume();
  }, []);

  const restart = useCallback(() => {
    audio.unlock();
    audio.play("click");
    setSettingsOpen(false);
    engine.restart();
  }, []);

  const toMenu = useCallback(() => {
    audio.play("click");
    setSettingsOpen(false);
    engine.toMenu();
  }, []);

  const openSettings = useCallback(() => {
    audio.unlock();
    audio.play("click");
    engine.pause(); // no-op unless a run is active
    setSettingsOpen(true);
  }, []);

  const closeSettings = useCallback(() => {
    audio.play("click");
    setSettingsOpen(false);
  }, []);

  const changeSettings = useCallback((p: Partial<Settings>) => {
    setSettings((prev) => {
      const next = { ...prev, ...p };
      saveSettings(next);
      audio.setSettings(next);
      return next;
    });
  }, []);

  // ---- keyboard --------------------------------------------------------------------------
  useEffect(() => {
    const onKeyDown = (ev: KeyboardEvent) => {
      audio.unlock();
      const t = ev.target as HTMLElement | null;
      const inControl =
        !!t?.closest?.('button, input, select, textarea, [role="switch"]') && !t.closest("[data-press]");
      const phase = engine.phase;
      switch (ev.code) {
        case "Space":
        case "Enter":
        case "NumpadEnter": {
          if (inControl) return;
          ev.preventDefault();
          if (ev.repeat || settingsOpenRef.current) return;
          if (phase === "PLAYING") {
            setKeyDown(true);
            doCut();
          } else if (phase === "MENU") start();
          else if (phase === "PAUSED") resume();
          else if (phase === "GAME_OVER") restart();
          break;
        }
        case "Escape": {
          ev.preventDefault();
          if (settingsOpenRef.current) closeSettings();
          else if (phase === "PAUSED") resume();
          else pause();
          break;
        }
        case "KeyR": {
          if (settingsOpenRef.current || ev.repeat || ev.ctrlKey || ev.metaKey) return;
          if (phase === "PAUSED" || phase === "GAME_OVER") restart();
          break;
        }
      }
    };
    const onKeyUp = (ev: KeyboardEvent) => {
      if (ev.code === "Space" || ev.code === "Enter" || ev.code === "NumpadEnter") setKeyDown(false);
    };
    window.addEventListener("keydown", onKeyDown);
    window.addEventListener("keyup", onKeyUp);
    return () => {
      window.removeEventListener("keydown", onKeyDown);
      window.removeEventListener("keyup", onKeyUp);
    };
  }, [doCut, start, resume, restart, pause, closeSettings]);

  // ---- browser housekeeping ----------------------------------------------------------------
  useEffect(() => {
    const onVis = () => {
      if (document.hidden) {
        engine.pause();
        audio.setActive(false);
      } else {
        audio.setActive(true);
      }
    };
    const onBlur = () => engine.pause();
    const stop = (e: Event) => e.preventDefault();
    const onWheel = (e: WheelEvent) => {
      if (e.ctrlKey) e.preventDefault();
    };
    document.addEventListener("visibilitychange", onVis);
    window.addEventListener("blur", onBlur);
    document.addEventListener("gesturestart", stop);
    document.addEventListener("gesturechange", stop);
    document.addEventListener("contextmenu", stop);
    window.addEventListener("wheel", onWheel, { passive: false });
    return () => {
      document.removeEventListener("visibilitychange", onVis);
      window.removeEventListener("blur", onBlur);
      document.removeEventListener("gesturestart", stop);
      document.removeEventListener("gesturechange", stop);
      document.removeEventListener("contextmenu", stop);
      window.removeEventListener("wheel", onWheel);
    };
  }, []);

  return (
    <div
      className="fixed inset-0 overflow-hidden bg-[#070d1c] text-white"
      onPointerDownCapture={() => audio.unlock()}
      dir="rtl"
    >
      <GameCanvas engine={engine} audio={audio} layout={layout} />

      {snap.phase === "MENU" ? (
        <StartScreen best={snap.best} layout={layout} onStart={start} onSettings={openSettings} />
      ) : (
        <>
          <Hud snap={snap} layout={layout} onSettings={openSettings} />
          <MemoryPanel snap={snap} engine={engine} layout={layout} />
          <PauseButton onPause={pause} />
          <PressButton active={snap.phase === "PLAYING"} down={keyDown} scale={layout.ctrl} onPress={doCut} />
        </>
      )}

      {snap.phase === "PAUSED" && !settingsOpen && (
        <PauseModal snap={snap} onResume={resume} onRestart={restart} onSettings={openSettings} onMenu={toMenu} />
      )}
      {snap.phase === "GAME_OVER" && !settingsOpen && <GameOverModal snap={snap} onRestart={restart} onMenu={toMenu} />}
      {settingsOpen && (
        <SettingsModal
          settings={settings}
          inGame={inGame}
          onChange={changeSettings}
          onClose={closeSettings}
          onRestart={restart}
        />
      )}
    </div>
  );
}
