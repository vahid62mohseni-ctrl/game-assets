import { useEffect, useRef } from "react";
import type { AudioEngine } from "../game/audio";
import type { Engine } from "../game/engine";
import type { Layout } from "../game/layout";
import { Renderer } from "../game/renderer";

const dpr = () => Math.min(window.devicePixelRatio || 1, 2);

/** Owns the requestAnimationFrame loop: simulation step -> render -> machine audio level. */
export function GameCanvas({ engine, audio, layout }: { engine: Engine; audio: AudioEngine; layout: Layout }) {
  const ref = useRef<HTMLCanvasElement>(null);
  const rendererRef = useRef<Renderer | null>(null);
  const layoutRef = useRef(layout);
  layoutRef.current = layout;

  useEffect(() => {
    const canvas = ref.current;
    if (!canvas) return;
    let renderer: Renderer;
    try {
      renderer = new Renderer(canvas);
    } catch (err) {
      console.error(err);
      return;
    }
    rendererRef.current = renderer;
    renderer.resize(layoutRef.current, dpr(), engine);

    let raf = 0;
    let last = performance.now();
    const loop = (now: number) => {
      const dt = (now - last) / 1000;
      last = now;
      try {
        engine.update(dt);
        renderer.draw(engine);
        audio.setMachine(engine.phase === "PAUSED" ? 0 : engine.machine);
      } catch (err) {
        console.error(err);
      }
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);

    // Re-render the cached factory once the Persian font is ready (wall sign, labels).
    let alive = true;
    document.fonts?.ready.then(() => alive && renderer.rebuild()).catch(() => undefined);

    return () => {
      alive = false;
      cancelAnimationFrame(raf);
      renderer.dispose();
      rendererRef.current = null;
    };
  }, [engine, audio]);

  useEffect(() => {
    rendererRef.current?.resize(layout, dpr(), engine);
  }, [layout, engine]);

  return <canvas ref={ref} className="absolute inset-0 z-0" aria-label="خط تولید خمیر" />;
}
