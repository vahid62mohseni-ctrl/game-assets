import { useMemo } from "react";
import type { Snapshot } from "../game/engine";
import type { Layout } from "../game/layout";
import type { Settings } from "../game/storage";
import { cn } from "../utils/cn";
import { fa } from "../utils/fa";
import {
  GearIcon,
  HeartIcon,
  HomeIcon,
  MusicIcon,
  Modal,
  PlayIcon,
  RestartIcon,
  SpeakerIcon,
  Switch,
  TrophyIcon,
} from "./ui";

// ---------------------------------------------------------------------------------------------
// Start screen
// ---------------------------------------------------------------------------------------------
export function StartScreen({
  best,
  layout,
  onStart,
  onSettings,
}: {
  best: number;
  layout: Layout;
  onStart: () => void;
  onSettings: () => void;
}) {
  const { wide, H } = layout;
  const compact = !wide && H < 740;
  /** Phone held sideways: keep everything below the conveyor. */
  const short = wide && H < 560;

  const card = (
    <div className={cn("panel w-full rounded-3xl text-center", short ? "max-w-[460px] px-3 py-1.5" : "max-w-[420px] px-4 py-3")}>
      {!short && <div className="text-base font-extrabold text-amber-200">هدف بازی</div>}
      <p className={cn("mt-1 font-semibold text-sky-50/95", short ? "text-[11px] leading-[1.6]" : "text-[13.5px] leading-[1.9] sm:text-sm")}>
        الگوی قطعه‌های{" "}
        <span className="capsule-short mx-0.5 inline-block rounded-full px-2.5 py-0.5 align-middle text-xs font-extrabold">کوتاه</span>{" "}
        و{" "}
        <span className="capsule-long mx-0.5 inline-block rounded-full px-2.5 py-0.5 align-middle text-xs font-extrabold">بلند</span>{" "}
        را به خاطر بسپار، سپس با دکمه‌ی پرس، خمیر را دقیقاً به همان ترتیب و اندازه برش بزن. هرچه بیشتر دوام بیاوری، رکوردت بالاتر می‌رود!
      </p>
      {!compact && !short && (
        <p className="mt-1 flex items-center justify-center gap-1.5 text-[12px] font-bold text-red-200">
          <HeartIcon className="h-4 w-4" />
          سه جان داری؛ هر اشتباه یک جان می‌گیرد.
        </p>
      )}
      {!compact && !wide && (
        <div className="mt-2 grid grid-cols-3 gap-1.5 text-[12px] font-bold text-white">
          {["به خاطر بسپار", "زمان‌بندی کن", "برش بزن"].map((t, i) => (
            <div key={t} className="flex items-center justify-center gap-1.5 rounded-xl bg-[#071026]/80 py-1.5 ring-1 ring-sky-300/25">
              <span className="flex h-5 w-5 items-center justify-center rounded-full bg-amber-400 text-[11px] font-black text-amber-950">
                {fa(i + 1, false)}
              </span>
              {t}
            </div>
          ))}
        </div>
      )}
    </div>
  );

  const startBtn = (
    <button
      type="button"
      onClick={onStart}
      className={cn(
        "btn-primary flex items-center justify-center gap-3 rounded-2xl font-black",
        short ? "min-w-[180px] px-6 py-2 text-xl" : "min-w-[240px] px-10 py-3.5 text-[26px]",
      )}
    >
      <PlayIcon className="h-7 w-7" />
      شروع بازی
    </button>
  );

  return (
    <div
      className="anim-fade absolute inset-0 z-20 flex flex-col px-3"
      style={{
        paddingTop: "max(10px, env(safe-area-inset-top))",
        paddingBottom: "max(14px, env(safe-area-inset-bottom))",
      }}
      dir="rtl"
    >
      <div className="flex items-start justify-between" dir="ltr">
        <div className="panel flex items-center gap-2 rounded-2xl px-2.5 py-1.5">
          <TrophyIcon className="h-9 w-9 shrink-0" />
          <div dir="rtl" className="min-w-[72px] text-center leading-tight">
            <div className="text-xs font-bold text-sky-100/90">بهترین رکورد</div>
            <div className="text-xl font-extrabold tabular-nums text-white">{fa(best)}</div>
          </div>
        </div>
        <button
          type="button"
          onClick={onSettings}
          aria-label="تنظیمات"
          className="icon-btn flex h-12 w-12 items-center justify-center rounded-2xl"
        >
          <GearIcon className="h-8 w-8" />
        </button>
      </div>

      <div className="mt-1 text-center">
        <h1 className={cn("title-dough font-black leading-[1.15]", short ? "text-[44px]" : "text-[68px] sm:text-[92px]")}>خمیرکات</h1>
        {!short && (
          <div className="-mt-1 text-xs font-extrabold tracking-[0.55em] text-amber-100/85" dir="ltr">
            DOUGH CUT
          </div>
        )}
      </div>

      <div className="flex-1" />

      {wide ? (
        <div className="flex items-end justify-center gap-5 pb-1">
          {card}
          <div className="flex flex-col items-center gap-2">
            {startBtn}
            <div className="text-xs font-semibold text-sky-100/70" dir="ltr">
              Space / Enter · Esc
            </div>
          </div>
        </div>
      ) : (
        <div className="flex flex-col items-center gap-3">
          {card}
          {startBtn}
        </div>
      )}
    </div>
  );
}

// ---------------------------------------------------------------------------------------------
// Pause
// ---------------------------------------------------------------------------------------------
export function PauseModal({
  snap,
  onResume,
  onRestart,
  onSettings,
  onMenu,
}: {
  snap: Snapshot;
  onResume: () => void;
  onRestart: () => void;
  onSettings: () => void;
  onMenu: () => void;
}) {
  return (
    <Modal>
      <h2 className="text-center text-3xl font-black text-white">توقف</h2>
      <div className="mt-3 grid grid-cols-2 gap-2 text-center">
        <Stat label="امتیاز" value={fa(snap.score)} />
        <Stat label="مرحله" value={fa(snap.stage)} />
      </div>
      <ul className="mt-3 space-y-0.5 rounded-2xl bg-[#071026]/70 px-3 py-2 text-[12px] font-semibold leading-relaxed text-sky-100/85 ring-1 ring-sky-300/15">
        <li>قطعه‌ی درست: {fa(100)} (کوتاه) · {fa(150)} (بلند)</li>
        <li>برش دقیق: {fa(50)}+ امتیاز اضافه</li>
        <li>کامل کردن الگو: پاداش مرحله</li>
        <li>الگوهای پشت‌سرهم بدون اشتباه: ضریب امتیاز بیشتر</li>
      </ul>
      <div className="mt-4 flex flex-col gap-3">
        <button type="button" onClick={onResume} className="btn-primary flex items-center justify-center gap-2 rounded-2xl py-3 text-xl font-black">
          <PlayIcon className="h-6 w-6" />
          ادامه
        </button>
        <button type="button" onClick={onRestart} className="btn-secondary flex items-center justify-center gap-2 rounded-2xl py-2.5 text-lg font-extrabold">
          <RestartIcon className="h-5 w-5" />
          شروع مجدد
        </button>
        <div className="grid grid-cols-2 gap-3">
          <button type="button" onClick={onSettings} className="btn-secondary flex items-center justify-center gap-2 rounded-2xl py-2.5 text-base font-extrabold">
            <GearIcon className="h-5 w-5" />
            تنظیمات
          </button>
          <button type="button" onClick={onMenu} className="btn-secondary flex items-center justify-center gap-2 rounded-2xl py-2.5 text-base font-extrabold">
            <HomeIcon className="h-5 w-5" />
            منوی اصلی
          </button>
        </div>
      </div>
    </Modal>
  );
}

function Stat({ label, value, gold }: { label: string; value: string; gold?: boolean }) {
  return (
    <div className="rounded-2xl bg-[#071026]/80 px-2 py-2 ring-1 ring-sky-300/20">
      <div className="text-[12px] font-bold text-sky-100/80">{label}</div>
      <div className={cn("text-xl font-black tabular-nums", gold ? "text-amber-300" : "text-white")}>{value}</div>
    </div>
  );
}

// ---------------------------------------------------------------------------------------------
// Game over
// ---------------------------------------------------------------------------------------------
const CONFETTI = ["#fbbf24", "#60a5fa", "#f87171", "#4ade80", "#fde68a", "#c4b5fd"];

export function GameOverModal({
  snap,
  onRestart,
  onMenu,
}: {
  snap: Snapshot;
  onRestart: () => void;
  onMenu: () => void;
}) {
  const record = snap.newRecord;
  const pieces = useMemo(
    () =>
      Array.from({ length: 18 }, (_, i) => ({
        left: `${(i * 37 + 7) % 100}%`,
        color: CONFETTI[i % CONFETTI.length],
        delay: `${((i * 0.37) % 2.4).toFixed(2)}s`,
        dx: `${((i % 5) - 2) * 14}px`,
      })),
    [],
  );
  return (
    <Modal tone={record ? "gold" : "red"} z={45}>
      {record && (
        <div className="pointer-events-none absolute inset-x-0 top-0 h-[280px] overflow-hidden rounded-t-3xl" aria-hidden>
          {pieces.map((p, i) => (
            <span
              key={i}
              className="confetti"
              style={{ left: p.left, background: p.color, animationDelay: p.delay, ["--dx" as string]: p.dx }}
            />
          ))}
        </div>
      )}
      <div className="relative">
        <h2 className={cn("text-center text-3xl font-black", record ? "text-amber-300" : "text-white")}>
          {record ? "رکورد جدید!" : "پایان بازی"}
        </h2>
        {record && (
          <div className="anim-shimmer mx-auto mt-2 w-fit rounded-full bg-gradient-to-r from-amber-300 via-yellow-100 to-amber-300 px-4 py-1 text-sm font-extrabold text-amber-950">
            🏆 رکورد قبلی‌ات شکسته شد!
          </div>
        )}
        {snap.failReason && (
          <p className="mt-2 text-center text-sm font-bold text-red-200">{snap.failReason}</p>
        )}
        <div className="mt-3 rounded-2xl bg-[#071026]/85 p-3 text-center ring-1 ring-sky-300/25">
          <div className="text-sm font-bold text-sky-100/85">امتیاز نهایی</div>
          <div className="text-5xl font-black tabular-nums text-amber-300 drop-shadow">{fa(snap.score)}</div>
        </div>
        <div className="mt-2 grid grid-cols-3 gap-2 text-center">
          <Stat label="بهترین رکورد" value={fa(snap.best)} gold />
          <Stat label="مرحله" value={fa(snap.stage)} />
          <Stat label="الگوی کامل" value={fa(snap.completed)} />
        </div>
        <div className="mt-4 flex flex-col gap-3">
          <button type="button" onClick={onRestart} className="btn-primary flex items-center justify-center gap-2 rounded-2xl py-3 text-xl font-black">
            <RestartIcon className="h-6 w-6" />
            دوباره بازی کن
          </button>
          <button type="button" onClick={onMenu} className="btn-secondary flex items-center justify-center gap-2 rounded-2xl py-2.5 text-lg font-extrabold">
            <HomeIcon className="h-5 w-5" />
            منوی اصلی
          </button>
        </div>
      </div>
    </Modal>
  );
}

// ---------------------------------------------------------------------------------------------
// Settings
// ---------------------------------------------------------------------------------------------
function VolumeRow({
  icon,
  title,
  enabled,
  volume,
  onToggle,
  onVolume,
}: {
  icon: React.ReactNode;
  title: string;
  enabled: boolean;
  volume: number;
  onToggle: (v: boolean) => void;
  onVolume: (v: number) => void;
}) {
  const pct = Math.round(volume * 100);
  return (
    <div className="rounded-2xl bg-[#071026]/80 p-3 ring-1 ring-sky-300/20">
      <div className="flex items-center justify-between gap-3">
        <div className="flex items-center gap-2 text-base font-extrabold text-white">
          <span className="text-amber-300">{icon}</span>
          {title}
        </div>
        <Switch checked={enabled} onChange={onToggle} label={title} />
      </div>
      <div className={cn("mt-3 flex items-center gap-3 transition-opacity", !enabled && "opacity-45")}>
        <input
          type="range"
          min={0}
          max={100}
          step={1}
          value={pct}
          aria-label={`${title} – میزان صدا`}
          onChange={(e) => onVolume(Number(e.target.value) / 100)}
          className="w-full"
          style={{ ["--p" as string]: `${pct}%` }}
        />
        <span className="w-10 text-center text-sm font-extrabold tabular-nums text-sky-100">{fa(pct, false)}٪</span>
      </div>
    </div>
  );
}

export function SettingsModal({
  settings,
  inGame,
  onChange,
  onClose,
  onRestart,
}: {
  settings: Settings;
  inGame: boolean;
  onChange: (p: Partial<Settings>) => void;
  onClose: () => void;
  onRestart: () => void;
}) {
  return (
    <Modal z={60}>
      <div className="flex items-center justify-center gap-2">
        <GearIcon className="h-8 w-8" />
        <h2 className="text-center text-2xl font-black text-white">تنظیمات</h2>
      </div>
      <div className="mt-3 flex flex-col gap-3">
        <VolumeRow
          icon={<MusicIcon className="h-6 w-6" />}
          title="موسیقی"
          enabled={settings.music}
          volume={settings.musicVol}
          onToggle={(v) => onChange({ music: v })}
          onVolume={(v) => onChange({ musicVol: v })}
        />
        <VolumeRow
          icon={<SpeakerIcon className="h-6 w-6" />}
          title="افکت‌های صوتی"
          enabled={settings.sfx}
          volume={settings.sfxVol}
          onToggle={(v) => onChange({ sfx: v })}
          onVolume={(v) => onChange({ sfxVol: v })}
        />
        <p className="text-center text-[12px] font-semibold leading-relaxed text-sky-100/70">
          صفحه‌کلید: <b dir="ltr">Space / Enter</b> برش · <b dir="ltr">Esc</b> توقف · <b dir="ltr">R</b> شروع مجدد
        </p>
        <div className={cn("grid gap-3", inGame ? "grid-cols-2" : "grid-cols-1")}>
          {inGame && (
            <button type="button" onClick={onRestart} className="btn-secondary flex items-center justify-center gap-2 rounded-2xl py-2.5 text-base font-extrabold">
              <RestartIcon className="h-5 w-5" />
              شروع مجدد
            </button>
          )}
          <button type="button" onClick={onClose} className="btn-primary rounded-2xl py-2.5 text-lg font-black">
            بستن
          </button>
        </div>
      </div>
    </Modal>
  );
}
