import pauseUrl from "../assets/pause-button.png";
import { MAX_LIVES } from "../game/config";
import type { Snapshot } from "../game/engine";
import type { Layout } from "../game/layout";
import { fa } from "../utils/fa";
import { GearIcon, HeartIcon, TrophyIcon } from "./ui";

interface HudProps {
  snap: Snapshot;
  layout: Layout;
  onSettings: () => void;
}

export function Hud({ snap, layout, onSettings }: HudProps) {
  const { wide } = layout;

  const best = (
    <div className="panel flex items-center gap-2 rounded-2xl px-2.5 py-1.5" dir="ltr" aria-label="بهترین رکورد">
      <TrophyIcon className="h-8 w-8 shrink-0 drop-shadow-[0_2px_3px_rgba(0,0,0,0.5)] sm:h-9 sm:w-9" />
      <div dir="rtl" className="min-w-[68px] text-center leading-tight">
        <div className="text-[11px] font-bold text-sky-100/90 sm:text-xs">بهترین رکورد</div>
        <div className="text-xl font-extrabold tabular-nums text-white">{fa(snap.best)}</div>
      </div>
    </div>
  );

  const score = (
    <div className="panel rounded-2xl px-3 py-1.5 text-center" dir="rtl" aria-label="امتیاز">
      <div className="flex items-baseline justify-center gap-1.5 leading-tight">
        <span className="text-[11px] font-bold text-sky-100/90 sm:text-xs">امتیاز</span>
        {snap.combo > 0 && (
          <span className="rounded-full bg-amber-400 px-1.5 text-[11px] font-extrabold text-amber-950">
            ×{fa((Math.round(snap.multiplier * 100) / 100).toString().replace(".", "٫"), false)}
          </span>
        )}
      </div>
      <div className="text-xl font-extrabold tabular-nums leading-tight text-amber-300">{fa(snap.score)}</div>
      <div className="mt-0.5 flex items-center justify-center gap-0.5" aria-label="جان‌ها">
        {Array.from({ length: MAX_LIVES }, (_, i) => (
          <HeartIcon key={i} filled={i < snap.lives} className="h-4 w-4" />
        ))}
      </div>
    </div>
  );

  const stage = (
    <div className="panel pointer-events-auto flex items-center gap-2 rounded-2xl px-2.5 py-1.5" dir="ltr">
      <div dir="rtl" className="min-w-[44px] text-center leading-tight" aria-label="مرحله">
        <div className="text-[11px] font-bold text-sky-100/90 sm:text-xs">مرحله</div>
        <div className="text-2xl font-extrabold tabular-nums text-white">{fa(snap.stage)}</div>
      </div>
      <button
        type="button"
        onClick={onSettings}
        aria-label="تنظیمات"
        className="icon-btn flex h-10 w-10 shrink-0 items-center justify-center rounded-xl"
      >
        <GearIcon className="h-7 w-7" />
      </button>
    </div>
  );

  return (
    <div
      className="pointer-events-none absolute inset-x-0 top-0 z-10 flex items-start justify-between gap-2 px-2"
      style={{ paddingTop: "max(8px, env(safe-area-inset-top))" }}
      dir="ltr"
    >
      {wide ? (
        <div className="flex flex-col gap-2">
          {best}
          {score}
        </div>
      ) : (
        <>
          {best}
          {score}
        </>
      )}
      {stage}
    </div>
  );
}

export function PauseButton({ onPause }: { onPause: () => void }) {
  return (
    <button
      type="button"
      onClick={onPause}
      aria-label="توقف"
      className="group absolute left-3 z-10 h-16 w-16 cursor-pointer select-none border-0 bg-transparent p-0 transition-transform duration-75 hover:scale-105 active:scale-95 active:translate-y-0.5"
      style={{ bottom: "max(14px, env(safe-area-inset-bottom))" }}
    >
      <img
        src={pauseUrl}
        alt=""
        draggable={false}
        className="pointer-events-none h-full w-full object-contain drop-shadow-[0_5px_8px_rgba(0,0,0,0.55)] transition-[filter] group-hover:brightness-110"
      />
    </button>
  );
}
