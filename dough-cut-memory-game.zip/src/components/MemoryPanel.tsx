import { useEffect, useRef } from "react";
import capsuleLongUrl from "../assets/capsule-long.webp";
import capsuleShortUrl from "../assets/capsule-short.webp";
import frameUrl from "../assets/remember-frame.webp";
import type { Engine, Snapshot } from "../game/engine";
import type { Layout } from "../game/layout";
import { cn } from "../utils/cn";
import { fa } from "../utils/fa";
import { Capsule, HeartIcon } from "./ui";

interface Props {
  snap: Snapshot;
  engine: Engine;
  layout: Layout;
}

const GAP = 8;

/** Aspect of the supplied capsule artwork (کوتاه and بلند are drawn at the same size). */
const CAPSULE_ASPECT = 2.34;
/** 9-slice inset of the frame artwork, in source px (see scripts/prepare-remember-art.mjs). */
const FRAME_SLICE = 83;

/**
 * Capsule size for a row of `n` pills. The artwork has its label baked in, so pills are never
 * squeezed below a readable size — long rows wrap onto a second line instead.
 */
function capsuleSizes(n: number, avail: number) {
  const fit = (avail - GAP * (n - 1)) / Math.max(1, n) / CAPSULE_ASPECT;
  const h = Math.max(23, Math.min(40, fit));
  return { w: h * CAPSULE_ASPECT, h };
}

/** Countdown bar driven directly by the engine (no React re-renders per frame). */
function MemBar({ engine }: { engine: Engine }) {
  const bar = useRef<HTMLDivElement>(null);
  const txt = useRef<HTMLSpanElement>(null);
  useEffect(() => {
    let raf = 0;
    const loop = () => {
      const f = engine.memTotal > 0 ? Math.max(0, Math.min(1, engine.memLeft / engine.memTotal)) : 0;
      if (bar.current) {
        bar.current.style.transform = `scaleX(${f})`;
        bar.current.style.background =
          f < 0.25 ? "linear-gradient(90deg,#f87171,#fb923c)" : f < 0.5 ? "linear-gradient(90deg,#fbbf24,#fde047)" : "linear-gradient(90deg,#34d399,#4ade80)";
      }
      if (txt.current) txt.current.textContent = fa(Math.ceil(engine.memLeft), false);
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(raf);
  }, [engine]);
  return (
    <div className="mt-2.5 flex items-center gap-2" dir="rtl">
      <div className="h-2.5 flex-1 overflow-hidden rounded-full bg-[#0a1430] ring-1 ring-sky-300/30">
        <div ref={bar} className="h-full origin-right rounded-full" style={{ transform: "scaleX(1)" }} />
      </div>
      <span ref={txt} className="w-6 text-center text-sm font-extrabold tabular-nums text-amber-200" />
    </div>
  );
}

export function MemoryPanel({ snap, engine, layout }: Props) {
  const paused = snap.phase === "PAUSED";
  const phase = paused ? (snap.pausedFrom ?? "PLAYING") : snap.phase;
  const seq = snap.seq;
  const n = seq.length;
  const compact = layout.wide && layout.H < 560;
  const panelW = layout.wide ? Math.min(compact ? 480 : 640, layout.W * (compact ? 0.5 : 0.44)) : Math.min(layout.W - 16, 470);
  const sizes = capsuleSizes(n, panelW - 56);
  const showHint = !compact && layout.H >= 700;
  const tutorial = snap.completed < 2 && !snap.retry;
  // Visual thickness of the artwork frame; a little thinner on small panels.
  const frameW = Math.round(Math.max(22, Math.min(34, panelW * 0.072)));

  let tone = "";
  let variant: string = phase;
  let body: React.ReactNode = null;

  if (phase === "MEMORIZE") {
    const showSeq = !snap.ready && !paused;
    variant = showSeq ? "mem" : "ready";
    const hiddenW = Math.max(26, Math.min(sizes.w, 52));
    body = (
      <>
        <div className="flex items-center justify-center gap-2 text-xl font-extrabold text-white sm:text-2xl">
          {showSeq ? (
            <span>
              به خاطر بسپار! <span aria-hidden>🧠</span>
            </span>
          ) : paused ? (
            <span>توقف</span>
          ) : (
            <span key={snap.countdown} className="anim-count inline-flex items-center gap-3">
              آماده باش!
              <span className="inline-flex h-9 min-w-9 items-center justify-center rounded-full bg-amber-400 px-2 text-xl text-amber-950">
                {fa(snap.countdown, false)}
              </span>
            </span>
          )}
        </div>
        <div className="mt-2.5 flex flex-wrap items-center justify-center gap-2" dir="rtl">
          {seq.map((k, i) =>
            showSeq ? (
              <img
                key={i}
                src={k ? capsuleLongUrl : capsuleShortUrl}
                alt={k ? "بلند" : "کوتاه"}
                draggable={false}
                className="shrink-0 select-none object-contain"
                style={{ width: sizes.w, height: sizes.h }}
              />
            ) : (
              <Capsule key={i} kind="hidden" width={hiddenW} height={sizes.h}>
                ؟
              </Capsule>
            ),
          )}
        </div>
        {showSeq && <MemBar engine={engine} />}
        {showHint && (showSeq || paused) && (
          <p className="mt-2 text-[13px] font-semibold leading-relaxed text-sky-100/90 sm:text-sm">
            {showSeq
              ? snap.retry
                ? "دوباره تلاش کن! همان الگوی قبلی را به خاطر بسپار."
                : snap.stageUp
                  ? `مرحله‌ی ${fa(snap.stage, false)}! الگوها طولانی‌تر و ماشین سریع‌تر شد.`
                  : tutorial
                    ? "الگو را با دقت ببین؛ بعد از پایان زمان پنهان می‌شود!"
                    : "ترتیب و اندازه‌ی قطعه‌ها را به خاطر بسپار."
              : "بازی متوقف شده است."}
          </p>
        )}
      </>
    );
  } else if (phase === "PLAYING") {
    return null;
  } else if (phase === "CHECKING_SEQUENCE") {
    const ok = snap.checkResult === "ok";
    variant = ok ? "ok" : "fail";
    tone = ok ? "drop-shadow(0 0 16px rgba(74,222,128,0.6))" : "drop-shadow(0 0 16px rgba(248,113,113,0.65))";
    body = (
      <>
        <div className="flex items-center justify-center gap-2 text-xl font-extrabold sm:text-2xl">
          <span
            className={cn(
              "inline-flex h-8 w-8 items-center justify-center rounded-full text-lg text-white",
              ok ? "bg-emerald-500" : "bg-red-500",
            )}
          >
            {ok ? "✓" : "✕"}
          </span>
          <span className={ok ? "text-emerald-200" : "text-red-200"}>{ok ? "عالی! همه درست بود" : "اشتباه شد!"}</span>
        </div>
        <p className="mt-1.5 text-sm font-bold text-white">{snap.message}</p>
        {!ok && (
          <div className="mt-1.5 flex items-center justify-center gap-1.5 text-[13px] font-semibold text-red-100/90">
            {snap.lives > 0 ? (
              <>
                <span>یک جان از دست رفت</span>
                <span className="flex">
                  {Array.from({ length: 3 }, (_, i) => (
                    <HeartIcon key={i} filled={i < snap.lives} className="h-4 w-4" />
                  ))}
                </span>
              </>
            ) : (
              <span>جان‌ها تمام شد!</span>
            )}
          </div>
        )}
      </>
    );
  } else {
    return null;
  }

  return (
    <div
      className="pointer-events-none absolute left-1/2 z-10 -translate-x-1/2"
      style={{ width: panelW, top: layout.wide ? 12 : "calc(max(8px, env(safe-area-inset-top)) + 78px)" }}
      dir="rtl"
    >
      <div
        key={variant}
        className="anim-pop text-center"
        style={{
          filter: tone || undefined,
          borderStyle: "solid",
          borderWidth: frameW,
          borderImageSource: `url(${frameUrl})`,
          borderImageSlice: `${FRAME_SLICE} fill`,
          borderImageWidth: `${frameW}px`,
          borderImageRepeat: "stretch",
          padding: compact ? "0 6px 2px" : "2px 10px 8px",
        }}
      >
        {body}
      </div>
    </div>
  );
}
