import { useState } from "react";
import pressUrl from "../assets/press-button.png";
import emissionUrl from "../assets/press-emission.png";
import "./PressButton.css";

interface Props {
  active: boolean;
  down: boolean;
  scale: number;
  onPress: () => void;
}

export function PressButton({ active, down, scale, onPress }: Props) {
  const [pointerDown, setPointerDown] = useState(false);

  return (
    <div
      className="press-device-anchor"
      style={{ width: `min(${238 * scale}px, ${64 * scale}vw)` }}
    >
      <div
        className="press-device"
        data-active={active}
        data-pressed={down || pointerDown}
        data-press-device
      >
        <img src={emissionUrl} alt="" draggable={false} className="press-device-bloom press-device-bloom-wide" />
        <img
          src={pressUrl}
          alt=""
          draggable={false}
          width={638}
          height={510}
          className="press-device-art"
        />
        <img src={emissionUrl} alt="" draggable={false} className="press-device-bloom press-device-bloom-core" />
        <button
          type="button"
          tabIndex={-1}
          data-press
          aria-label="دکمه‌ی پرس"
          onPointerDown={(e) => {
            e.preventDefault();
            e.currentTarget.setPointerCapture(e.pointerId);
            setPointerDown(true);
            onPress();
          }}
          onPointerUp={() => setPointerDown(false)}
          onPointerCancel={() => setPointerDown(false)}
          onLostPointerCapture={() => setPointerDown(false)}
          onMouseDown={(e) => e.preventDefault()}
          onContextMenu={(e) => e.preventDefault()}
          className="press-device-hit"
        />
      </div>
    </div>
  );
}
