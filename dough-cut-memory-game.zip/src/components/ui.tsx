import type { ReactNode } from "react";
import { cn } from "../utils/cn";

type IconProps = { className?: string };

export function TrophyIcon({ className }: IconProps) {
  return (
    <svg viewBox="0 0 64 64" className={className} aria-hidden>
      <defs>
        <linearGradient id="trophyG" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#fff2a8" />
          <stop offset="0.5" stopColor="#ffc928" />
          <stop offset="1" stopColor="#d98b06" />
        </linearGradient>
      </defs>
      <path d="M17 12H8c0 10 4 16 12 18M47 12h9c0 10-4 16-12 18" fill="none" stroke="#e5a10c" strokeWidth="4.5" strokeLinecap="round" />
      <path d="M16 6h32v18c0 10-7 17-16 18-9-1-16-8-16-18V6z" fill="url(#trophyG)" stroke="#8a5500" strokeWidth="2" />
      <path d="M22 11v12c0 5 2 9 5 12" fill="none" stroke="#fff" strokeOpacity="0.65" strokeWidth="3" strokeLinecap="round" />
      <rect x="28" y="42" width="8" height="9" fill="url(#trophyG)" stroke="#8a5500" strokeWidth="2" />
      <rect x="19" y="51" width="26" height="8" rx="2.5" fill="url(#trophyG)" stroke="#8a5500" strokeWidth="2" />
    </svg>
  );
}

export function GearIcon({ className }: IconProps) {
  const teeth = Array.from({ length: 8 }, (_, i) => i * 45);
  return (
    <svg viewBox="0 0 64 64" className={className} aria-hidden>
      <defs>
        <linearGradient id="gearG" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#7cc4ff" />
          <stop offset="1" stopColor="#1d7be0" />
        </linearGradient>
      </defs>
      <g fill="url(#gearG)">
        {teeth.map((a) => (
          <rect key={a} x="27" y="4" width="10" height="14" rx="2.5" transform={`rotate(${a} 32 32)`} />
        ))}
        <circle cx="32" cy="32" r="21" />
      </g>
      <circle cx="32" cy="32" r="9" fill="#0b1a3c" />
      <circle cx="32" cy="32" r="21" fill="none" stroke="#fff" strokeOpacity="0.35" strokeWidth="2" />
    </svg>
  );
}

export function PauseIcon({ className }: IconProps) {
  return (
    <svg viewBox="0 0 32 32" className={className} aria-hidden>
      <rect x="8" y="6" width="6" height="20" rx="2" fill="currentColor" />
      <rect x="18" y="6" width="6" height="20" rx="2" fill="currentColor" />
    </svg>
  );
}

export function PlayIcon({ className }: IconProps) {
  return (
    <svg viewBox="0 0 32 32" className={className} aria-hidden>
      <path d="M10 5.5v21a1 1 0 0 0 1.5.86l17-10.5a1 1 0 0 0 0-1.72l-17-10.5A1 1 0 0 0 10 5.5z" fill="currentColor" />
    </svg>
  );
}

export function ScissorsIcon({ className }: IconProps) {
  return (
    <svg viewBox="0 0 64 64" className={className} fill="none" aria-hidden>
      <g stroke="currentColor" strokeWidth="6" strokeLinecap="round" strokeLinejoin="round">
        <circle cx="18" cy="48" r="8.5" />
        <circle cx="46" cy="48" r="8.5" />
        <path d="M23.5 41 L43 8 M40.5 41 L21 8" />
      </g>
      <circle cx="32" cy="29" r="2.6" fill="currentColor" />
    </svg>
  );
}

export function HeartIcon({ className, filled = true }: IconProps & { filled?: boolean }) {
  return (
    <svg viewBox="0 0 24 24" className={className} aria-hidden>
      <path
        d="M12 21s-8-5.2-8-11.2C4 6.6 6.4 4.5 9 4.5c1.4 0 2.5.6 3 1.5.5-.9 1.6-1.5 3-1.5 2.6 0 5 2.1 5 5.3C20 15.8 12 21 12 21z"
        fill={filled ? "#ff4d5e" : "#27304d"}
        stroke={filled ? "#fff" : "#4b5a86"}
        strokeOpacity={filled ? 0.85 : 0.9}
        strokeWidth="1.3"
      />
      {filled && <path d="M8 8.2c.5-.9 1.5-1.2 2.3-.8" stroke="#fff" strokeOpacity="0.7" strokeWidth="1.4" strokeLinecap="round" fill="none" />}
    </svg>
  );
}

export function HomeIcon({ className }: IconProps) {
  return (
    <svg viewBox="0 0 24 24" className={className} fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" aria-hidden>
      <path d="M3 11l9-8 9 8" />
      <path d="M5 10v10h5v-6h4v6h5V10" />
    </svg>
  );
}

export function RestartIcon({ className }: IconProps) {
  return (
    <svg viewBox="0 0 24 24" className={className} fill="none" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round" aria-hidden>
      <path d="M20 12a8 8 0 1 1-2.6-5.9" />
      <path d="M20 4v5h-5" />
    </svg>
  );
}

export function CheckIcon({ className }: IconProps) {
  return (
    <svg viewBox="0 0 24 24" className={className} fill="none" stroke="currentColor" strokeWidth="3.4" strokeLinecap="round" strokeLinejoin="round" aria-hidden>
      <path d="M5 12.5l4.5 4.5L19 7" />
    </svg>
  );
}

export function CrossIcon({ className }: IconProps) {
  return (
    <svg viewBox="0 0 24 24" className={className} fill="none" stroke="currentColor" strokeWidth="3.4" strokeLinecap="round" aria-hidden>
      <path d="M6 6l12 12M18 6L6 18" />
    </svg>
  );
}

export function CloseIcon({ className }: IconProps) {
  return <CrossIcon className={className} />;
}

export function MusicIcon({ className }: IconProps) {
  return (
    <svg viewBox="0 0 24 24" className={className} fill="currentColor" aria-hidden>
      <path d="M9 17.5V6.5l11-2v11" fill="none" stroke="currentColor" strokeWidth="2" strokeLinejoin="round" />
      <circle cx="6.5" cy="17.5" r="2.8" />
      <circle cx="17.5" cy="15.5" r="2.8" />
    </svg>
  );
}

export function SpeakerIcon({ className }: IconProps) {
  return (
    <svg viewBox="0 0 24 24" className={className} fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden>
      <path d="M4 9.5v5h3.5L12 18.5v-13L7.5 9.5H4z" fill="currentColor" />
      <path d="M15.5 9a4 4 0 0 1 0 6M18 6.5a7.5 7.5 0 0 1 0 11" />
    </svg>
  );
}

/** Rounded dough-shaped indicator: short = compact capsule, long = wide capsule. */
export function Capsule({
  kind,
  width,
  height,
  label,
  className,
  children,
}: {
  kind: "short" | "long" | "hidden";
  width: number;
  height: number;
  label?: string;
  className?: string;
  children?: ReactNode;
}) {
  return (
    <div
      className={cn(
        "flex shrink-0 items-center justify-center rounded-full font-extrabold leading-none transition-[width,transform] duration-200",
        kind === "short" && "capsule-short",
        kind === "long" && "capsule-long",
        kind === "hidden" && "capsule-hidden",
        className,
      )}
      style={{ width, height, fontSize: Math.max(10, Math.min(18, height * 0.42)) }}
    >
      {children ?? label}
    </div>
  );
}

export function Switch({
  checked,
  onChange,
  label,
}: {
  checked: boolean;
  onChange: (v: boolean) => void;
  label: string;
}) {
  return (
    <button
      type="button"
      role="switch"
      aria-checked={checked}
      aria-label={label}
      onClick={() => onChange(!checked)}
      className={cn(
        "relative h-8 w-14 shrink-0 rounded-full border-2 transition-colors",
        checked ? "border-amber-200/80 bg-amber-400" : "border-blue-300/40 bg-[#1b2a52]",
      )}
      dir="ltr"
    >
      <span
        className={cn(
          "absolute top-0.5 h-6 w-6 rounded-full bg-white shadow-md transition-all",
          checked ? "left-[26px]" : "left-0.5",
        )}
      />
    </button>
  );
}

export function Modal({
  children,
  tone = "blue",
  z = 40,
  className,
}: {
  children: ReactNode;
  tone?: "blue" | "gold" | "green" | "red";
  z?: number;
  className?: string;
}) {
  return (
    <div
      className="anim-fade absolute inset-0 flex items-center justify-center bg-[#030712]/65 px-4 backdrop-blur-[3px]"
      style={{ zIndex: z }}
      role="dialog"
      aria-modal="true"
      dir="rtl"
    >
      <div
        className={cn(
          "panel anim-pop relative max-h-[92%] w-full max-w-sm overflow-y-auto rounded-3xl p-5",
          tone === "gold" && "panel-gold",
          tone === "green" && "panel-green",
          tone === "red" && "panel-red",
          className,
        )}
        style={{ touchAction: "pan-y", overscrollBehavior: "contain" }}
      >
        {children}
      </div>
    </div>
  );
}
