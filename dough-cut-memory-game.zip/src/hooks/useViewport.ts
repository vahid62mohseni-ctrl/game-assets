import { useEffect, useState } from "react";

function read() {
  return { w: Math.round(window.innerWidth), h: Math.round(window.innerHeight) };
}

/** Tracks the visible viewport size (handles rotation and mobile browser toolbars). */
export function useViewport() {
  const [vp, setVp] = useState(read);
  useEffect(() => {
    const on = () => setVp((prev) => {
      const n = read();
      return prev.w === n.w && prev.h === n.h ? prev : n;
    });
    window.addEventListener("resize", on);
    window.addEventListener("orientationchange", on);
    window.visualViewport?.addEventListener("resize", on);
    return () => {
      window.removeEventListener("resize", on);
      window.removeEventListener("orientationchange", on);
      window.visualViewport?.removeEventListener("resize", on);
    };
  }, []);
  return vp;
}
