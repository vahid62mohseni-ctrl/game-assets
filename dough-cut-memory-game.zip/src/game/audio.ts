import type { Settings } from "./storage";

export type SoundName =
  | "press"
  | "cut"
  | "correct"
  | "perfect"
  | "wrong"
  | "sequence"
  | "stage"
  | "gameover"
  | "record"
  | "tick"
  | "go"
  | "click";

interface NoiseOpts {
  type: BiquadFilterType;
  freq: number;
  freqEnd?: number;
  q?: number;
  vol: number;
  attack?: number;
  dest?: AudioNode;
}

const STEP = 0.3; // seconds per 8th note (100 bpm)
const BASS = [55, 43.65, 65.41, 49];
const ARP = [
  [220, 261.63, 329.63],
  [174.61, 220, 261.63],
  [196, 261.63, 329.63],
  [196, 246.94, 293.66],
];

/**
 * Fully synthesised audio (no asset files). Every public method is wrapped in try/catch so a
 * blocked / missing AudioContext can never interfere with gameplay.
 */
export class AudioEngine {
  private ctx: AudioContext | null = null;
  private failed = false;
  private master: GainNode | null = null;
  private musicBus: GainNode | null = null;
  private sfxBus: GainNode | null = null;
  private noiseBuf: AudioBuffer | null = null;
  private brownBuf: AudioBuffer | null = null;
  private machineGain: GainNode | null = null;
  private machineOsc: OscillatorNode | null = null;
  private machineLevel = -1;
  private ambienceOn = false;
  private musicTimer: number | null = null;
  private clankTimer: number | null = null;
  private nextStepTime = 0;
  private step = 0;

  constructor(private settings: Settings) {}

  get available(): boolean {
    return !!this.ctx && !this.failed;
  }

  /** Must be called from a user gesture. Safe to call repeatedly. */
  unlock(): void {
    if (this.failed) return;
    try {
      if (!this.ctx) {
        const AC: typeof AudioContext | undefined =
          window.AudioContext ||
          (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
        if (!AC) {
          this.failed = true;
          return;
        }
        this.ctx = new AC();
        this.buildGraph();
      }
      const c = this.ctx;
      if (c && c.state === "suspended") {
        void c.resume().catch(() => undefined);
      }
      this.applySettings();
      this.startAmbience();
      this.syncMusic();
    } catch {
      this.failed = true;
    }
  }

  setSettings(s: Settings): void {
    this.settings = s;
    try {
      this.applySettings();
      this.syncMusic();
    } catch {
      /* ignore */
    }
  }

  /** Suspend / resume when the tab is hidden. */
  setActive(active: boolean): void {
    try {
      const c = this.ctx;
      if (!c) return;
      if (active && c.state === "suspended") void c.resume().catch(() => undefined);
      if (!active && c.state === "running") void c.suspend().catch(() => undefined);
    } catch {
      /* ignore */
    }
  }

  /** 0..1 – how fast the machine is currently running. */
  setMachine(level: number): void {
    try {
      const c = this.ctx;
      if (!c || !this.machineGain || !this.machineOsc) return;
      if (Math.abs(level - this.machineLevel) < 0.015) return;
      this.machineLevel = level;
      const t = c.currentTime;
      this.machineGain.gain.setTargetAtTime(level * 0.1, t, 0.08);
      this.machineOsc.frequency.setTargetAtTime(38 + level * 16, t, 0.1);
    } catch {
      /* ignore */
    }
  }

  play(name: SoundName): void {
    const c = this.ctx;
    if (!c || this.failed || !this.settings.sfx || !this.sfxBus) return;
    try {
      const t = c.currentTime + 0.002;
      switch (name) {
        case "press":
          this.noise(t, 0.16, { type: "highpass", freq: 1400, vol: 0.2 });
          this.tone(170, t, 0.2, "sine", 0.5, 50);
          this.tone(95, t, 0.12, "square", 0.06, 60);
          break;
        case "cut":
          // Blade impact lands ~50ms after the button (matches the press animation).
          this.noise(t + 0.05, 0.09, { type: "bandpass", freq: 3800, q: 1.4, vol: 0.5 });
          this.tone(1500, t + 0.05, 0.12, "triangle", 0.13, 650);
          this.noise(t + 0.055, 0.15, { type: "lowpass", freq: 520, vol: 0.38 });
          this.tone(72, t + 0.05, 0.16, "sine", 0.4, 42);
          break;
        case "correct":
          this.tone(659.25, t + 0.07, 0.14, "sine", 0.26);
          this.tone(880, t + 0.16, 0.24, "sine", 0.26);
          break;
        case "perfect":
          this.tone(659.25, t + 0.07, 0.14, "sine", 0.26);
          this.tone(880, t + 0.15, 0.16, "sine", 0.26);
          this.tone(1318.5, t + 0.23, 0.34, "triangle", 0.2);
          break;
        case "wrong":
          this.tone(196, t + 0.07, 0.3, "square", 0.15, 120);
          this.tone(147, t + 0.24, 0.34, "square", 0.15, 78);
          break;
        case "sequence":
          [523.25, 659.25, 783.99, 1046.5].forEach((f, i) =>
            this.tone(f, t + 0.1 + i * 0.14, 0.26, "triangle", 0.28),
          );
          this.tone(1568, t + 0.68, 0.7, "sine", 0.12);
          break;
        case "stage":
          this.tone(320, t, 0.55, "sine", 0.16, 960);
          this.noise(t, 0.5, { type: "bandpass", freq: 600, freqEnd: 4200, q: 0.9, vol: 0.12, attack: 0.15 });
          break;
        case "gameover":
          [392, 329.63, 261.63, 196].forEach((f, i) =>
            this.tone(f, t + i * 0.3, 0.34, "square", 0.13, f * 0.96),
          );
          this.tone(62, t + 1.0, 1.0, "sawtooth", 0.22, 34);
          break;
        case "record":
          [523.25, 659.25, 783.99, 1046.5, 1318.5].forEach((f, i) =>
            this.tone(f, t + i * 0.1, 0.4, "triangle", 0.26),
          );
          this.tone(1568, t + 0.55, 1.0, "sine", 0.14);
          break;
        case "tick":
          this.tone(880, t, 0.09, "square", 0.1);
          break;
        case "go":
          this.tone(1320, t, 0.24, "square", 0.11);
          this.tone(660, t, 0.26, "triangle", 0.2);
          break;
        case "click":
          this.tone(700, t, 0.06, "triangle", 0.15, 480);
          break;
      }
    } catch {
      /* audio must never break gameplay */
    }
  }

  // ---------------------------------------------------------------------------------------
  // internals
  // ---------------------------------------------------------------------------------------

  private buildGraph(): void {
    const c = this.ctx!;
    const comp = c.createDynamicsCompressor();
    comp.threshold.value = -14;
    comp.ratio.value = 5;
    comp.connect(c.destination);
    this.master = c.createGain();
    this.master.gain.value = 0.9;
    this.master.connect(comp);
    this.musicBus = c.createGain();
    this.sfxBus = c.createGain();
    this.musicBus.connect(this.master);
    this.sfxBus.connect(this.master);

    // white noise
    const len = c.sampleRate * 2;
    this.noiseBuf = c.createBuffer(1, len, c.sampleRate);
    const d = this.noiseBuf.getChannelData(0);
    for (let i = 0; i < len; i++) d[i] = Math.random() * 2 - 1;
    // brown noise (rumble)
    this.brownBuf = c.createBuffer(1, len, c.sampleRate);
    const b = this.brownBuf.getChannelData(0);
    let last = 0;
    for (let i = 0; i < len; i++) {
      const w = Math.random() * 2 - 1;
      last = (last + 0.02 * w) / 1.02;
      b[i] = last * 3.5;
    }
  }

  private applySettings(): void {
    const c = this.ctx;
    if (!c || !this.musicBus || !this.sfxBus) return;
    const s = this.settings;
    const t = c.currentTime;
    this.musicBus.gain.setTargetAtTime(s.music ? s.musicVol * 0.55 : 0, t, 0.05);
    this.sfxBus.gain.setTargetAtTime(s.sfx ? s.sfxVol : 0, t, 0.05);
  }

  private startAmbience(): void {
    const c = this.ctx;
    if (!c || this.ambienceOn || !this.sfxBus || !this.brownBuf || !this.noiseBuf) return;
    this.ambienceOn = true;

    // Soft factory ambience: low rumble + distant hiss + mains hum.
    const rumble = c.createBufferSource();
    rumble.buffer = this.brownBuf;
    rumble.loop = true;
    const lp = c.createBiquadFilter();
    lp.type = "lowpass";
    lp.frequency.value = 420;
    const ag = c.createGain();
    ag.gain.value = 0.16;
    rumble.connect(lp).connect(ag).connect(this.sfxBus);
    rumble.start();

    const hiss = c.createBufferSource();
    hiss.buffer = this.noiseBuf;
    hiss.loop = true;
    const bp = c.createBiquadFilter();
    bp.type = "bandpass";
    bp.frequency.value = 2400;
    bp.Q.value = 0.4;
    const hg = c.createGain();
    hg.gain.value = 0.006;
    hiss.connect(bp).connect(hg).connect(this.sfxBus);
    hiss.start();

    for (const f of [50, 100.4]) {
      const o = c.createOscillator();
      o.type = "sine";
      o.frequency.value = f;
      const g = c.createGain();
      g.gain.value = 0.012;
      o.connect(g).connect(this.sfxBus);
      o.start();
    }

    // Machine (extrusion motor) – level driven by the game.
    this.machineGain = c.createGain();
    this.machineGain.gain.value = 0;
    const mo = c.createOscillator();
    mo.type = "sawtooth";
    mo.frequency.value = 38;
    const mlp = c.createBiquadFilter();
    mlp.type = "lowpass";
    mlp.frequency.value = 170;
    mo.connect(mlp).connect(this.machineGain);
    this.machineOsc = mo;
    mo.start();
    const mn = c.createBufferSource();
    mn.buffer = this.noiseBuf;
    mn.loop = true;
    const mbp = c.createBiquadFilter();
    mbp.type = "bandpass";
    mbp.frequency.value = 460;
    mbp.Q.value = 0.7;
    const mng = c.createGain();
    mng.gain.value = 0.35;
    mn.connect(mbp).connect(mng).connect(this.machineGain);
    mn.start();
    // chugging LFO
    const lfo = c.createOscillator();
    lfo.frequency.value = 7;
    const lg = c.createGain();
    lg.gain.value = 0.018;
    lfo.connect(lg).connect(this.machineGain.gain);
    lfo.start();
    this.machineGain.connect(this.sfxBus);

    this.scheduleClank();
  }

  private scheduleClank(): void {
    if (this.clankTimer != null) return;
    const loop = () => {
      this.clankTimer = window.setTimeout(
        () => {
          try {
            const c = this.ctx;
            if (c && c.state === "running" && this.settings.sfx) {
              const t = c.currentTime + 0.01;
              const f = 520 + Math.random() * 520;
              this.tone(f, t, 0.32, "triangle", 0.035, f * 0.7);
              this.noise(t, 0.12, { type: "bandpass", freq: 1800, q: 2, vol: 0.03 });
            }
          } catch {
            /* ignore */
          }
          loop();
        },
        4000 + Math.random() * 6000,
      );
    };
    loop();
  }

  private syncMusic(): void {
    const c = this.ctx;
    if (!c) return;
    if (this.settings.music && this.settings.musicVol > 0) {
      if (this.musicTimer == null) {
        this.nextStepTime = c.currentTime + 0.1;
        this.musicTimer = window.setInterval(() => this.scheduleMusic(), 90);
      }
    } else if (this.musicTimer != null) {
      window.clearInterval(this.musicTimer);
      this.musicTimer = null;
    }
  }

  private scheduleMusic(): void {
    try {
      const c = this.ctx;
      if (!c || c.state !== "running") return;
      if (this.nextStepTime < c.currentTime - 0.3) this.nextStepTime = c.currentTime + 0.05;
      while (this.nextStepTime < c.currentTime + 0.35) {
        this.musicStep(this.step, this.nextStepTime);
        this.nextStepTime += STEP;
        this.step = (this.step + 1) % 32;
      }
    } catch {
      /* ignore */
    }
  }

  private musicStep(step: number, t: number): void {
    const bar = Math.floor(step / 8) % 4;
    const s = step % 8;
    const bus = this.musicBus!;
    if (s === 0 || s === 4) {
      this.tone(120, t, 0.18, "sine", 0.34, 45, bus);
    }
    if (s % 2 === 1) {
      this.noise(t, 0.04, { type: "highpass", freq: 8000, vol: 0.05, dest: bus });
    } else if (s === 2 || s === 6) {
      this.noise(t, 0.09, { type: "bandpass", freq: 2200, q: 0.8, vol: 0.05, dest: bus });
    }
    if (s === 0 || s === 3 || s === 4 || s === 6) {
      this.tone(BASS[bar], t, 0.26, "triangle", 0.3, undefined, bus);
      this.tone(BASS[bar] * 2, t, 0.2, "sawtooth", 0.035, undefined, bus);
    }
    const arp = ARP[bar];
    if (s !== 5) {
      this.tone(arp[s % 3] * 2, t, 0.22, "triangle", 0.05, undefined, bus);
    }
    if (s === 0) {
      this.tone(arp[0], t, STEP * 7, "sine", 0.05, undefined, bus);
      this.tone(arp[2], t, STEP * 7, "sine", 0.04, undefined, bus);
    }
  }

  private tone(
    freq: number,
    t0: number,
    dur: number,
    type: OscillatorType,
    vol: number,
    freqEnd?: number,
    dest?: AudioNode,
  ): void {
    const c = this.ctx!;
    const o = c.createOscillator();
    const g = c.createGain();
    o.type = type;
    o.frequency.setValueAtTime(freq, t0);
    if (freqEnd) o.frequency.exponentialRampToValueAtTime(Math.max(20, freqEnd), t0 + dur);
    g.gain.setValueAtTime(0.0001, t0);
    g.gain.exponentialRampToValueAtTime(Math.max(0.0002, vol), t0 + 0.01);
    g.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
    o.connect(g);
    g.connect(dest ?? this.sfxBus!);
    o.start(t0);
    o.stop(t0 + dur + 0.03);
  }

  private noise(t0: number, dur: number, o: NoiseOpts): void {
    const c = this.ctx!;
    if (!this.noiseBuf) return;
    const src = c.createBufferSource();
    src.buffer = this.noiseBuf;
    const f = c.createBiquadFilter();
    f.type = o.type;
    f.frequency.setValueAtTime(o.freq, t0);
    if (o.freqEnd) f.frequency.exponentialRampToValueAtTime(o.freqEnd, t0 + dur);
    f.Q.value = o.q ?? 0.8;
    const g = c.createGain();
    const atk = o.attack ?? 0.004;
    g.gain.setValueAtTime(0.0001, t0);
    g.gain.exponentialRampToValueAtTime(Math.max(0.0002, o.vol), t0 + atk);
    g.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
    src.connect(f).connect(g).connect(o.dest ?? this.sfxBus!);
    src.start(t0, Math.random() * 1.5);
    src.stop(t0 + dur + 0.03);
  }
}
