import { LONG_LEN, PRESS_X, SHORT_LEN } from "./config";
import type { Engine, Segment } from "./engine";
import { glow, lin, rrPath, type Ctx } from "./gfx";
import { BELT, type Layout } from "./layout";
import bgUrl from "../assets/factory-bg.jpg";
import armUrl from "../assets/press-arm.webp";

const FONT = '"Vazirmatn Variable", Tahoma, system-ui, sans-serif';

const DOUGH_STOPS: ReadonlyArray<readonly [number, string]> = [
  [0, "#fff7d9"],
  [0.2, "#fae5a9"],
  [0.55, "#efcb84"],
  [0.86, "#d8a85a"],
  [1, "#e3bc74"],
];

/**
 * Geometry of the press sprite sheet (press-arm.webp), in sheet pixels. The sheet is the supplied
 * artwork with its background removed; the renderer slices it into four layers:
 *   housing  – ceiling mount, cylinder body and hazard collar (static; hose regions cut out)
 *   hoses    – the hanging hoses between housing and arm (stretch + sway with the arm)
 *   rod      – a slice of the chrome rod, stretched to fill the gap when the arm extends
 *   carriage – rod top, slide block, blade head and blade (moves down on a cut)
 */
const ARM = {
  w: 930,
  h: 1412,
  /** rows above this line are the static housing (bottom edge of the hazard collar) */
  housingBottom: 786,
  /** rows reused as the ceiling column above the housing (portrait screens) */
  topRows: 6,
  /** width of the blade head -> drives the on-screen scale */
  headWidth: 500,
  /** blade tip */
  tip: { x: 228.5, y: 1406 },
  carriage: { x0: 88, x1: 695, y0: 786, y1: 1412, hoseCutX: 175, hoseCutY: 826 },
  rod: { x0: 174, x1: 360, y0: 864, y1: 870 },
  hoseL: {
    x1: 175,
    x1Narrow: 167, // beside the collar's left edge
    narrowFrom: 744,
    narrowTo: 786,
    top: 545, // emerges from under the housing here
    bottom: 826, // meets the fitting on the rod
    hiddenTop: 345, // synthetic rows (hidden behind the housing) start here
    synth: { x0: 30, x1: 84, y0: 548, y1: 556, shift: 10 },
    pivotX: 55,
  },
  hoseR: { x0: 638, x0Narrow: 642, narrowFrom: 740, x1: 930, top: 296, bottom: 786, pivotX: 730 },
} as const;
/** Blade-head width in world units (dough diameter = 0.56). */
const PRESS_HEAD_U = 1.25;
/** Gap between the resting blade tip and the top of the dough, in world units. */
const PRESS_REST_GAP_U = 0.08;

interface ArmSprites {
  k: number; // screen px per sheet px
  housing: HTMLCanvasElement;
  top: HTMLCanvasElement;
  hoseL: HTMLCanvasElement;
  hoseR: HTMLCanvasElement;
  rod: HTMLCanvasElement;
  carriage: HTMLCanvasElement;
}

/**
 * Canvas renderer. The factory (everything static) is drawn once into an off-screen cache; each
 * frame only the belt, dough, segments, press and particles are drawn on top.
 */
export class Renderer {
  private ctx: Ctx;
  private cache: HTMLCanvasElement | null = null;
  private L: Layout | null = null;
  private dpr = 1;
  private img: HTMLImageElement | null = null;
  private imgReady = false;
  /** Pre-rendered vertical slice of the dough (used for the bent part leaving the nozzle). */
  private strip: HTMLCanvasElement | null = null;
  private arm: HTMLImageElement | null = null;
  private armReady = false;
  private sprites: ArmSprites | null = null;
  private disposed = false;

  constructor(private canvas: HTMLCanvasElement) {
    const c = canvas.getContext("2d", { alpha: false });
    if (!c) throw new Error("Canvas 2D is not available");
    this.ctx = c;
    const img = new Image();
    img.decoding = "async";
    img.onload = () => {
      if (this.disposed) return;
      this.imgReady = true;
      this.rebuild();
    };
    img.src = bgUrl;
    this.img = img;
    const arm = new Image();
    arm.decoding = "async";
    arm.onload = () => {
      if (this.disposed) return;
      this.armReady = true;
      if (this.L) this.buildArm(this.L);
    };
    arm.src = armUrl;
    this.arm = arm;
  }

  dispose(): void {
    this.disposed = true;
    if (this.img) this.img.onload = null;
    if (this.arm) this.arm.onload = null;
  }

  resize(L: Layout, dpr: number, engine: Engine): void {
    this.L = L;
    this.dpr = dpr;
    const w = Math.round(L.W * dpr);
    const h = Math.round(L.H * dpr);
    this.canvas.width = w;
    this.canvas.height = h;
    this.canvas.style.width = `${L.W}px`;
    this.canvas.style.height = `${L.H}px`;
    engine.viewRight = (L.W - L.x0) / L.u + 0.6;
    this.rebuild();
  }

  /** Re-render the static layer (background picture + extension of its edges). */
  rebuild(): void {
    const L = this.L;
    if (!L) return;
    const cache = document.createElement("canvas");
    cache.width = Math.round(L.W * this.dpr);
    cache.height = Math.round(L.H * this.dpr);
    const cc = cache.getContext("2d");
    if (!cc) return;
    cc.scale(this.dpr, this.dpr);
    this.paintBackground(cc, L);
    this.cache = cache;
    this.buildStrip(L);
    if (this.armReady) this.buildArm(L);
  }

  // ---- press sprite sheet -----------------------------------------------------------------
  /** Slice the press artwork into display-resolution sprites for the current layout. */
  private buildArm(L: Layout): void {
    const arm = this.arm;
    if (!arm || !arm.naturalWidth) return;
    const k = (PRESS_HEAD_U * L.u) / ARM.headWidth;
    const ks = k * this.dpr; // device px per sheet px
    const A = ARM;

    const part = (sw: number, sh: number): [HTMLCanvasElement, Ctx] => {
      const cv = document.createElement("canvas");
      cv.width = Math.max(1, Math.ceil(sw * ks));
      cv.height = Math.max(1, Math.ceil(sh * ks));
      const cc = cv.getContext("2d")!;
      cc.imageSmoothingEnabled = true;
      cc.imageSmoothingQuality = "high";
      return [cv, cc];
    };
    const blit = (cc: Ctx, sx: number, sy: number, sw: number, sh: number, dx: number, dy: number, dw = sw * ks, dh = sh * ks) =>
      this.downscale(arm, sx, sy, sw, sh, cc, dx, dy, dw, dh);
    const clear = (cc: Ctx, x: number, y: number, w: number, h: number) =>
      cc.clearRect(Math.floor(x * ks), Math.floor(y * ks), Math.ceil(w * ks), Math.ceil(h * ks));

    // housing: everything above the collar bottom, minus the hanging hose regions
    const [housing, hc] = part(A.w, A.housingBottom);
    blit(hc, 0, 0, A.w, A.housingBottom, 0, 0);
    clear(hc, 0, A.hoseL.top, A.hoseL.x1, A.hoseL.narrowFrom - A.hoseL.top);
    clear(hc, 0, A.hoseL.narrowFrom, A.hoseL.x1Narrow, A.housingBottom - A.hoseL.narrowFrom);
    clear(hc, A.hoseR.x0, A.hoseR.top, A.w - A.hoseR.x0, A.hoseR.narrowFrom - A.hoseR.top);
    clear(hc, A.hoseR.x0Narrow, A.hoseR.narrowFrom, A.w - A.hoseR.x0Narrow, A.housingBottom - A.hoseR.narrowFrom);

    // ceiling column: the top rows, stretched upwards when the housing hangs below the screen top
    const [top, tc] = part(A.w, A.topRows);
    blit(tc, 0, 0, A.w, A.topRows, 0, 0);

    // left hose: synthetic rows hidden behind the housing + the visible hanging part
    const hl = A.hoseL;
    const hlH = hl.bottom - hl.hiddenTop;
    const [hoseL, lc] = part(hl.x1, hlH);
    const synthW = hl.synth.x1 - hl.synth.x0;
    blit(lc, hl.synth.x0, hl.synth.y0, synthW, hl.synth.y1 - hl.synth.y0,
      (hl.synth.x0 + hl.synth.shift) * ks, 0, synthW * ks, (hl.top - hl.hiddenTop + 1) * ks);
    blit(lc, 0, hl.top, hl.x1, hl.bottom - hl.top, 0, (hl.top - hl.hiddenTop) * ks);
    clear(lc, hl.x1Narrow, hl.narrowFrom - hl.hiddenTop, hl.x1 - hl.x1Narrow, hl.narrowTo - hl.narrowFrom);

    // right hoses
    const hr = A.hoseR;
    const [hoseR, rc] = part(hr.x1 - hr.x0, hr.bottom - hr.top);
    blit(rc, hr.x0, hr.top, hr.x1 - hr.x0, hr.bottom - hr.top, 0, 0);
    clear(rc, 0, hr.narrowFrom - hr.top, hr.x0Narrow - hr.x0, hr.bottom - hr.narrowFrom);

    // rod slice
    const [rod, rdc] = part(A.rod.x1 - A.rod.x0, A.rod.y1 - A.rod.y0);
    blit(rdc, A.rod.x0, A.rod.y0, A.rod.x1 - A.rod.x0, A.rod.y1 - A.rod.y0, 0, 0);

    // carriage: rod top, slide block, head and blade (minus the hose end that belongs to the hose)
    const cr = A.carriage;
    const [carriage, cc] = part(cr.x1 - cr.x0, cr.y1 - cr.y0);
    blit(cc, cr.x0, cr.y0, cr.x1 - cr.x0, cr.y1 - cr.y0, 0, 0);
    clear(cc, 0, 0, cr.hoseCutX - cr.x0, cr.hoseCutY - cr.y0);

    this.sprites = { k, housing, top, hoseL, hoseR, rod, carriage };
  }

  /** drawImage with progressive halving so large downscales stay crisp in every browser. */
  private downscale(
    src: CanvasImageSource,
    sx: number, sy: number, sw: number, sh: number,
    dst: Ctx, dx: number, dy: number, dw: number, dh: number,
  ): void {
    let cur: CanvasImageSource = src;
    let cx = sx, cy = sy, cw = sw, ch = sh;
    while (cw > dw * 2 && ch > dh * 2) {
      const nw = Math.max(1, Math.round(cw / 2));
      const nh = Math.max(1, Math.round(ch / 2));
      const tmp = document.createElement("canvas");
      tmp.width = nw;
      tmp.height = nh;
      const tc = tmp.getContext("2d")!;
      tc.imageSmoothingEnabled = true;
      tc.imageSmoothingQuality = "high";
      tc.drawImage(cur, cx, cy, cw, ch, 0, 0, nw, nh);
      cur = tmp; cx = 0; cy = 0; cw = nw; ch = nh;
    }
    dst.drawImage(cur, cx, cy, cw, ch, dx, dy, dw, dh);
  }

  private paintBackground(c: Ctx, L: Layout): void {
    const { W, H, bg } = L;
    const img = this.img;
    // Neutral fallback while the picture decodes.
    c.fillStyle = lin(c, 0, 0, 0, H, [
      [0, "#0b1226"],
      [0.6, "#233d69"],
      [1, "#1a2540"],
    ]);
    c.fillRect(0, 0, W, H);
    if (!img || !this.imgReady || !img.naturalWidth) return;

    const k = bg.h / img.naturalHeight; // screen px per source px
    const gapTop = Math.max(0, bg.y);
    const gapBottom = Math.max(0, H - (bg.y + bg.h));
    const smooth = (canvas: HTMLCanvasElement, sx: number, sy: number, sw: number, sh: number, dx: number, dy: number, dw: number, dh: number) => {
      // Down-sample then up-sample: a cheap blur that works in every browser.
      const t = canvas.getContext("2d");
      if (!t) return;
      t.imageSmoothingEnabled = true;
      t.imageSmoothingQuality = "high";
      t.drawImage(img, sx, sy, sw, sh, 0, 0, canvas.width, canvas.height);
      c.imageSmoothingEnabled = true;
      c.imageSmoothingQuality = "high";
      c.drawImage(canvas, dx, dy, dw, dh);
    };

    // Visible horizontal part of the picture (source px).
    const vx0 = Math.max(0, -bg.x);
    const vx1 = Math.min(bg.w, W - bg.x);
    const srcX = vx0 / k;
    const srcW = Math.max(1, (vx1 - vx0) / k);
    const edge = Math.max(2, Math.round(img.naturalHeight * 0.02));

    // Extension above (ceiling) and below (floor): the picture's edge rows, stretched + blurred.
    if (gapTop > 0.5) {
      const tiny = document.createElement("canvas");
      tiny.width = 48;
      tiny.height = 2;
      smooth(tiny, srcX, 0, srcW, edge, 0, 0, W, gapTop + 2);
      c.fillStyle = lin(c, 0, 0, 0, gapTop, [
        [0, "rgba(3,6,16,0.6)"],
        [1, "rgba(3,6,16,0.1)"],
      ]);
      c.fillRect(0, 0, W, gapTop);
    }
    if (gapBottom > 0.5) {
      const tiny = document.createElement("canvas");
      tiny.width = 48;
      tiny.height = 2;
      const y0 = bg.y + bg.h;
      smooth(tiny, srcX, img.naturalHeight - edge, srcW, edge, 0, y0 - 2, W, gapBottom + 2);
      c.fillStyle = lin(c, 0, y0, 0, H, [
        [0, "rgba(3,6,16,0.1)"],
        [1, "rgba(3,6,16,0.55)"],
      ]);
      c.fillRect(0, y0, W, gapBottom);
    }

    if (gapTop <= 0.5 && gapBottom <= 0.5) {
      c.imageSmoothingQuality = "high";
      c.drawImage(img, bg.x, bg.y, bg.w, bg.h);
      return;
    }

    // The picture itself, with its top / bottom edges feathered into the extension.
    const tmp = document.createElement("canvas");
    tmp.width = Math.round(W * this.dpr);
    tmp.height = Math.round(H * this.dpr);
    const t = tmp.getContext("2d");
    if (!t) {
      c.drawImage(img, bg.x, bg.y, bg.w, bg.h);
      return;
    }
    t.scale(this.dpr, this.dpr);
    t.imageSmoothingQuality = "high";
    t.drawImage(img, bg.x, bg.y, bg.w, bg.h);
    t.globalCompositeOperation = "destination-out";
    const fe = bg.h * 0.1;
    if (gapTop > 0.5) {
      t.fillStyle = lin(t, 0, bg.y, 0, bg.y + fe, [
        [0, "rgba(0,0,0,1)"],
        [1, "rgba(0,0,0,0)"],
      ]);
      t.fillRect(0, bg.y, W, fe);
    }
    if (gapBottom > 0.5) {
      const yb = bg.y + bg.h;
      t.fillStyle = lin(t, 0, yb - fe, 0, yb, [
        [0, "rgba(0,0,0,0)"],
        [1, "rgba(0,0,0,1)"],
      ]);
      t.fillRect(0, yb - fe, W, fe);
    }
    c.drawImage(tmp, 0, 0, W, H);
  }

  /** One-pixel-wide cross-section of the dough, rendered with exactly the same shading. */
  private buildStrip(L: Layout): void {
    const h = Math.max(4, Math.ceil(L.r * 2 * this.dpr));
    const s = document.createElement("canvas");
    s.width = 8;
    s.height = h;
    const sc = s.getContext("2d");
    if (!sc) return;
    sc.scale(this.dpr, this.dpr);
    // A very long cylinder cropped to its middle: no end shading, just the side profile.
    this.doughShape(sc, -400, 400, L.r, L.r);
    this.strip = s;
  }

  draw(e: Engine): void {
    const L = this.L;
    const cache = this.cache;
    if (!L || !cache) return;
    const c = this.ctx;
    c.setTransform(this.dpr, 0, 0, this.dpr, 0, 0);
    c.fillStyle = "#070d1c";
    c.fillRect(0, 0, L.W, L.H);

    c.save();
    if (e.shake > 0.01) {
      c.translate(Math.sin(e.T * 95) * e.shake * 3.2, Math.cos(e.T * 83) * e.shake * 2.6);
    }
    c.drawImage(cache, 0, 0, L.W, L.H);

    this.belt(c, e, L);
    this.gaugeZones(c, e, L);
    this.dynamicShadows(c, e, L);
    this.continuousDough(c, e, L);
    this.gaugeLines(c, e, L);
    this.segments(c, e, L);
    this.cutMark(c, L);
    this.press(c, e, L);
    this.particles(c, e, L);
    this.feedbackLabel(c, e, L);
    c.restore();
  }

  // ---------------------------------------------------------------------------------------
  private belt(c: Ctx, e: Engine, L: Layout): void {
    const { u, x0, beltY, W } = L;
    const top = beltY + BELT.top * u;
    const bot = beltY + BELT.bot * u;
    const sp = 0.42 * u;
    const off = (e.E * u) % sp;
    c.save();
    c.beginPath();
    c.rect(x0 + 0.3 * u, top, W, bot - top);
    c.clip();
    c.strokeStyle = "rgba(190,210,255,0.13)";
    c.lineWidth = 1.6;
    c.beginPath();
    for (let x = x0 + 0.3 * u - sp + off; x < W + sp; x += sp) {
      c.moveTo(x + 0.1 * u, top);
      c.lineTo(x - 0.1 * u, bot);
    }
    c.stroke();
    c.restore();
  }

  private gaugeZones(c: Ctx, e: Engine, L: Layout): void {
    const { u, x0, beltY } = L;
    const top = beltY + BELT.top * u;
    const bot = beltY + BELT.bot * u;
    const p = e.params;
    const zones: Array<[number, number, string, string]> = [
      [SHORT_LEN, p.tolShort, "74,163,255", "کوتاه"],
      [LONG_LEN, p.tolLong, "255,196,40", "بلند"],
    ];
    c.font = `800 ${Math.max(9, Math.round(0.15 * u))}px ${FONT}`;
    c.textAlign = "center";
    c.textBaseline = "middle";
    c.direction = "rtl";
    for (const [len, tol, col, label] of zones) {
      const xa = x0 + (PRESS_X + len - tol) * u;
      const xb = x0 + (PRESS_X + len + tol) * u;
      const xc = (xa + xb) / 2;
      c.fillStyle = `rgba(${col},0.22)`;
      c.fillRect(xa, top, xb - xa, bot - top);
      c.fillStyle = `rgba(${col},0.75)`;
      c.fillRect(xa - 0.75, top, 1.5, bot - top);
      c.fillRect(xb - 0.75, top, 1.5, bot - top);
      // label pill on the conveyor's front panel
      const ly = beltY + BELT.panel * u;
      const pw = 0.7 * u;
      const ph = 0.22 * u;
      rrPath(c, xc - pw / 2, ly - ph / 2, pw, ph, ph / 2);
      c.fillStyle = "rgba(6,14,36,0.82)";
      c.fill();
      c.lineWidth = 1.2;
      c.strokeStyle = `rgba(${col},0.9)`;
      c.stroke();
      c.fillStyle = `rgb(${col})`;
      c.fillText(label, xc, ly + 0.01 * u);
    }
  }

  private dynamicShadows(c: Ctx, e: Engine, L: Layout): void {
    const { u, x0, beltY } = L;
    const frontX = x0 + (PRESS_X + Math.max(0, e.lead)) * u;
    this.shadow(c, x0 + this.bendLen(L) * 0.6, frontX, L);
    for (const s of e.segs) {
      if (!s.active) continue;
      const xa = x0 + e.segX(s) * u;
      this.shadow(c, xa, xa + s.len * u, L);
      // result glow on the belt
      if (s.state > 0 && s.age > 0 && s.age < 1.6) {
        const a = Math.min(1, (1.6 - s.age) / 0.8) * 0.5;
        const col = s.state === 1 ? "74,222,128" : "248,113,113";
        const cx = xa + (s.len * u) / 2;
        c.save();
        c.translate(cx, beltY + 0.1 * u);
        c.scale(1, 0.22);
        glow(c, 0, 0, (s.len * u) / 2 + 0.5 * u, `rgba(${col},1)`, a);
        c.restore();
      }
    }
  }

  private shadow(c: Ctx, xa: number, xb: number, L: Layout): void {
    const { u, beltY } = L;
    if (xb - xa < 1) return;
    c.fillStyle = lin(c, 0, beltY - 0.02 * u, 0, beltY + 0.2 * u, [
      [0, "rgba(5,8,20,0.6)"],
      [1, "rgba(5,8,20,0)"],
    ]);
    c.fillRect(xa - 0.02 * u, beltY - 0.02 * u, xb - xa + 0.1 * u, 0.22 * u);
  }

  /** One dough cylinder (diameter == nozzle opening). */
  private dough(c: Ctx, xa: number, xb: number, L: Layout): void {
    this.doughShape(c, xa, xb, L.yc, L.r);
  }

  /** A glossy dough cylinder lying horizontally, centre line at `yc`, radius `r`. */
  private doughShape(c: Ctx, xa: number, xb: number, yc: number, r: number): void {
    const w = xb - xa;
    if (w < 2) return;
    const rad = Math.min(r * 0.45, w / 2);
    const top = yc - r;
    const h = 2 * r;
    rrPath(c, xa, top, w, h, rad);
    c.fillStyle = lin(c, 0, top, 0, top + h, DOUGH_STOPS);
    c.fill();
    c.save();
    c.clip();
    // slightly darker rounded ends
    const f = Math.min(0.5, (rad * 1.3) / w);
    c.fillStyle = lin(c, xa, 0, xb, 0, [
      [0, "rgba(120,70,10,0.2)"],
      [f, "rgba(120,70,10,0)"],
      [1 - f, "rgba(120,70,10,0)"],
      [1, "rgba(120,70,10,0.2)"],
    ]);
    c.fillRect(xa, top, w, h);
    // glossy specular streaks
    c.fillStyle = lin(c, xa, 0, xb, 0, [
      [0, "rgba(255,255,255,0)"],
      [0.07, "rgba(255,255,255,0.7)"],
      [0.93, "rgba(255,255,255,0.7)"],
      [1, "rgba(255,255,255,0)"],
    ]);
    rrPath(c, xa + rad * 0.5, top + h * 0.12, Math.max(0, w - rad), h * 0.13, h * 0.065);
    c.fill();
    c.fillStyle = "rgba(255,255,255,0.16)";
    rrPath(c, xa + rad, top + h * 0.31, Math.max(0, w - 2 * rad), h * 0.055, h * 0.03);
    c.fill();
    // warm bounce light from the belt
    c.fillStyle = lin(c, 0, top + h * 0.78, 0, top + h, [
      [0, "rgba(255,220,150,0)"],
      [1, "rgba(255,215,140,0.38)"],
    ]);
    c.fillRect(xa, top + h * 0.78, w, h * 0.22);
    c.restore();
    rrPath(c, xa, top, w, h, rad);
    c.lineWidth = 1.2;
    c.strokeStyle = "rgba(140,92,26,0.5)";
    c.stroke();
  }

  /** Horizontal length of the bend where the dough drops from the nozzle onto the belt. */
  private bendLen(L: Layout): number {
    const drop = L.yc - L.mouthY;
    return Math.max(0.9 * L.u, 3 * Math.abs(drop));
  }

  /**
   * The continuous extrusion: leaves the nozzle opening horizontally (same diameter as the
   * opening), eases down onto the conveyor and then runs straight to the cutting position.
   */
  /**
   * Geometry of the nozzle opening (the dark circle in the background): the parametric angles of
   * its highest / lowest points, those points, and its leftmost x.
   */
  private mouth(L: Layout) {
    const { x0: cx, mouthY: cy, mouthA: a, mouthB: b, mouthTilt: th } = L;
    const ct = Math.cos(th);
    const st = Math.sin(th);
    const at = (t: number): [number, number] => [
      cx + a * Math.cos(t) * ct - b * Math.sin(t) * st,
      cy + a * Math.cos(t) * st + b * Math.sin(t) * ct,
    ];
    const tBot = Math.atan2(b * ct, a * st); // lowest point on screen (y grows downwards)
    const tTop = tBot - Math.PI;
    return { tTop, tBot, top: at(tTop), bot: at(tBot), left: cx - Math.hypot(a * ct, b * st) };
  }

  /** Path of the opening's left arc, from its highest point round the left side to its lowest. */
  private mouthArc(c: Ctx, L: Layout, m: ReturnType<Renderer["mouth"]>): void {
    c.ellipse(L.x0, L.mouthY, L.mouthA, L.mouthB, L.mouthTilt, m.tTop, m.tBot - 2 * Math.PI, true);
  }

  private continuousDough(c: Ctx, e: Engine, L: Layout): void {
    const { u, x0, r, yc, mouthY, W, H } = L;
    const frontX = x0 + (PRESS_X + Math.max(0, e.lead)) * u;
    const drop = yc - mouthY;
    const lb = this.bendLen(L);
    const seam = x0 + lb;
    const m = this.mouth(L);

    // Visible outline: the dough fills the round opening, so its start is the opening's left arc;
    // to the right of the chord between the arc's ends the extrusion is unrestricted.
    const [tx, ty] = m.top;
    const [bx, by] = m.bot;
    const k = (bx - tx) / (by - ty);
    c.save();
    c.beginPath();
    c.moveTo(tx, ty);
    this.mouthArc(c, L, m);
    c.lineTo(bx + k * (H + 10 - by), H + 10);
    c.lineTo(W + 10, H + 10);
    c.lineTo(W + 10, -10);
    c.lineTo(tx + k * (-10 - ty), -10);
    c.closePath();
    c.clip();

    // straight part (belt level) – same renderer as the cut pieces
    c.save();
    c.beginPath();
    c.rect(seam - 0.5, 0, W, H);
    c.clip();
    this.dough(c, seam - 3 * r, frontX, L);
    c.restore();

    // bent part: vertical slices of the pre-rendered cross-section follow the centre line
    const strip = this.strip;
    const step = 2;
    if (strip) {
      c.imageSmoothingEnabled = true;
      // Inside the opening (left of its centre) the dough is level with the pipe axis.
      for (let x = Math.floor(m.left) - step; x < seam; x += step) {
        const t = Math.max(0, (x + step / 2 - x0) / lb);
        const t2 = t * t;
        const s = t2 * t * (t * (6 * t - 15) + 10);
        const ds = (30 * t2 * (1 - t) * (1 - t) * drop) / lb;
        const f = Math.sqrt(1 + ds * ds);
        const cy = mouthY + drop * s;
        c.drawImage(strip, 3, 0, 1, strip.height, x, cy - r * f, step + 0.6, 2 * r * f);
      }
    }

    // ambient occlusion where the dough leaves the rim
    c.fillStyle = lin(c, m.left, 0, x0 + 0.25 * u, 0, [
      [0, "rgba(40,20,0,0.5)"],
      [1, "rgba(40,20,0,0)"],
    ]);
    c.fillRect(m.left - 2, mouthY - r - 2, x0 + 0.25 * u - m.left + 2, 2 * r + 4);
    // crisp contact line along the rim (only its inner half survives the clip)
    c.beginPath();
    this.mouthArc(c, L, m);
    c.lineWidth = Math.max(1.5, 0.035 * u);
    c.strokeStyle = "rgba(35,18,4,0.6)";
    c.stroke();
    c.restore();
  }

  private gaugeLines(c: Ctx, e: Engine, L: Layout): void {
    const { u, x0, r, yc, beltY } = L;
    void e;
    c.save();
    c.setLineDash([Math.max(3, 0.05 * u), Math.max(3, 0.05 * u)]);
    c.lineWidth = 1.5;
    for (const [len, col] of [
      [SHORT_LEN, "170,215,255"],
      [LONG_LEN, "255,225,130"],
    ] as Array<[number, string]>) {
      const x = x0 + (PRESS_X + len) * u;
      c.strokeStyle = `rgba(${col},0.75)`;
      c.beginPath();
      c.moveTo(x, yc - r - 0.04 * u);
      c.lineTo(x, beltY + BELT.bot * u);
      c.stroke();
    }
    c.restore();
  }

  private segments(c: Ctx, e: Engine, L: Layout): void {
    const { u, x0, r, yc, W } = L;
    for (const s of e.segs) {
      if (!s.active) continue;
      const xa = x0 + e.segX(s) * u;
      const xb = xa + s.len * u;
      if (xb < x0 || xa > W) continue;
      const hop = s.age > 0 && s.age < 0.22 ? -0.045 * u * Math.sin((Math.PI * s.age) / 0.22) : 0;
      c.save();
      c.translate(0, hop);
      this.dough(c, xa, xb, L);
      c.restore();
      if (s.state > 0 && s.age > 0 && s.age < 1.9) this.badge(c, s, xa + (xb - xa) / 2, yc - r - 0.3 * u, u);
    }
  }

  private badge(c: Ctx, s: Segment, cx: number, cy: number, u: number): void {
    const pop = Math.min(1, s.age / 0.2);
    const k = 1 + 0.35 * Math.sin(Math.PI * Math.min(1, pop)) * (1 - pop * 0.5);
    const fade = s.age > 1.5 ? Math.max(0, 1 - (s.age - 1.5) / 0.4) : 1;
    const R = 0.15 * u * k * (0.4 + 0.6 * pop);
    const ok = s.state === 1;
    c.save();
    c.globalAlpha = fade;
    const g = c.createRadialGradient(cx - R * 0.3, cy - R * 0.4, R * 0.1, cx, cy, R);
    if (ok) {
      g.addColorStop(0, "#9bf5b6");
      g.addColorStop(1, "#16a34a");
    } else {
      g.addColorStop(0, "#ffb0b0");
      g.addColorStop(1, "#dc2626");
    }
    c.beginPath();
    c.arc(cx, cy, R, 0, Math.PI * 2);
    c.fillStyle = g;
    c.fill();
    c.lineWidth = Math.max(1.5, R * 0.16);
    c.strokeStyle = "rgba(255,255,255,0.9)";
    c.stroke();
    c.lineCap = "round";
    c.lineJoin = "round";
    c.lineWidth = Math.max(2, R * 0.28);
    c.strokeStyle = "#fff";
    c.beginPath();
    if (ok) {
      c.moveTo(cx - R * 0.42, cy + R * 0.02);
      c.lineTo(cx - R * 0.1, cy + R * 0.36);
      c.lineTo(cx + R * 0.46, cy - R * 0.32);
    } else {
      c.moveTo(cx - R * 0.34, cy - R * 0.34);
      c.lineTo(cx + R * 0.34, cy + R * 0.34);
      c.moveTo(cx + R * 0.34, cy - R * 0.34);
      c.lineTo(cx - R * 0.34, cy + R * 0.34);
    }
    c.stroke();
    c.restore();
  }

  /** Floating result text above the blade for the most recent cut. */
  private feedbackLabel(c: Ctx, e: Engine, L: Layout): void {
    let best: Segment | null = null;
    for (const s of e.segs) {
      if (!s.active || s.state === 0 || !s.label) continue;
      if (!best || s.cutE > best.cutE) best = s;
    }
    if (!best || best.age < 0 || best.age > 1.5) return;
    const { u, px, yc, r } = L;
    const age = best.age;
    const a = age > 1.1 ? Math.max(0, 1 - (age - 1.1) / 0.4) : 1;
    const pop = Math.min(1, age / 0.16);
    const scale = 0.7 + 0.3 * pop + 0.12 * Math.sin(Math.PI * pop);
    const y = yc - r - 0.95 * u - age * 0.22 * u;
    const x = Math.min(L.W - 0.9 * u, px + 1.05 * u);
    const ok = best.state === 1;
    c.save();
    c.globalAlpha = a;
    c.translate(x, y);
    c.scale(scale, scale);
    c.font = `800 ${Math.max(13, Math.round(0.27 * u))}px ${FONT}`;
    c.textAlign = "center";
    c.textBaseline = "middle";
    c.direction = "rtl";
    c.lineJoin = "round";
    c.lineWidth = Math.max(4, 0.07 * u);
    c.strokeStyle = "rgba(5,10,26,0.92)";
    c.strokeText(best.label, 0, 0);
    c.fillStyle = ok ? (best.perfect ? "#ffe066" : "#86efac") : "#fca5a5";
    c.fillText(best.label, 0, 0);
    c.restore();
  }

  private cutMark(c: Ctx, L: Layout): void {
    const { u, px, beltY } = L;
    const top = beltY + BELT.top * u;
    const bot = beltY + BELT.bot * u;
    c.save();
    c.strokeStyle = "rgba(255,90,80,0.85)";
    c.lineWidth = Math.max(1.5, 0.028 * u);
    c.setLineDash([Math.max(3, 0.06 * u), Math.max(2, 0.04 * u)]);
    c.beginPath();
    c.moveTo(px, top);
    c.lineTo(px, bot);
    c.stroke();
    c.setLineDash([]);
    c.fillStyle = "#ff5a4f";
    const s = 0.07 * u;
    c.beginPath();
    c.moveTo(px - s, bot + 0.1 * u + s * 1.4);
    c.lineTo(px + s, bot + 0.1 * u + s * 1.4);
    c.lineTo(px, bot + 0.1 * u);
    c.closePath();
    c.fill();
    c.restore();
  }

  /**
   * The press: housing (static), hanging hoses (stretch to follow the arm and sway afterwards),
   * telescoping rod and the moving carriage with the blade. All drawn from the supplied artwork.
   */
  private press(c: Ctx, e: Engine, L: Layout): void {
    const { u, px, beltY, yc, r } = L;
    const o = e.pressOffset();
    const restTip = yc - r - PRESS_REST_GAP_U * u;
    const stroke = beltY - restTip;
    const d = o * stroke;
    const S = this.sprites;

    if (!S) {
      // Minimal placeholder until the artwork has decoded (a frame or two).
      const tip = restTip + d;
      c.fillStyle = "#cfd6e6";
      c.fillRect(px - 0.02 * u, tip - 0.6 * u, 0.04 * u, 0.6 * u);
      return;
    }

    const { k } = S;
    const A = ARM;
    const ox = px - A.tip.x * k; // screen x of sheet x = 0
    const oy = restTip - A.tip.y * k; // screen y of sheet y = 0 (carriage at rest)
    const dpr = this.dpr;
    const sw = (cv: HTMLCanvasElement) => cv.width / dpr;
    const sh = (cv: HTMLCanvasElement) => cv.height / dpr;

    // hose sway: a damped swing after every stroke + a faint tremor while the machine runs
    const t = e.pressT;
    const env = t < 2.5 ? Math.exp(-t / 0.5) : 0;
    const idle = e.machine > 0.3 ? 0.0035 * Math.sin(e.T * 8.5) : 0;
    const thL = 0.045 * env * Math.sin(2 * Math.PI * 3.0 * t) + idle;
    const thR = -0.035 * env * Math.sin(2 * Math.PI * 2.5 * t + 0.6) + idle * 0.7;

    // 1) ceiling column above the housing (portrait: the housing hangs below the screen top)
    if (oy > 0) {
      c.drawImage(S.top, ox, -1, A.w * k, oy + 2);
    }

    // 2) hoses (behind the housing so their hidden tops stay covered)
    this.drawHose(c, S.hoseL, ox + A.hoseL.pivotX * k, oy + A.hoseL.hiddenTop * k, sw(S.hoseL), sh(S.hoseL), d, thL, A.hoseL.pivotX * k);
    this.drawHose(c, S.hoseR, ox + A.hoseR.pivotX * k, oy + A.hoseR.top * k, sw(S.hoseR), sh(S.hoseR), d, thR, (A.hoseR.pivotX - A.hoseR.x0) * k);

    // 3) rod extension: fills the gap between collar and carriage while the arm is down
    if (d > 0.5) {
      c.drawImage(S.rod, ox + A.rod.x0 * k, oy + (A.housingBottom - 2) * k, sw(S.rod), d + 4 * k);
    }

    // 4) housing
    c.drawImage(S.housing, ox, oy, sw(S.housing), sh(S.housing));

    // 5) carriage (rod top + slide block + head + blade)
    c.drawImage(S.carriage, ox + A.carriage.x0 * k, oy + A.carriage.y0 * k + d, sw(S.carriage), sh(S.carriage));

    // impact flash
    if (e.flash > 0.02) {
      c.save();
      c.globalCompositeOperation = "lighter";
      glow(c, px, beltY - 0.02 * u, 0.7 * u, "rgba(255,230,160,1)", 0.75 * e.flash);
      c.restore();
    }
  }

  /** A hose hangs from `(px, py)`; its lower end follows the arm by `d` px and it swings by `theta`. */
  private drawHose(
    c: Ctx,
    sprite: HTMLCanvasElement,
    px: number,
    py: number,
    w: number,
    h: number,
    d: number,
    theta: number,
    pivotLocalX: number,
  ): void {
    c.save();
    c.translate(px, py);
    c.rotate(theta);
    c.scale(1, (h + d) / h);
    c.drawImage(sprite, -pivotLocalX, 0, w, h);
    c.restore();
  }

  private particles(c: Ctx, e: Engine, L: Layout): void {
    const { u, x0, beltY } = L;
    for (const p of e.parts) {
      if (!p.active) continue;
      const t = p.life / p.max;
      const x = x0 + p.x * u;
      const y = beltY + p.y * u;
      if (p.kind === 0) {
        c.save();
        c.globalCompositeOperation = "lighter";
        c.fillStyle = `rgba(255,${180 + Math.round(60 * t)},90,${Math.min(1, t * 1.6)})`;
        const s = Math.max(1.5, p.size * u * 2);
        c.fillRect(x - s / 2, y - s / 2, s, s);
        c.restore();
      } else if (p.kind === 1) {
        c.fillStyle = `rgba(250,228,170,${0.5 * t})`;
        c.beginPath();
        c.arc(x, y, p.size * u * (1.2 + (1 - t) * 1.6), 0, Math.PI * 2);
        c.fill();
      } else {
        c.fillStyle = `rgba(225,236,255,${0.32 * t})`;
        c.beginPath();
        c.arc(x, y, p.size * u * (1 + (1 - t) * 2.2), 0, Math.PI * 2);
        c.fill();
      }
    }
  }
}
