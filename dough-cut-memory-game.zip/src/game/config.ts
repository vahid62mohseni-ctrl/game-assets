/**
 * Core tuning values and difficulty progression for Dough Cut.
 * All lengths are in "world units" (1 unit ≈ the length of a long-ish dough bite).
 */

export type Kind = 0 | 1; // 0 = short, 1 = long
export const SHORT: Kind = 0;
export const LONG: Kind = 1;

/**
 * Diameter of the dough == inner diameter of the nozzle opening (≈ 0.717 world units). The
 * layout derives the exact on-screen value from the opening measured on the background image.
 */
export const DOUGH_DIAMETER = 0.717;
export const SHORT_LEN = 0.6;
export const LONG_LEN = 1.5;

/**
 * Distance (world units) from the nozzle opening to the cutting blade. 3.15 puts the blade at
 * ~56% of the background's width (the free slot above the conveyor), clear of the nozzle.
 */
export const PRESS_X = 3.15;
/** If the leading dough grows past this length the machine auto-cuts (and the cut fails). */
export const OVERFLOW_LEN = 2.1;
/** Ignore cut inputs arriving sooner than this after the previous one (double-tap guard). */
export const MIN_CUT_INTERVAL = 0.12;

/** Cut pieces are carried away by a faster transfer belt (multiple of the dough speed). */
export const SEG_SPEED = 2.2;

export const MAX_LIVES = 3;
export const READY_TIME = 1.2;

export const POINTS = {
  short: 100,
  long: 150,
  perfect: 50,
  sequenceBase: 250,
  sequencePerStage: 50,
  comboStep: 0.25,
  comboMax: 8,
} as const;

export interface StageParams {
  stage: number;
  nMin: number;
  nMax: number;
  speed: number; // dough / conveyor speed in units per second
  tolShort: number;
  tolLong: number;
  pLong: number;
  markov: boolean;
  pSwitch: number;
  /** Sequences completed per stage. */
  memBonus: number;
}

export const SEQUENCES_PER_STAGE = 2;

export function stageFromCompleted(completed: number): number {
  return 1 + Math.floor(completed / SEQUENCES_PER_STAGE);
}

/** Smooth, gradual difficulty curve. Every value changes by a small step per stage. */
export function stageParams(stage: number): StageParams {
  const s = Math.max(1, stage);
  // 3-4, 4-5, 5-6 ... up to 9-10 at stage 8, then one more piece every 3 stages (max 11-12).
  const extra = Math.floor(Math.max(0, s - 8) / 3);
  const nMin = Math.min(Math.min(2 + s, 9) + extra, 11);
  const nMax = Math.min(Math.min(3 + s, 10) + extra, 12);
  return {
    stage: s,
    nMin,
    nMax,
    speed: Math.min(1.5, 1.0 + 0.04 * (s - 1)),
    tolShort: Math.max(0.16, 0.24 - 0.007 * (s - 1)),
    tolLong: Math.max(0.22, 0.34 - 0.01 * (s - 1)),
    pLong: s === 1 ? 0.28 : s === 2 ? 0.42 : 0.5,
    markov: s >= 3,
    pSwitch: Math.min(0.8, 0.45 + 0.05 * (s - 3)),
    memBonus: 1.5 * Math.max(0, 1 - (s - 1) / 6),
  };
}

export function memorizeTime(n: number, p: StageParams): number {
  const t = 2.4 + 0.75 * n + p.memBonus;
  return Math.min(12, Math.max(4, t));
}

export function generateSequence(p: StageParams, rng: () => number = Math.random): Kind[] {
  const n = p.nMin + Math.floor(rng() * (p.nMax - p.nMin + 1));
  const seq: Kind[] = [];
  for (let i = 0; i < n; i++) {
    if (p.markov && i > 0) {
      const prev = seq[i - 1];
      seq.push((rng() < p.pSwitch ? 1 - prev : prev) as Kind);
    } else {
      seq.push(rng() < p.pLong ? LONG : SHORT);
    }
  }
  // Always include both kinds so the memory test is meaningful.
  if (!seq.includes(LONG)) seq[Math.floor(rng() * n)] = LONG;
  if (!seq.includes(SHORT)) seq[Math.floor(rng() * n)] = SHORT;
  // Never produce 3+ identical long pieces in a row on early stages.
  return seq;
}
