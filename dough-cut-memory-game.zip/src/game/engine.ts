import {
  LONG,
  LONG_LEN,
  MAX_LIVES,
  MIN_CUT_INTERVAL,
  OVERFLOW_LEN,
  POINTS,
  PRESS_X,
  READY_TIME,
  SEG_SPEED,
  SHORT,
  SHORT_LEN,
  generateSequence,
  memorizeTime,
  stageFromCompleted,
  stageParams,
  type Kind,
  type StageParams,
} from "./config";
import { loadBest, saveBest } from "./storage";
import type { SoundName } from "./audio";
import { fa } from "../utils/fa";

export type Phase = "MENU" | "MEMORIZE" | "PLAYING" | "CHECKING_SEQUENCE" | "PAUSED" | "GAME_OVER";

export interface CutRecord {
  target: Kind;
  /** 0 = short, 1 = long, 2 = neither */
  produced: 0 | 1 | 2;
  ok: boolean;
  perfect: boolean;
  len: number;
  points: number;
}

export interface Segment {
  active: boolean;
  /** extrusion counter value at the moment this piece was cut off */
  cutE: number;
  len: number;
  /** 0 = scrap / demo, 1 = correct, 2 = wrong */
  state: 0 | 1 | 2;
  perfect: boolean;
  age: number;
  gap: number;
  sweepX: number;
  sweepV: number;
  sweeping: boolean;
  label: string;
}

export interface Particle {
  active: boolean;
  /** world x (units from nozzle exit) */
  x: number;
  /** y in units relative to the belt line (negative = up) */
  y: number;
  vx: number;
  vy: number;
  life: number;
  max: number;
  size: number;
  kind: 0 | 1 | 2; // spark, dust, steam
}

export interface Snapshot {
  phase: Phase;
  pausedFrom: Phase | null;
  stage: number;
  score: number;
  best: number;
  bestAtStart: number;
  newRecord: boolean;
  lives: number;
  combo: number;
  multiplier: number;
  completed: number;
  seq: Kind[];
  cuts: CutRecord[];
  cutIdx: number;
  ready: boolean;
  countdown: number;
  retry: boolean;
  stageUp: boolean;
  checkResult: "ok" | "fail" | null;
  message: string;
  msgKind: "info" | "good" | "bad";
  failReason: string;
  runId: number;
  tolShort: number;
  tolLong: number;
}

const SEG_POOL = 40;
const PART_POOL = 56;
export const KERF = 0.04;
export const IMPACT_T = 0.05;
const DEMO_PATTERN = [SHORT_LEN, LONG_LEN, SHORT_LEN, SHORT_LEN, LONG_LEN, SHORT_LEN, LONG_LEN];

export class Engine {
  // ---- simulation state (read by the renderer) -----------------------------------------
  E = 0;
  lastCutE = 0;
  machine = 0;
  speed = 1;
  T = 0;
  pressT = 99;
  shake = 0;
  flash = 0;
  viewRight = 8;
  memLeft = 0;
  memTotal = 1;
  readonly segs: Segment[] = [];
  readonly parts: Particle[] = [];
  params: StageParams = stageParams(1);

  onSound: ((name: SoundName) => void) | null = null;

  // ---- private state --------------------------------------------------------------------
  private _phase: Phase = "MENU";
  private pausedFrom: Phase | null = null;
  private machineTarget = 1;
  private stage = 1;
  private score = 0;
  private best = 0;
  private bestAtStart = 0;
  private newRecord = false;
  private lives = MAX_LIVES;
  private combo = 0;
  private completed = 0;
  private seq: Kind[] = [];
  private cuts: CutRecord[] = [];
  private cutIdx = 0;
  private ready = false;
  private readyLeft = 0;
  private countdown = 0;
  private retry = false;
  private stageUp = false;
  private checkResult: "ok" | "fail" | null = null;
  private checkLeft = 0;
  private message = "";
  private msgKind: "info" | "good" | "bad" = "info";
  private failReason = "";
  private runId = 0;
  private lastCutT = -10;
  private lastUpdateAt = 0;
  private segCursor = 0;
  private partCursor = 0;
  private pressArmed = false;
  private pressQuiet = false;
  private demoIdx = 0;

  private listeners = new Set<() => void>();
  private snap: Snapshot;

  constructor() {
    for (let i = 0; i < SEG_POOL; i++) {
      this.segs.push({
        active: false,
        cutE: 0,
        len: 0,
        state: 0,
        perfect: false,
        age: 0,
        gap: 0,
        sweepX: 0,
        sweepV: 0,
        sweeping: false,
        label: "",
      });
    }
    for (let i = 0; i < PART_POOL; i++) {
      this.parts.push({ active: false, x: 0, y: 0, vx: 0, vy: 0, life: 0, max: 1, size: 1, kind: 0 });
    }
    this.best = loadBest();
    this.bestAtStart = this.best;
    this.speed = 0.9;
    this.machine = 0;
    this.snap = this.buildSnapshot();
  }

  // ---- React integration ----------------------------------------------------------------
  subscribe = (fn: () => void): (() => void) => {
    this.listeners.add(fn);
    return () => {
      this.listeners.delete(fn);
    };
  };
  getSnapshot = (): Snapshot => this.snap;

  get phase(): Phase {
    return this._phase;
  }
  /** Length of dough currently extruded past the blade (the piece that would be cut now). */
  get lead(): number {
    return this.E - this.lastCutE;
  }
  /** x (world units) of the tail end of a piece, relative to the nozzle exit. */
  segX(s: Segment): number {
    return PRESS_X + SEG_SPEED * (this.E - s.cutE) + s.gap + s.sweepX;
  }

  private emit(): void {
    this.snap = this.buildSnapshot();
    this.listeners.forEach((l) => l());
  }

  private buildSnapshot(): Snapshot {
    const p = this.params;
    return {
      phase: this._phase,
      pausedFrom: this.pausedFrom,
      stage: this.stage,
      score: this.score,
      best: Math.max(this.best, this.score),
      bestAtStart: this.bestAtStart,
      newRecord: this.newRecord,
      lives: this.lives,
      combo: this.combo,
      multiplier: this.multiplier(),
      completed: this.completed,
      seq: this.seq,
      cuts: this.cuts.slice(),
      cutIdx: this.cutIdx,
      ready: this.ready,
      countdown: this.countdown,
      retry: this.retry,
      stageUp: this.stageUp,
      checkResult: this.checkResult,
      message: this.message,
      msgKind: this.msgKind,
      failReason: this.failReason,
      runId: this.runId,
      tolShort: p.tolShort,
      tolLong: p.tolLong,
    };
  }

  private multiplier(): number {
    return 1 + POINTS.comboStep * Math.min(this.combo, POINTS.comboMax);
  }

  private sound(n: SoundName): void {
    try {
      this.onSound?.(n);
    } catch {
      /* audio never blocks the game */
    }
  }

  // ---- public commands ------------------------------------------------------------------
  /** Start a brand-new run (valid from MENU, PAUSED and GAME_OVER). */
  startRun(): void {
    if (this._phase !== "MENU" && this._phase !== "GAME_OVER" && this._phase !== "PAUSED") return;
    this.runId++;
    this.score = 0;
    this.completed = 0;
    this.stage = 1;
    this.lives = MAX_LIVES;
    this.combo = 0;
    this.newRecord = false;
    this.bestAtStart = this.best;
    this.retry = false;
    this.stageUp = false;
    this.pausedFrom = null;
    this.failReason = "";
    this.params = stageParams(1);
    this.seq = generateSequence(this.params);
    this.beginMemorize();
  }

  restart(): void {
    this.startRun();
  }

  toMenu(): void {
    if (this._phase !== "PAUSED" && this._phase !== "GAME_OVER") return;
    this._phase = "MENU";
    this.pausedFrom = null;
    this.ready = false;
    this.countdown = 0;
    this.checkResult = null;
    this.cuts = [];
    this.cutIdx = 0;
    this.seq = [];
    this.message = "";
    this.speed = 0.9;
    this.machineTarget = 1;
    this.lastCutT = this.T;
    this.emit();
  }

  pause(): void {
    const p = this._phase;
    if (p !== "MEMORIZE" && p !== "PLAYING" && p !== "CHECKING_SEQUENCE") return;
    this.pausedFrom = p;
    this._phase = "PAUSED";
    this.emit();
  }

  resume(): void {
    if (this._phase !== "PAUSED" || !this.pausedFrom) return;
    this._phase = this.pausedFrom;
    this.pausedFrom = null;
    this.lastUpdateAt = performance.now();
    this.emit();
  }

  /** The player pressed the cutting button. Returns true if a cut was registered. */
  cut(): boolean {
    if (this._phase !== "PLAYING") return false;
    if (this.T - this.lastCutT < MIN_CUT_INTERVAL) return false;
    this.performCut(false);
    return true;
  }

  // ---- main loop ------------------------------------------------------------------------
  update(dtRaw: number): void {
    const now = performance.now();
    if (this._phase === "PAUSED") {
      this.lastUpdateAt = now;
      return;
    }
    const dt = Math.min(0.05, Math.max(0, dtRaw));
    this.T += dt;

    switch (this._phase) {
      case "MENU":
        this.updateMenu(dt);
        break;
      case "MEMORIZE":
        this.updateMemorize(dt);
        break;
      case "PLAYING":
        this.updatePlaying(dt);
        break;
      case "CHECKING_SEQUENCE":
        this.updateChecking(dt);
        break;
      case "GAME_OVER":
        this.stepWorld(dt);
        break;
    }
    this.stepSegments(dt);
    this.stepVisuals(dt);
    this.lastUpdateAt = now;
  }

  private stepWorld(dt: number): void {
    const diff = this.machineTarget - this.machine;
    const step = (diff > 0 ? 7 : 4) * dt;
    this.machine = Math.abs(diff) <= step ? this.machineTarget : this.machine + Math.sign(diff) * step;
    this.E += this.speed * this.machine * dt;
  }

  private updateMenu(dt: number): void {
    // Attract mode: the machine runs and the press cuts on its own.
    this.machineTarget = 1;
    this.speed = 0.9;
    this.stepWorld(dt);
    const target = DEMO_PATTERN[this.demoIdx % DEMO_PATTERN.length];
    if (this.lead >= target) {
      const len = this.lead;
      this.lastCutE = this.E;
      this.spawnSegment(this.E, len, 0, false, "", false);
      this.triggerPress(true);
      this.demoIdx++;
    }
  }

  private updateMemorize(dt: number): void {
    this.machineTarget = 0;
    this.stepWorld(dt);
    if (this.machine === 0 && this.lead > 0.002) this.trimFront();

    if (!this.ready) {
      this.memLeft -= dt;
      if (this.memLeft <= 0) {
        this.memLeft = 0;
        this.ready = true;
        this.readyLeft = READY_TIME;
        this.countdown = 3;
        this.sound("tick");
        this.emit();
      }
    } else {
      this.readyLeft -= dt;
      const c = Math.max(0, Math.ceil(this.readyLeft / (READY_TIME / 3) - 1e-6));
      if (c !== this.countdown && c > 0) {
        this.countdown = c;
        this.sound("tick");
        this.emit();
      }
      if (this.readyLeft <= 0) this.beginPlaying();
    }
  }

  private updatePlaying(dt: number): void {
    this.machineTarget = 1;
    this.stepWorld(dt);
    if (this.lead >= OVERFLOW_LEN) this.performCut(true);
  }

  private updateChecking(dt: number): void {
    this.machineTarget = 0;
    this.stepWorld(dt);
    this.checkLeft -= dt;
    if (this.checkLeft > 0) return;

    if (this.checkResult === "ok") {
      const prevStage = this.stage;
      this.stage = stageFromCompleted(this.completed);
      this.stageUp = this.stage > prevStage;
      this.params = stageParams(this.stage);
      this.seq = generateSequence(this.params);
      this.retry = false;
      this.beginMemorize();
    } else if (this.lives <= 0) {
      this.gameOver();
    } else {
      this.retry = true;
      this.stageUp = false;
      this.beginMemorize();
    }
  }

  // ---- phase transitions ----------------------------------------------------------------
  private beginMemorize(): void {
    this._phase = "MEMORIZE";
    this.cuts = [];
    this.cutIdx = 0;
    this.ready = false;
    this.countdown = 0;
    this.checkResult = null;
    this.params = stageParams(this.stage);
    this.memTotal = memorizeTime(this.seq.length, this.params);
    this.memLeft = this.memTotal;
    this.machineTarget = 0;
    this.message = "";
    this.msgKind = "info";
    // Clear the belt: trim whatever dough is hanging past the blade and sweep everything away.
    this.sweepAll();
    this.trimFront();
    if (this.stageUp) this.sound("stage");
    this.emit();
  }

  private beginPlaying(): void {
    this._phase = "PLAYING";
    this.ready = false;
    this.countdown = 0;
    this.speed = this.params.speed;
    this.machineTarget = 1;
    // Everything that has been extruded so far is already trimmed; start measuring from here.
    this.lastCutE = this.E;
    this.lastCutT = this.T;
    this.sound("go");
    this.emit();
  }

  private enterChecking(result: "ok" | "fail", message: string): void {
    this._phase = "CHECKING_SEQUENCE";
    this.checkResult = result;
    this.checkLeft = result === "ok" ? 1.5 : 1.9;
    this.machineTarget = 0;
    this.message = message;
    this.msgKind = result === "ok" ? "good" : "bad";
    this.emit();
  }

  private gameOver(): void {
    this._phase = "GAME_OVER";
    this.machineTarget = 0;
    this.newRecord = this.score > this.bestAtStart && this.score > 0;
    if (this.score > this.best) {
      this.best = this.score;
      saveBest(this.best);
    }
    this.sound(this.newRecord ? "record" : "gameover");
    this.emit();
  }

  // ---- cutting --------------------------------------------------------------------------
  private performCut(auto: boolean): void {
    // Interpolate the extrusion counter to the exact moment of the button press.
    const frac = auto ? 0 : Math.min(0.05, Math.max(0, (performance.now() - this.lastUpdateAt) / 1000));
    const eff = this.E + this.speed * this.machine * frac;
    const len = Math.max(0, eff - this.lastCutE);
    this.lastCutE = eff;
    this.lastCutT = this.T;

    const target = this.seq[this.cutIdx];
    const p = this.params;
    const errS = Math.abs(len - SHORT_LEN);
    const errL = Math.abs(len - LONG_LEN);
    let produced: 0 | 1 | 2 = 2;
    if (errS <= p.tolShort) produced = SHORT;
    else if (errL <= p.tolLong) produced = LONG;
    const ok = produced === target && !auto;
    const ideal = target === SHORT ? SHORT_LEN : LONG_LEN;
    const tol = target === SHORT ? p.tolShort : p.tolLong;
    const perfect = ok && Math.abs(len - ideal) <= tol * 0.4;

    let points = 0;
    let label = "";
    let reason = "";
    if (ok) {
      const base = target === SHORT ? POINTS.short : POINTS.long;
      points = Math.round((base + (perfect ? POINTS.perfect : 0)) * this.multiplier());
      this.score += points;
      this.updateBest();
      label = `${perfect ? "عالی!" : "درست!"} +${fa(points)}`;
    } else {
      if (auto) {
        reason = "خمیر زیادی بیرون آمد!";
        label = "خیلی بلند!";
      } else if (produced === SHORT && target === LONG) {
        reason = "این قطعه باید بلند می‌بود!";
        label = "باید بلند می‌شد";
      } else if (produced === LONG && target === SHORT) {
        reason = "این قطعه باید کوتاه می‌بود!";
        label = "باید کوتاه می‌شد";
      } else if (len < ideal) {
        reason = "قطعه خیلی کوتاه شد!";
        label = "خیلی کوتاه!";
      } else {
        reason = "قطعه خیلی بلند شد!";
        label = "خیلی بلند!";
      }
    }

    this.cuts.push({ target, produced, ok, perfect, len, points });
    this.cutIdx++;
    this.spawnSegment(eff, len, ok ? 1 : 2, perfect, label, false);
    this.triggerPress(false);
    this.sound(ok ? (perfect ? "perfect" : "correct") : "wrong");

    if (!ok) {
      this.lives = Math.max(0, this.lives - 1);
      this.combo = 0;
      this.failReason = reason;
      this.enterChecking("fail", reason);
    } else if (this.cutIdx >= this.seq.length) {
      const bonus = Math.round(
        (POINTS.sequenceBase + POINTS.sequencePerStage * this.stage) * this.multiplier(),
      );
      this.score += bonus;
      this.combo++;
      this.completed++;
      this.updateBest();
      this.sound("sequence");
      this.enterChecking("ok", `دنباله کامل شد! +${fa(bonus)}`);
    } else {
      this.emit();
    }
  }

  private updateBest(): void {
    if (this.score > this.best) {
      this.best = this.score;
      saveBest(this.best);
    }
  }

  private trimFront(): void {
    const len = this.lead;
    if (len < 0.004) return;
    this.lastCutE = this.E;
    this.spawnSegment(this.E, len, 0, false, "", true);
    this.triggerPress(true);
  }

  private sweepAll(): void {
    for (const s of this.segs) {
      if (s.active && !s.sweeping) {
        s.sweeping = true;
        s.sweepV = 2.5;
      }
    }
  }

  private spawnSegment(
    cutE: number,
    len: number,
    state: 0 | 1 | 2,
    perfect: boolean,
    label: string,
    sweeping: boolean,
  ): void {
    const s = this.segs[this.segCursor++ % SEG_POOL];
    s.active = true;
    s.cutE = cutE;
    s.len = len;
    s.state = state;
    s.perfect = perfect;
    s.age = -IMPACT_T;
    s.gap = 0;
    s.sweepX = 0;
    s.sweepV = sweeping ? 2.5 : 0;
    s.sweeping = sweeping;
    s.label = label;
  }

  private triggerPress(quiet: boolean): void {
    // If the press is mid-stroke, continue from its current position instead of snapping.
    const o = this.pressOffset();
    this.pressT = o > 0 && o < 1 ? 0.055 * Math.sqrt(o) : 0;
    this.pressArmed = this.pressT < IMPACT_T;
    this.pressQuiet = quiet;
    this.sound("press");
    if (!quiet) this.sound("cut");
  }

  /** 0 = blade fully raised, 1 = fully lowered. */
  pressOffset(): number {
    const t = this.pressT;
    if (t < 0.055) {
      const k = t / 0.055;
      return k * k;
    }
    if (t < 0.095) return 1;
    if (t < 0.3) {
      const k = (t - 0.095) / 0.205;
      return 1 - (1 - Math.pow(1 - k, 3));
    }
    return 0;
  }

  // ---- visuals --------------------------------------------------------------------------
  private stepSegments(dt: number): void {
    const limit = this.viewRight;
    for (const s of this.segs) {
      if (!s.active) continue;
      s.age += dt;
      const k = Math.min(1, Math.max(0, s.age / 0.18));
      s.gap = KERF * (1 - Math.pow(1 - k, 3));
      if (s.sweeping) {
        s.sweepV = Math.min(16, s.sweepV + 26 * dt);
        s.sweepX += s.sweepV * dt;
      }
      if (this.segX(s) > limit) s.active = false;
    }
  }

  private stepVisuals(dt: number): void {
    if (this.pressT < 99) this.pressT += dt;
    if (this.pressArmed && this.pressT >= IMPACT_T) {
      this.pressArmed = false;
      this.impact(this.pressQuiet);
    }
    this.shake = Math.max(0, this.shake - dt * 6);
    this.flash = Math.max(0, this.flash - dt * 7);

    for (const p of this.parts) {
      if (!p.active) continue;
      p.life -= dt;
      if (p.life <= 0) {
        p.active = false;
        continue;
      }
      if (p.kind === 0) p.vy += 6 * dt;
      p.x += p.vx * dt;
      p.y += p.vy * dt;
      if (p.kind !== 0) {
        p.vx *= 0.96;
        p.vy *= 0.97;
      }
    }
  }

  private impact(quiet: boolean): void {
    this.shake = quiet ? 0.35 : 1;
    this.flash = quiet ? 0.3 : 1;
    const n = quiet ? 3 : 8;
    for (let i = 0; i < n; i++) this.spawnPart(0);
    for (let i = 0; i < (quiet ? 2 : 4); i++) this.spawnPart(1);
    for (let i = 0; i < 3; i++) this.spawnPart(2);
  }

  private spawnPart(kind: 0 | 1 | 2): void {
    const p = this.parts[this.partCursor++ % PART_POOL];
    const r = Math.random;
    p.active = true;
    p.kind = kind;
    if (kind === 0) {
      p.x = PRESS_X + (r() - 0.5) * 0.08;
      p.y = 0.02;
      p.vx = (r() - 0.5) * 3.4;
      p.vy = -0.6 - r() * 2.2;
      p.max = p.life = 0.3 + r() * 0.3;
      p.size = 0.012 + r() * 0.012;
    } else if (kind === 1) {
      p.x = PRESS_X + (r() - 0.5) * 0.4;
      p.y = -0.04;
      p.vx = (r() - 0.5) * 0.9;
      p.vy = -0.25 - r() * 0.5;
      p.max = p.life = 0.5 + r() * 0.35;
      p.size = 0.03 + r() * 0.03;
    } else {
      p.x = PRESS_X + (r() > 0.5 ? 0.36 : -0.36) + (r() - 0.5) * 0.1;
      p.y = -1.85;
      p.vx = (r() - 0.5) * 0.5;
      p.vy = -0.5 - r() * 0.5;
      p.max = p.life = 0.55 + r() * 0.4;
      p.size = 0.05 + r() * 0.04;
    }
  }
}
