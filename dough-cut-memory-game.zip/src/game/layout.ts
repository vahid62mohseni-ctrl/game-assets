import { OVERFLOW_LEN, PRESS_X } from "./config";

/**
 * Measurements taken from the factory background image (factory-bg.jpg).
 * Everything is expressed as a fraction of the image so the file can be re-exported at any
 * resolution without touching the layout.
 */
export const BG = {
  /** width / height of the image */
  aspect: 2048 / 1357,
  /**
   * Rim of the nozzle opening: an ellipse fitted (1.2 px RMS on the 2560×1696 original) to the
   * dark circle inside the pipe. X is a fraction of the image width; Y and both semi-axes are
   * fractions of the image height. `mouthA` runs across the (foreshortened) opening, `mouthB`
   * along its height; `mouthTilt` is the ellipse rotation in radians (clockwise on screen).
   */
  mouthX: 0.20962,
  mouthY: 0.52405,
  mouthA: 0.0185,
  mouthB: 0.05973,
  mouthTilt: 0.0456,
  /** line where the dough touches the conveyor (fraction of image height) */
  belt: 0.619,
  /**
   * One world unit in image-height units. Fixed on its own (not derived from the dough size) so
   * the belt, gauge marks and press stay exactly where they are.
   */
  unit: (2 * 0.0466) / 0.56,
} as const;

/** Vertical half-extent of the opening ellipse = dough radius (image-height units). */
export const MOUTH_R = Math.hypot(BG.mouthA * Math.sin(BG.mouthTilt), BG.mouthB * Math.cos(BG.mouthTilt));

/** Conveyor geometry relative to the dough contact line, in world units (u). */
export const BELT = {
  /** back rail of the belt surface */
  top: -0.27,
  /** front rail of the belt surface */
  bot: 0.19,
  /** centre of the front panel (below the belt) */
  panel: 0.43,
} as const;

/**
 * Screen layout of the production line. Shared by the canvas renderer and the HTML overlay
 * so that both agree on where the belt, nozzle and press are.
 */
export interface Layout {
  W: number;
  H: number;
  /** pixels per world unit */
  u: number;
  /** screen x of the nozzle opening centre (world x = 0) */
  x0: number;
  /** screen y of the belt contact line (bottom of the dough) */
  beltY: number;
  /** dough radius in px (== nozzle opening radius) */
  r: number;
  /** dough centre y when lying on the belt */
  yc: number;
  /** screen y of the nozzle opening centre (dough leaves the pipe here) */
  mouthY: number;
  /** semi-axes (px) and rotation (rad) of the opening ellipse; its centre is (x0, mouthY) */
  mouthA: number;
  mouthB: number;
  mouthTilt: number;
  /** screen x of the cutting blade */
  px: number;
  wide: boolean;
  /** scale factor for the bottom control cluster */
  ctrl: number;
  /** background image placement on screen */
  bg: { x: number; y: number; w: number; h: number };
}

export function computeLayout(W: number, H: number): Layout {
  W = Math.max(280, W);
  H = Math.max(280, H);
  const wide = W / H > 1.15;

  // Everything below is in "image-height" units (image height = 1) until converted by `hs`.
  const uH = BG.unit; // one world unit
  const mouthXh = BG.mouthX * BG.aspect;
  const leftNeed = 0.16; // room for the nozzle flange left of the opening
  const rightNeed = (PRESS_X + OVERFLOW_LEN + 0.3) * uH;
  const need = leftNeed + rightNeed;

  // Landscape: the whole picture is visible (cover). Portrait: shrink the picture until the
  // production line (nozzle -> press -> overflow) fits the width; the rest is extended.
  const hsCover = Math.max(W / BG.aspect, H);
  const hsFit = W / need;
  const hs = Math.min(hsCover, hsFit);
  const bw = hs * BG.aspect;

  let ox = W / 2 - hs * (mouthXh - leftNeed + need / 2);
  ox = Math.min(0, Math.max(W - bw, ox));

  const beltFrac = wide ? (H < 560 ? 0.66 : 0.6) : H < 700 ? 0.55 : 0.52;
  let oy = beltFrac * H - BG.belt * hs;
  if (hs >= H) oy = Math.min(0, Math.max(H - hs, oy));

  const u = uH * hs;
  const r = MOUTH_R * hs;
  const x0 = ox + hs * mouthXh;
  const beltY = oy + BG.belt * hs;
  // The press button is a picture with a fixed aspect (638 x 510). Scale it to the largest size
  // that still fits both the screen width and the free space between the conveyor and the bottom.
  const PRESS_W = 238;
  const PRESS_ASPECT = 510 / 638;
  const availH = H - 8 - beltY; // 8px bottom padding
  let ctrl = Math.min(1.1, PRESS_W / PRESS_W);
  ctrl = Math.min(ctrl, W * 0.64 / PRESS_W);
  ctrl = Math.min(ctrl, availH / (PRESS_W * PRESS_ASPECT));
  ctrl = Math.max(0.5, ctrl);

  return {
    W,
    H,
    u,
    x0,
    beltY,
    r,
    yc: beltY - r,
    mouthY: oy + BG.mouthY * hs,
    mouthA: BG.mouthA * hs,
    mouthB: BG.mouthB * hs,
    mouthTilt: BG.mouthTilt,
    px: x0 + PRESS_X * u,
    wide,
    ctrl,
    bg: { x: ox, y: oy, w: bw, h: hs },
  };
}
