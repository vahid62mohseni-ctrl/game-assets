/** Persistent storage (best score + settings). Always safe against blocked localStorage. */

const BEST_KEY = "khamirkat.best.v1";
const SETTINGS_KEY = "khamirkat.settings.v1";

export interface Settings {
  music: boolean;
  sfx: boolean;
  musicVol: number; // 0..1
  sfxVol: number; // 0..1
}

export const DEFAULT_SETTINGS: Settings = {
  music: true,
  sfx: true,
  musicVol: 0.5,
  sfxVol: 0.8,
};

export function loadBest(): number {
  try {
    const v = Number(localStorage.getItem(BEST_KEY));
    return Number.isFinite(v) && v > 0 ? Math.floor(v) : 0;
  } catch {
    return 0;
  }
}

export function saveBest(v: number): void {
  try {
    localStorage.setItem(BEST_KEY, String(Math.floor(v)));
  } catch {
    /* ignore */
  }
}

export function loadSettings(): Settings {
  try {
    const raw = localStorage.getItem(SETTINGS_KEY);
    if (!raw) return { ...DEFAULT_SETTINGS };
    const o = JSON.parse(raw) as Partial<Settings>;
    const clamp = (n: unknown, d: number) =>
      typeof n === "number" && Number.isFinite(n) ? Math.min(1, Math.max(0, n)) : d;
    return {
      music: typeof o.music === "boolean" ? o.music : DEFAULT_SETTINGS.music,
      sfx: typeof o.sfx === "boolean" ? o.sfx : DEFAULT_SETTINGS.sfx,
      musicVol: clamp(o.musicVol, DEFAULT_SETTINGS.musicVol),
      sfxVol: clamp(o.sfxVol, DEFAULT_SETTINGS.sfxVol),
    };
  } catch {
    return { ...DEFAULT_SETTINGS };
  }
}

export function saveSettings(s: Settings): void {
  try {
    localStorage.setItem(SETTINGS_KEY, JSON.stringify(s));
  } catch {
    /* ignore */
  }
}
