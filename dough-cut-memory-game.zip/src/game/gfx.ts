export type Ctx = CanvasRenderingContext2D;

export function rrPath(c: Ctx, x: number, y: number, w: number, h: number, r: number): void {
  const rr = Math.max(0, Math.min(r, w / 2, h / 2));
  c.beginPath();
  c.moveTo(x + rr, y);
  c.arcTo(x + w, y, x + w, y + h, rr);
  c.arcTo(x + w, y + h, x, y + h, rr);
  c.arcTo(x, y + h, x, y, rr);
  c.arcTo(x, y, x + w, y, rr);
  c.closePath();
}

export function lin(
  c: Ctx,
  x0: number,
  y0: number,
  x1: number,
  y1: number,
  stops: ReadonlyArray<readonly [number, string]>,
): CanvasGradient {
  const g = c.createLinearGradient(x0, y0, x1, y1);
  for (const [o, col] of stops) g.addColorStop(o, col);
  return g;
}

/** Soft radial light / glow. */
export function glow(c: Ctx, x: number, y: number, rad: number, color: string, alpha: number): void {
  const g = c.createRadialGradient(x, y, 0, x, y, rad);
  g.addColorStop(0, color);
  g.addColorStop(1, "rgba(0,0,0,0)");
  c.save();
  c.globalAlpha = alpha;
  c.fillStyle = g;
  c.fillRect(x - rad, y - rad, rad * 2, rad * 2);
  c.restore();
}

export function bolt(c: Ctx, x: number, y: number, r: number): void {
  const g = c.createRadialGradient(x - r * 0.35, y - r * 0.35, r * 0.1, x, y, r);
  g.addColorStop(0, "#f2f6ff");
  g.addColorStop(0.5, "#98a6c2");
  g.addColorStop(1, "#47536f");
  c.beginPath();
  c.arc(x, y, r, 0, Math.PI * 2);
  c.fillStyle = g;
  c.fill();
  c.lineWidth = Math.max(0.6, r * 0.28);
  c.strokeStyle = "rgba(10,15,30,0.7)";
  c.stroke();
}

/** Yellow / black hazard stripes in a rectangle. */
export function hazardFill(c: Ctx, x: number, y: number, w: number, h: number, stripe: number): void {
  c.save();
  c.beginPath();
  c.rect(x, y, w, h);
  c.clip();
  c.fillStyle = "#f6b900";
  c.fillRect(x, y, w, h);
  c.fillStyle = "#15171d";
  const step = stripe * 2;
  for (let sx = x - h; sx < x + w + h; sx += step) {
    c.beginPath();
    c.moveTo(sx, y + h);
    c.lineTo(sx + stripe, y + h);
    c.lineTo(sx + stripe + h, y);
    c.lineTo(sx + h, y);
    c.closePath();
    c.fill();
  }
  c.restore();
}

/** Horizontal cylinder (pipe) body with metallic shading. */
export function pipeH(
  c: Ctx,
  xa: number,
  xb: number,
  yc: number,
  R: number,
  stops: ReadonlyArray<readonly [number, string]>,
): void {
  c.fillStyle = lin(c, 0, yc - R, 0, yc + R, stops);
  c.fillRect(xa, yc - R, xb - xa, R * 2);
  // glossy highlight along the top
  const hg = lin(c, 0, yc - R * 0.78, 0, yc - R * 0.35, [
    [0, "rgba(255,255,255,0)"],
    [0.5, "rgba(255,255,255,0.32)"],
    [1, "rgba(255,255,255,0)"],
  ]);
  c.fillStyle = hg;
  c.fillRect(xa, yc - R * 0.78, xb - xa, R * 0.43);
}

/** Vertical cylinder body with metallic shading. */
export function pipeV(
  c: Ctx,
  xc: number,
  ya: number,
  yb: number,
  R: number,
  stops: ReadonlyArray<readonly [number, string]>,
): void {
  c.fillStyle = lin(c, xc - R, 0, xc + R, 0, stops);
  c.fillRect(xc - R, ya, R * 2, yb - ya);
}

export const STEEL: ReadonlyArray<readonly [number, string]> = [
  [0, "#c3cde3"],
  [0.18, "#97a5c3"],
  [0.55, "#5a6988"],
  [0.85, "#37425e"],
  [1, "#262f48"],
];

export const STEEL_V: ReadonlyArray<readonly [number, string]> = [
  [0, "#1f2840"],
  [0.18, "#5d6b8a"],
  [0.42, "#aab6d0"],
  [0.62, "#7b8aa9"],
  [1, "#222b44"],
];
