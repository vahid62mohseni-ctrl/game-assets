const DIGITS = ["۰", "۱", "۲", "۳", "۴", "۵", "۶", "۷", "۸", "۹"];

/** Convert a number / string to Persian digits, with Persian thousands separators. */
export function fa(n: number | string, group = true): string {
  let s = typeof n === "number" ? String(Math.round(n)) : n;
  if (group && /^\d+$/.test(s) && s.length > 3) {
    s = s.replace(/\B(?=(\d{3})+(?!\d))/g, "٬");
  }
  return s.replace(/\d/g, (d) => DIGITS[Number(d)]);
}
