/**
 * Turns the supplied pause-button artwork (pause.png, white background baked in) into a compact
 * transparent sprite used by the HUD pause control.
 *
 *   node scripts/prepare-pause-art.mjs
 *
 * The shape is convex, so a flood fill from the border removes the background without touching
 * the glossy highlights inside the button. The result is downscaled to 256 px.
 */
import assert from "node:assert/strict";
import sharp from "sharp";

const crop = { left: 806, top: 376, width: 946, height: 944 };
const { width, height } = crop;
const source = await sharp("src/assets/pause-original.png")
  .extract(crop)
  .ensureAlpha()
  .raw()
  .toBuffer();
const pixels = width * height;
const outside = new Uint8Array(pixels);
const queue = new Int32Array(pixels);
let head = 0;
let tail = 0;

const dist = (index) => {
  const p = index * 4;
  return Math.abs(source[p] - 250) + Math.abs(source[p + 1] - 249) + Math.abs(source[p + 2] - 245);
};
const visit = (index) => {
  if (outside[index] || dist(index) >= 26) return;
  outside[index] = 1;
  queue[tail++] = index;
};
for (let x = 0; x < width; x++) {
  visit(x);
  visit((height - 1) * width + x);
}
for (let y = 0; y < height; y++) {
  visit(y * width);
  visit(y * width + width - 1);
}
while (head < tail) {
  const index = queue[head++];
  const x = index % width;
  if (x > 0) visit(index - 1);
  if (x < width - 1) visit(index + 1);
  if (index >= width) visit(index - width);
  if (index < pixels - width) visit(index + width);
}

const out = Buffer.from(source);
let kept = 0;
for (let index = 0; index < pixels; index++) {
  const p = index * 4;
  if (outside[index]) {
    out[p + 3] = 0;
    continue;
  }
  const d = dist(index);
  // Soft edge: ramp alpha where the border fill stopped on anti-aliased rim pixels.
  let edge = false;
  const x = index % width;
  const y = (index - x) / width;
  for (let dy = -2; dy <= 2 && !edge; dy++) {
    for (let dx = -2; dx <= 2; dx++) {
      const xx = x + dx;
      const yy = y + dy;
      if (xx >= 0 && yy >= 0 && xx < width && yy < height && outside[yy * width + xx]) {
        edge = true;
        break;
      }
    }
  }
  if (edge && d < 60) out[p + 3] = Math.round(255 * Math.min(1, Math.max(0, (d - 14) / 40)));
  kept++;
}
assert.ok(kept > 300000, "button body must survive keying");
assert.equal(out[(10 * width + 10) * 4 + 3], 0, "corner must be transparent");
assert.equal(out[(Math.floor(height / 2) * width + Math.floor(width / 2)) * 4 + 3], 255, "centre opaque");

await sharp(out, { raw: { width, height, channels: 4 } })
  .resize({ width: 256 })
  .png({ compressionLevel: 9 })
  .toFile("src/assets/pause-button.png");
const meta = await sharp("src/assets/pause-button.png").metadata();
console.log(`wrote src/assets/pause-button.png ${meta.width}x${meta.height}`);
