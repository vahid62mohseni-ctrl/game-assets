/**
 * Builds the "به خاطر بسپار" panel frame from the supplied artwork (remember.png).
 *
 *   node scripts/prepare-remember-art.mjs
 *
 * The artwork is a finished panel on a white background: glowing cyan border, dark navy body and
 * sample content (title, capsules, hint). The game needs only the frame, so this script
 *   1. keys out the white background, turning the soft outer glow into real alpha, and
 *   2. repaints the interior with the panel's own background shading, erasing the sample content.
 * The result is exported as a 9-slice source: corners stay sharp, edges stretch.
 */
import assert from "node:assert/strict";
import sharp from "sharp";

// Panel incl. glow margin, measured on the 2560x1696 original.
const CROP = { left: 51, top: 259, width: 2458, height: 1191 };
// Hard (non-glow) frame rectangle inside that crop.
const FRAME = { x0: 111 - CROP.left, y0: 319 - CROP.top, x1: 2449 - CROP.left, y1: 1390 - CROP.top };
const BG = [250, 249, 245];
/** colour distance that still counts as "white page background / glow" */
const GLOW_MAX = 110;
/** everything further than this from the frame edge is interior and gets repainted */
const RING = 46;

const { data, info } = await sharp("src/assets/remember-original.png")
  .extract(CROP)
  .ensureAlpha()
  .raw()
  .toBuffer({ resolveWithObject: true });
const W = info.width;
const H = info.height;
const N = W * H;

const dist = new Uint16Array(N);
for (let i = 0; i < N; i++) {
  const p = i * 4;
  dist[i] = Math.abs(data[p] - BG[0]) + Math.abs(data[p + 1] - BG[1]) + Math.abs(data[p + 2] - BG[2]);
}

// ---- 1. background + glow: flood fill from the border ---------------------------------------
const outside = new Uint8Array(N);
const queue = new Int32Array(N);
let tail = 0;
const push = (i) => {
  if (!outside[i] && dist[i] < GLOW_MAX) {
    outside[i] = 1;
    queue[tail++] = i;
  }
};
for (let x = 0; x < W; x++) {
  push(x);
  push((H - 1) * W + x);
}
for (let y = 0; y < H; y++) {
  push(y * W);
  push(y * W + W - 1);
}
for (let head = 0; head < tail; head++) {
  const i = queue[head];
  const x = i % W;
  if (x > 0) push(i - 1);
  if (x < W - 1) push(i + 1);
  if (i >= W) push(i - W);
  if (i < N - W) push(i + W);
}

// ---- 2. distance from the frame edge (for the interior mask) --------------------------------
const depth = new Int32Array(N).fill(-1);
let dTail = 0;
const dq = new Int32Array(N);
for (let i = 0; i < N; i++) {
  if (!outside[i]) continue;
  const x = i % W;
  const y = (i - x) / W;
  const nb = [x > 0 ? i - 1 : -1, x < W - 1 ? i + 1 : -1, y > 0 ? i - W : -1, y < H - 1 ? i + W : -1];
  for (const j of nb) {
    if (j >= 0 && !outside[j] && depth[j] < 0) {
      depth[j] = 1;
      dq[dTail++] = j;
    }
  }
}
for (let head = 0; head < dTail; head++) {
  const i = dq[head];
  const x = i % W;
  const y = (i - x) / W;
  const nb = [x > 0 ? i - 1 : -1, x < W - 1 ? i + 1 : -1, y > 0 ? i - W : -1, y < H - 1 ? i + W : -1];
  for (const j of nb) {
    if (j >= 0 && !outside[j] && depth[j] < 0) {
      depth[j] = depth[i] + 1;
      dq[dTail++] = j;
    }
  }
}

// ---- 3. per-row interior background, sampled just inside the ring ---------------------------
const median = (arr) => (arr.length ? arr.sort((a, b) => a - b)[arr.length >> 1] : null);
const sampleSide = (y, fromLeft) => {
  const r = [];
  const g = [];
  const b = [];
  for (let k = 0; k < W; k++) {
    const x = fromLeft ? k : W - 1 - k;
    const i = y * W + x;
    if (outside[i] || depth[i] < RING) continue;
    const p = i * 4;
    r.push(data[p]);
    g.push(data[p + 1]);
    b.push(data[p + 2]);
    if (r.length >= 70) break;
  }
  const m = [median(r), median(g), median(b)];
  return m[0] === null ? null : m;
};
const left = [];
const right = [];
for (let y = 0; y < H; y++) {
  left.push(sampleSide(y, true));
  right.push(sampleSide(y, false));
}
// vertical smoothing so sampling noise does not show up as banding
const smooth = (col) => {
  const out = col.map((v) => (v ? v.slice() : null));
  for (let y = 0; y < H; y++) {
    if (!col[y]) continue;
    const acc = [0, 0, 0];
    let n = 0;
    for (let k = -40; k <= 40; k++) {
      const v = col[y + k];
      if (!v) continue;
      acc[0] += v[0];
      acc[1] += v[1];
      acc[2] += v[2];
      n++;
    }
    out[y] = [acc[0] / n, acc[1] / n, acc[2] / n];
  }
  return out;
};
const L = smooth(left);
const R = smooth(right);

// ---- 4. compose -----------------------------------------------------------------------------
const out = Buffer.from(data);
let repainted = 0;
for (let y = 0; y < H; y++) {
  // horizontal span of the interior on this row (for the left/right interpolation)
  let xa = -1;
  let xb = -1;
  for (let x = 0; x < W; x++) {
    const i = y * W + x;
    if (!outside[i] && depth[i] >= RING) {
      if (xa < 0) xa = x;
      xb = x;
    }
  }
  for (let x = 0; x < W; x++) {
    const i = y * W + x;
    const p = i * 4;
    if (outside[i]) {
      // Un-premultiply the glow from white: a = 1 - min(channel), colour = (c - (1-a)*255)/a.
      // The page white is ~(250,249,245), so a small floor is subtracted first.
      const mn = Math.min(data[p], data[p + 1], data[p + 2]) / 255;
      const a0 = 0.058;
      const a = Math.min(1, Math.max(0, (1 - mn - a0) / (1 - a0)));
      if (a < 0.004) {
        out[p + 3] = 0;
        continue;
      }
      for (let k = 0; k < 3; k++) {
        const v = (data[p + k] / 255 - (1 - a)) / a;
        out[p + k] = Math.round(255 * Math.min(1, Math.max(0, v)));
      }
      out[p + 3] = Math.round(255 * a);
      continue;
    }
    out[p + 3] = 255;
    if (depth[i] < RING || xa < 0 || !L[y] || !R[y]) continue;
    const t = xb > xa ? (x - xa) / (xb - xa) : 0;
    // feather the first few px so the repaint blends into the border's inner glow
    const f = Math.min(1, (depth[i] - RING) / 16);
    for (let k = 0; k < 3; k++) {
      const bgv = L[y][k] + (R[y][k] - L[y][k]) * t;
      out[p + k] = Math.round(data[p + k] * (1 - f) + bgv * f);
    }
    repainted++;
  }
}

const at = (x, y, c) => out[(y * W + x) * 4 + c];
assert.equal(at(2, 2, 3), 0, "corner must be transparent");
assert.equal(at(FRAME.x0 + 400, FRAME.y0 + 400, 3), 255, "interior must be opaque");
assert.ok(repainted > 1_000_000, `interior must be repainted (${repainted})`);
// the repainted interior must be free of the sample content: no bright pixels left
let bright = 0;
for (let y = FRAME.y0 + 120; y < FRAME.y1 - 120; y += 2) {
  for (let x = FRAME.x0 + 180; x < FRAME.x1 - 180; x += 2) {
    const i = (y * W + x) * 4;
    if (0.3 * out[i] + 0.59 * out[i + 1] + 0.11 * out[i + 2] > 95) bright++;
  }
}
assert.equal(bright, 0, `sample content must be gone (${bright} bright px left)`);

const SCALE = 1000 / W;
await sharp(out, { raw: { width: W, height: H, channels: 4 } })
  .resize({ width: 1000 })
  .webp({ quality: 93, alphaQuality: 100, effort: 6 })
  .toFile("src/assets/remember-frame.webp");
const meta = await sharp("src/assets/remember-frame.webp").metadata();
// 9-slice inset: glow margin + corner radius + a little headroom
const slice = Math.round((FRAME.x0 + 120 + 25) * SCALE);
console.log(`wrote src/assets/remember-frame.webp ${meta.width}x${meta.height}`);
console.log(`border-image-slice: ${slice}  (source ${W}x${H}, scale ${SCALE.toFixed(3)})`);
