/**
 * Turns the supplied press artwork (cutpress.png, white background baked in) into a transparent
 * sprite sheet. The renderer slices this sheet into the static housing, the swinging hoses, the
 * telescoping rod and the moving carriage (slide block + blade head + blade).
 *
 *   node scripts/prepare-press-arm.mjs
 *
 * Keying strategy: the background is removed by flood fill from the sheet border plus explicit
 * seeds for the enclosed pockets (between pipes, hoses, rod and block). Solid parts with wide
 * white speculars (rod, head, blade) are protected per row so the fill can never leak into them,
 * and nothing else is ever made transparent, so chrome / glow highlights stay intact.
 */
import assert from "node:assert/strict";
import sharp from "sharp";

// Crop of the original that contains the whole press (original px). Sheet x = original x - 1030.
const SHEET = { left: 1030, top: 0, width: 930, height: 1412 };
const BG = [250, 249, 245];
const NEAR = 36;

// Enclosed background pockets (sheet coordinates), measured on the artwork.
const POCKET_SEEDS = [
  [140, 600], [326, 500], [362, 860], [653, 720], [258, 250], [258, 470], [193, 700], [230, 540],
  [390, 515], [641, 610], [187, 905], [25, 392], [259, 342], [158, 100], [176, 830], [199, 642],
  [161, 900], [192, 347], [191, 317], [160, 134], [177, 761],
];

// Solid parts: for each row, everything between the first and last non-white pixel inside the
// window is the object and must stay opaque (protects the wide blade / rod speculars).
const PROTECT = [
  { y0: 786, y1: 883, x0: 181, x1: 351 }, // chrome rod
  { y0: 884, y1: 935, x0: 194, x1: 351 }, // chrome rod, right of the side bracket
  { y0: 936, y1: 1050, x0: 94, x1: 645 }, // blade head (solid body)
  { y0: 1070, y1: 1406, x0: 185, x1: 335 }, // blade
];

const { data, info } = await sharp("src/assets/cutpress-original.png")
  .extract(SHEET)
  .ensureAlpha()
  .raw()
  .toBuffer({ resolveWithObject: true });
const W = info.width;
const H = info.height;
const N = W * H;

const dist = new Uint16Array(N);
for (let i = 0; i < N; i++) {
  const p = i * 4;
  dist[i] = Math.abs(data[p] - BG[0]) + Math.abs(data[p + 1] - BG[1]) + Math.abs(data[p + 2] - BG[2]);
}
const near = new Uint8Array(N);
for (let i = 0; i < N; i++) near[i] = dist[i] < NEAR ? 1 : 0;

// Protection: clear `near` inside the solid spans.
for (const w of PROTECT) {
  for (let y = w.y0; y <= w.y1; y++) {
    let first = -1;
    let last = -1;
    for (let x = w.x0; x <= w.x1; x++) {
      if (!near[y * W + x]) {
        if (first < 0) first = x;
        last = x;
      }
    }
    if (first >= 0) for (let x = first; x <= last; x++) near[y * W + x] = 0;
  }
}

// Erode by one pixel so 1-2 px highlight lines cannot act as leak paths.
const core = new Uint8Array(N);
for (let y = 1; y < H - 1; y++) {
  for (let x = 1; x < W - 1; x++) {
    const i = y * W + x;
    if (
      near[i] && near[i - 1] && near[i + 1] && near[i - W] && near[i + W] &&
      near[i - W - 1] && near[i - W + 1] && near[i + W - 1] && near[i + W + 1]
    ) core[i] = 1;
  }
}
for (let x = 0; x < W; x++) { if (near[x]) core[x] = 1; if (near[(H - 1) * W + x]) core[(H - 1) * W + x] = 1; }
for (let y = 0; y < H; y++) { if (near[y * W]) core[y * W] = 1; if (near[y * W + W - 1]) core[y * W + W - 1] = 1; }

const keyed = new Uint8Array(N);
const queue = new Int32Array(N);
let tail = 0;
const push = (i) => { if (core[i] && !keyed[i]) { keyed[i] = 1; queue[tail++] = i; } };
for (let x = 0; x < W; x++) { push(x); push((H - 1) * W + x); }
for (let y = 0; y < H; y++) { push(y * W); push(y * W + W - 1); }
for (const [sx, sy] of POCKET_SEEDS) {
  // Snap each seed to the nearest eroded-background pixel (pockets are narrow and noisy).
  let best = -1;
  let bestD = Infinity;
  for (let dy = -5; dy <= 5; dy++) {
    for (let dx = -5; dx <= 5; dx++) {
      const x = sx + dx;
      const y = sy + dy;
      if (x < 0 || y < 0 || x >= W || y >= H) continue;
      const dd = dx * dx + dy * dy;
      if (core[y * W + x] && dd < bestD) { bestD = dd; best = y * W + x; }
    }
  }
  assert.ok(best >= 0, `pocket seed (${sx},${sy}) is not near background`);
  push(best);
}
for (let head = 0; head < tail; head++) {
  const i = queue[head];
  const x = i % W;
  if (x > 0) push(i - 1);
  if (x < W - 1) push(i + 1);
  if (i >= W) push(i - W);
  if (i < N - W) push(i + W);
}

// Grow back over the eroded rim (two passes, only onto near-white pixels).
for (let pass = 0; pass < 2; pass++) {
  const add = [];
  for (let y = 0; y < H; y++) {
    for (let x = 0; x < W; x++) {
      const i = y * W + x;
      if (keyed[i] || !near[i]) continue;
      if ((x > 0 && keyed[i - 1]) || (x < W - 1 && keyed[i + 1]) || (y > 0 && keyed[i - W]) || (y < H - 1 && keyed[i + W]))
        add.push(i);
    }
  }
  for (const i of add) keyed[i] = 1;
}

// Output: keyed -> transparent; pixels within 2 px of the keyed region get an anti-alias ramp;
// everything else keeps its exact original colour and stays fully opaque.
const out = Buffer.from(data);
let keyedCount = 0;
for (let y = 0; y < H; y++) {
  for (let x = 0; x < W; x++) {
    const i = y * W + x;
    const p = i * 4;
    if (keyed[i]) { out[p + 3] = 0; keyedCount++; continue; }
    let edge = false;
    for (let dy = -2; dy <= 2 && !edge; dy++) {
      const yy = y + dy;
      if (yy < 0 || yy >= H) continue;
      for (let dx = -2; dx <= 2; dx++) {
        const xx = x + dx;
        if (xx >= 0 && xx < W && keyed[yy * W + xx]) { edge = true; break; }
      }
    }
    if (edge && dist[i] < 60) out[p + 3] = Math.round(255 * Math.min(1, Math.max(0, (dist[i] - 14) / 40)));
  }
}

const alphaAt = (x, y) => out[(y * W + x) * 4 + 3];
assert.equal(alphaAt(5, 700), 0, "left margin must be transparent");
assert.equal(alphaAt(362, 870), 0, "gap between rod and block must be transparent");
assert.equal(alphaAt(140, 600), 0, "pocket between hose and pipes must be transparent");
assert.equal(alphaAt(326, 500), 0, "pocket between pipes must be transparent");
assert.equal(alphaAt(270, 860), 255, "rod must be opaque");
assert.equal(alphaAt(228, 1300), 255, "blade specular must stay opaque");
assert.equal(alphaAt(226, 1150), 255, "blade specular must stay opaque (upper)");
assert.equal(alphaAt(400, 760), 255, "hazard collar must be opaque");
assert.equal(alphaAt(60, 560), 255, "left hose must be opaque");
assert.equal(alphaAt(730, 400), 255, "right hose must be opaque");
assert.equal(alphaAt(300, 1000), 255, "head must be opaque");
assert.ok(alphaAt(228, 1404) > 0, "blade tip must be present");
assert.equal(alphaAt(228, 1410), 0, "below the blade tip must be transparent");
assert.equal(alphaAt(100, 1300), 0, "left of the blade must be transparent");
assert.equal(alphaAt(500, 1200), 0, "right of the blade must be transparent");
console.log(`keyed ${keyedCount} of ${N} px (${((100 * keyedCount) / N).toFixed(1)}%)`);

await sharp(out, { raw: { width: W, height: H, channels: 4 } })
  .webp({ quality: 92, alphaQuality: 100, effort: 6 })
  .toFile("src/assets/press-arm.webp");
const meta = await sharp("src/assets/press-arm.webp").metadata();
console.log(`wrote src/assets/press-arm.webp ${meta.width}x${meta.height}, ${(meta.size / 1024).toFixed(0)} KB`);
