import assert from "node:assert/strict";
import sharp from "sharp";

const crop = { left: 1022, top: 1186, width: 638, height: 510 };
const { width, height } = crop;
const source = await sharp("src/assets/cut-original.png")
  .extract(crop)
  .ensureAlpha()
  .raw()
  .toBuffer();
const pixels = width * height;
const exterior = new Uint8Array(pixels);
const queue = new Int32Array(pixels);
let head = 0;
let tail = 0;

function backgroundDistance(index) {
  const p = index * 4;
  return Math.abs(source[p] - 250) + Math.abs(source[p + 1] - 249) + Math.abs(source[p + 2] - 245);
}

function visit(index) {
  if (exterior[index] || backgroundDistance(index) >= 26) return;
  exterior[index] = 1;
  queue[tail++] = index;
}

for (let x = 0; x < width; x++) {
  visit(x);
  visit((height - 1) * width + x);
}
for (let y = 0; y < height; y++) {
  visit(y * width);
  visit(y * width + width - 1);
}
while (head < tail) {
  const index = queue[head++];
  const x = index % width;
  if (x > 0) visit(index - 1);
  if (x < width - 1) visit(index + 1);
  if (index >= width) visit(index - width);
  if (index < pixels - width) visit(index + width);
}

const artwork = Buffer.from(source);
const emission = Buffer.from(source);
let preservedHighlights = 0;
let preservedNeon = 0;

for (let index = 0; index < pixels; index++) {
  const p = index * 4;
  // Only border-connected background is removed. Interior whites and neon keep their RGB/alpha.
  if (exterior[index]) {
    artwork[p + 3] = 0;
    emission[p + 3] = 0;
    continue;
  }

  const r = source[p] / 255;
  const g = source[p + 1] / 255;
  const b = source[p + 2] / 255;
  const high = Math.max(r, g, b);
  const low = Math.min(r, g, b);
  const neon = b >= r * 0.65 && high - low > 0.17;
  const white = low > 0.88;
  const energy = Math.pow(Math.max(0, (high - 0.58) / 0.42), 1.3);
  emission[p + 3] = Math.round(255 * energy * (neon ? 0.9 : white ? 0.65 : 0));

  if (white) preservedHighlights++;
  if (neon && high > 0.8) preservedNeon++;
  assert.equal(artwork[p + 3], source[p + 3]);
  assert.equal(artwork[p], source[p]);
  assert.equal(artwork[p + 1], source[p + 1]);
  assert.equal(artwork[p + 2], source[p + 2]);
}

assert.ok(preservedHighlights > 1000, "White highlights must remain opaque");
assert.ok(preservedNeon > 1000, "Neon colors must remain intact");
assert.equal(artwork[((height - 1) * width + 262) * 4 + 3], 255, "Device base must reach the last row");

const raw = { width, height, channels: 4 };
await sharp(artwork, { raw }).png({ compressionLevel: 9, palette: false }).toFile("src/assets/press-button.png");
await sharp(emission, { raw }).png({ compressionLevel: 9, palette: false }).toFile("src/assets/press-emission.png");
console.log(`Preserved ${preservedHighlights} white highlights and ${preservedNeon} neon pixels; base is flush.`);