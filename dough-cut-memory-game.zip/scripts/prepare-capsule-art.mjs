/**
 * Builds the "کوتاه" / "بلند" capsule sprites used inside the memorise panel.
 *
 *   node scripts/prepare-capsule-art.mjs
 *
 * The supplied artwork (short.png / long.png) already has an alpha channel, so this only trims
 * each pill to its visible bounds and downscales it for the web.
 */
import assert from "node:assert/strict";
import sharp from "sharp";

const OUT_WIDTH = 440;

for (const [src, out] of [
  ["src/assets/short-original.png", "src/assets/capsule-short.webp"],
  ["src/assets/long-original.png", "src/assets/capsule-long.webp"],
]) {
  const { data, info } = await sharp(src).ensureAlpha().raw().toBuffer({ resolveWithObject: true });
  const W = info.width;
  const H = info.height;
  let x0 = W;
  let x1 = -1;
  let y0 = H;
  let y1 = -1;
  for (let y = 0; y < H; y++) {
    for (let x = 0; x < W; x++) {
      if (data[(y * W + x) * 4 + 3] > 8) {
        if (x < x0) x0 = x;
        if (x > x1) x1 = x;
        if (y < y0) y0 = y;
        if (y > y1) y1 = y;
      }
    }
  }
  const w = x1 - x0 + 1;
  const h = y1 - y0 + 1;
  assert.ok(w > 400 && h > 200, `${src}: unexpected content size ${w}x${h}`);

  const trimmed = await sharp(src).extract({ left: x0, top: y0, width: w, height: h }).ensureAlpha().raw().toBuffer();
  // the pill must be solid in the middle and transparent at the corners
  const at = (x, y, c) => trimmed[(y * w + x) * 4 + c];
  assert.equal(at(Math.floor(w / 2), Math.floor(h / 2), 3), 255, `${src}: centre must be opaque`);
  assert.ok(at(1, 1, 3) < 40, `${src}: corner must be transparent`);

  await sharp(trimmed, { raw: { width: w, height: h, channels: 4 } })
    .resize({ width: OUT_WIDTH })
    .webp({ quality: 94, alphaQuality: 100, effort: 6 })
    .toFile(out);
  const meta = await sharp(out).metadata();
  console.log(`${out}: source ${w}x${h} (aspect ${(w / h).toFixed(3)}) -> ${meta.width}x${meta.height}`);
}
